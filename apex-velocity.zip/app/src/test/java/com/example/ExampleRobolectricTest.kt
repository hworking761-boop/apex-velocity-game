package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.GamePreferencesRepository
import com.example.data.GameRepository
import com.example.model.CarCatalog
import com.example.model.Difficulty
import com.example.model.GameMode
import com.example.model.RaceConfig
import com.example.model.RacerStanding
import com.example.model.TimeOfDay
import com.example.model.UpgradeCategory
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches Apex Velocity`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Apex Velocity", appName)
    }

    @Test
    fun `offline repository initializes garage and saves career progress`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repo = GameRepository(db, GamePreferencesRepository(context))

        repo.ensureInitialized()
        val cars = repo.garageCarsFlow.first()
        assertEquals(CarCatalog.cars.size, cars.size)
        assertTrue(cars["valkyrie_gtr"]?.unlocked == true)

        // Upgrade engine of starter car
        val upgraded = repo.upgradeCar("valkyrie_gtr", UpgradeCategory.ENGINE)
        assertTrue(upgraded)
        val afterUpgrade = repo.garageCarsFlow.first()["valkyrie_gtr"]!!
        assertEquals(2, afterUpgrade.upgrades.engine)

        // Record career win and verify reward + star persistence + unlock
        val result = repo.recordRaceCompletion(
            config = RaceConfig(
                mode = GameMode.CAREER,
                trackId = "azure_coast",
                timeOfDay = TimeOfDay.GOLDEN_COAST,
                carId = "valkyrie_gtr",
                laps = 2,
                difficulty = Difficulty.ROOKIE,
                careerEventId = "career_2"
            ),
            playerPosition = 1,
            totalTimeMs = 92_400L,
            bestLapMs = 45_100L,
            standings = listOf(
                RacerStanding("YOU", "Valkyrie GT-R", true, 1, 92_400L, 45_100L, true)
            )
        )

        assertEquals(3, result.starsEarned)
        assertEquals("kurogane_rs", result.newlyUnlockedCarId)
        assertTrue(repo.garageCarsFlow.first()["kurogane_rs"]?.unlocked == true)
        assertTrue(repo.bestLapsFlow.first()["azure_coast"]?.bestLapMs == 45_100L)

        db.close()
    }
}
