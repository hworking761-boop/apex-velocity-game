package com.example

import com.example.engine.AiDriver
import com.example.engine.DriverInput
import com.example.engine.RacePhase
import com.example.engine.RaceSimulation
import com.example.engine.TrackSpline
import com.example.model.CarCatalog
import com.example.model.CarUpgradeLevels
import com.example.model.Difficulty
import com.example.model.GameMode
import com.example.model.RaceConfig
import com.example.model.TimeOfDay
import com.example.model.TrackCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RaceSimulationTest {

    @Test
    fun `all 4 tracks generate valid closed splines`() {
        for (def in TrackCatalog.tracks) {
            val spline = TrackSpline(def)
            assertTrue("Track ${def.id} length should be > 800m", spline.totalLength > 800f)
            assertEquals(420, spline.samples.size)
            for (s in spline.samples) {
                assertFalse(s.pos.x.isNaN())
                assertFalse(s.pos.y.isNaN())
                assertFalse(s.pos.z.isNaN())
            }
        }
    }

    @Test
    fun `race simulation completes 1-lap race from countdown to finish`() {
        val config = RaceConfig(
            mode = GameMode.QUICK_RACE,
            trackId = "metro_skyline",
            timeOfDay = TimeOfDay.DAYTIME,
            carId = CarCatalog.cars.last().id, // Hyperion Apex
            laps = 1,
            difficulty = Difficulty.ROOKIE
        )
        val sim = RaceSimulation(config, CarUpgradeLevels(5, 5, 5, 5), "crimson_rush")
        assertEquals(RacePhase.COUNTDOWN, sim.phase)

        // Advance past 3.2s countdown
        repeat(80) {
            sim.step(0.05f, 50)
        }
        assertEquals(RacePhase.RACING, sim.phase)

        // Drive player car with AI autopilot around 1 full lap
        val autopilot = AiDriver(0f, Difficulty.LEGEND, 1.0f)
        var maxSteps = 3200
        while (sim.phase != RacePhase.FINISHED && maxSteps > 0) {
            sim.playerInput = autopilot.computeInput(sim.player, sim.racers, sim.track, 0.03f)
            sim.step(0.03f, 50)
            maxSteps--
        }

        assertEquals(RacePhase.FINISHED, sim.phase)
        assertTrue(sim.player.finished)
        assertTrue(sim.raceElapsedMs > 10_000L)
    }
}
