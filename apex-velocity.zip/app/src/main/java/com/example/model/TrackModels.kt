package com.example.model

enum class TrackEnvironmentType {
    CITY_DAY,
    COASTAL_HIGHWAY,
    MOUNTAIN_ALPINE,
    DESERT_SUNSET
}

enum class TimeOfDay(
    val label: String,
    val skyTopRgb: FloatArray,
    val skyHorizonRgb: FloatArray,
    val fogRgb: FloatArray,
    val sunDir: FloatArray,
    val sunColor: FloatArray,
    val ambientColor: FloatArray,
    val headlightIntensity: Float
) {
    DAYTIME(
        label = "Daylight",
        skyTopRgb = floatArrayOf(0.16f, 0.44f, 0.84f),
        skyHorizonRgb = floatArrayOf(0.68f, 0.83f, 0.96f),
        fogRgb = floatArrayOf(0.66f, 0.80f, 0.93f),
        sunDir = floatArrayOf(0.55f, 0.78f, 0.30f),
        sunColor = floatArrayOf(1.00f, 0.97f, 0.90f),
        ambientColor = floatArrayOf(0.36f, 0.40f, 0.46f),
        headlightIntensity = 0.35f
    ),
    GOLDEN_COAST(
        label = "Coastal Sun",
        skyTopRgb = floatArrayOf(0.12f, 0.48f, 0.86f),
        skyHorizonRgb = floatArrayOf(0.84f, 0.89f, 0.94f),
        fogRgb = floatArrayOf(0.76f, 0.84f, 0.92f),
        sunDir = floatArrayOf(-0.45f, 0.72f, 0.52f),
        sunColor = floatArrayOf(1.00f, 0.95f, 0.84f),
        ambientColor = floatArrayOf(0.38f, 0.42f, 0.48f),
        headlightIntensity = 0.40f
    ),
    SUNSET(
        label = "Sunset",
        skyTopRgb = floatArrayOf(0.18f, 0.14f, 0.36f),
        skyHorizonRgb = floatArrayOf(0.96f, 0.49f, 0.24f),
        fogRgb = floatArrayOf(0.78f, 0.43f, 0.29f),
        sunDir = floatArrayOf(0.78f, 0.24f, -0.58f),
        sunColor = floatArrayOf(1.00f, 0.64f, 0.36f),
        ambientColor = floatArrayOf(0.38f, 0.27f, 0.29f),
        headlightIntensity = 0.85f
    ),
    NIGHT(
        label = "Midnight",
        skyTopRgb = floatArrayOf(0.02f, 0.04f, 0.10f),
        skyHorizonRgb = floatArrayOf(0.08f, 0.14f, 0.26f),
        fogRgb = floatArrayOf(0.06f, 0.10f, 0.19f),
        sunDir = floatArrayOf(0.35f, 0.65f, 0.40f),
        sunColor = floatArrayOf(0.36f, 0.44f, 0.65f),
        ambientColor = floatArrayOf(0.16f, 0.19f, 0.26f),
        headlightIntensity = 1.45f
    )
}

data class TrackWaypoint(
    val x: Float,
    val y: Float,
    val z: Float,
    val bankingRad: Float = 0f
)

data class TrackDefinition(
    val id: String,
    val name: String,
    val location: String,
    val environment: TrackEnvironmentType,
    val defaultTimeOfDay: TimeOfDay,
    val roadHalfWidth: Float,
    val lengthLabel: String,
    val difficultyLabel: String,
    val description: String,
    val accentHex: Long,
    val groundColorRgb: FloatArray,
    val barrierColorRgb: FloatArray,
    val waypoints: List<TrackWaypoint>
)

object TrackCatalog {
    val tracks: List<TrackDefinition> = listOf(
        TrackDefinition(
            id = "metro_skyline",
            name = "Metro Skyline",
            location = "Chicago Downtown Loop",
            environment = TrackEnvironmentType.CITY_DAY,
            defaultTimeOfDay = TimeOfDay.DAYTIME,
            roadHalfWidth = 8.5f,
            lengthLabel = "3.4 km",
            difficultyLabel = "Technical Street",
            description = "High-speed downtown boulevards, sweeping elevated expressways, and tight 90-degree skyline chicanes.",
            accentHex = 0xFF00E5FF,
            groundColorRgb = floatArrayOf(0.20f, 0.22f, 0.25f),
            barrierColorRgb = floatArrayOf(0.76f, 0.78f, 0.82f),
            waypoints = listOf(
                TrackWaypoint(0f, 0f, 0f),
                TrackWaypoint(0f, 0f, -150f),
                TrackWaypoint(38f, 1.5f, -290f),
                TrackWaypoint(155f, 4.0f, -350f),
                TrackWaypoint(285f, 4.5f, -310f),
                TrackWaypoint(355f, 2.0f, -205f),
                TrackWaypoint(330f, 0f, -80f),
                TrackWaypoint(235f, 0f, -35f),
                TrackWaypoint(215f, 0f, 75f),
                TrackWaypoint(295f, 1.5f, 185f),
                TrackWaypoint(245f, 2.0f, 295f),
                TrackWaypoint(115f, 0.5f, 285f),
                TrackWaypoint(28f, 0f, 185f),
                TrackWaypoint(0f, 0f, 95f)
            )
        ),
        TrackDefinition(
            id = "azure_coast",
            name = "Azure Coast",
            location = "Pacific Cliff Highway",
            environment = TrackEnvironmentType.COASTAL_HIGHWAY,
            defaultTimeOfDay = TimeOfDay.GOLDEN_COAST,
            roadHalfWidth = 9.0f,
            lengthLabel = "4.1 km",
            difficultyLabel = "Fast Flowing",
            description = "Sweeping oceanfront curves hugging turquoise cliffs, palm-lined promenades, and flat-out coastal straights.",
            accentHex = 0xFF00E676,
            groundColorRgb = floatArrayOf(0.76f, 0.69f, 0.52f),
            barrierColorRgb = floatArrayOf(0.88f, 0.88f, 0.90f),
            waypoints = listOf(
                TrackWaypoint(0f, 2f, 0f),
                TrackWaypoint(0f, 2f, -180f),
                TrackWaypoint(-55f, 6f, -330f),
                TrackWaypoint(-180f, 11f, -410f),
                TrackWaypoint(-330f, 8f, -355f),
                TrackWaypoint(-395f, 3f, -205f),
                TrackWaypoint(-340f, 2f, -55f),
                TrackWaypoint(-240f, 2f, 60f),
                TrackWaypoint(-290f, 5f, 200f),
                TrackWaypoint(-185f, 7f, 330f),
                TrackWaypoint(-45f, 4f, 300f),
                TrackWaypoint(12f, 2f, 165f)
            )
        ),
        TrackDefinition(
            id = "alpine_ridge",
            name = "Alpine Ridge",
            location = "Dolomite Switchbacks",
            environment = TrackEnvironmentType.MOUNTAIN_ALPINE,
            defaultTimeOfDay = TimeOfDay.DAYTIME,
            roadHalfWidth = 8.0f,
            lengthLabel = "3.8 km",
            difficultyLabel = "High Elevation",
            description = "Steep alpine climbs through misty pine forests, dramatic ridge hairpins, and blistering downhill braking zones.",
            accentHex = 0xFF64B5F6,
            groundColorRgb = floatArrayOf(0.22f, 0.34f, 0.21f),
            barrierColorRgb = floatArrayOf(0.68f, 0.70f, 0.73f),
            waypoints = listOf(
                TrackWaypoint(0f, 0f, 0f),
                TrackWaypoint(0f, 4f, -155f),
                TrackWaypoint(95f, 14f, -270f),
                TrackWaypoint(230f, 24f, -260f),
                TrackWaypoint(290f, 28f, -135f),
                TrackWaypoint(195f, 22f, -45f),
                TrackWaypoint(265f, 18f, 80f),
                TrackWaypoint(360f, 12f, 190f),
                TrackWaypoint(280f, 6f, 310f),
                TrackWaypoint(130f, 3f, 280f),
                TrackWaypoint(35f, 1f, 155f)
            )
        ),
        TrackDefinition(
            id = "redstone_canyon",
            name = "Redstone Canyon",
            location = "Mojave Sunset Mesa",
            environment = TrackEnvironmentType.DESERT_SUNSET,
            defaultTimeOfDay = TimeOfDay.SUNSET,
            roadHalfWidth = 9.2f,
            lengthLabel = "4.6 km",
            difficultyLabel = "Extreme Velocity",
            description = "Blazing desert straightaways carved past sandstone mesas under a glowing amber sunset horizon.",
            accentHex = 0xFFFF9100,
            groundColorRgb = floatArrayOf(0.64f, 0.36f, 0.22f),
            barrierColorRgb = floatArrayOf(0.84f, 0.56f, 0.36f),
            waypoints = listOf(
                TrackWaypoint(0f, 0f, 0f),
                TrackWaypoint(0f, 0f, -210f),
                TrackWaypoint(70f, 3f, -380f),
                TrackWaypoint(230f, 7f, -450f),
                TrackWaypoint(400f, 5f, -365f),
                TrackWaypoint(440f, 1f, -180f),
                TrackWaypoint(330f, 0f, -30f),
                TrackWaypoint(385f, 2f, 145f),
                TrackWaypoint(310f, 4f, 315f),
                TrackWaypoint(145f, 2f, 355f),
                TrackWaypoint(25f, 0f, 215f)
            )
        )
    )

    fun findById(id: String): TrackDefinition = tracks.firstOrNull { it.id == id } ?: tracks.first()
}
