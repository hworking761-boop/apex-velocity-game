package com.example.model

enum class CarBodyStyle {
    GT_COUPE,
    MUSCLE_WIDEBODY,
    MID_ENGINE_WEDGE,
    JDM_TUNER,
    LE_MANS_PROTOTYPE
}

enum class UpgradeCategory(val label: String, val shortDesc: String) {
    ENGINE("Engine ECU", "Boosts top speed and high-RPM pull"),
    TURBO("Twin-Turbo & Nitro", "Increases acceleration & nitro capacity"),
    TIRES("Semi-Slick Tires", "Improves lateral grip & drift stability"),
    BRAKES("Carbon Brakes & Aero", "Sharpens braking & cornering response")
}

data class PaintFinish(
    val id: String,
    val name: String,
    val hexRgb: Int,
    val metallic: Float = 0.85f
)

object PaintCatalog {
    val finishes = listOf(
        PaintFinish("crimson_rush", "Crimson Rush", 0xFFD91E36.toInt(), 0.88f),
        PaintFinish("cobalt_apex", "Cobalt Apex", 0xFF1565D8.toInt(), 0.90f),
        PaintFinish("arctic_silver", "Arctic Silver", 0xFFD0D8E4.toInt(), 0.94f),
        PaintFinish("obsidian_stealth", "Obsidian Stealth", 0xFF1C212B.toInt(), 0.72f),
        PaintFinish("solar_amber", "Solar Amber", 0xFFFF7A00.toInt(), 0.86f),
        PaintFinish("emerald_gt", "British Emerald", 0xFF0B8A56.toInt(), 0.84f),
        PaintFinish("pearl_white", "Glacier Pearl", 0xFFF2F5FA.toInt(), 0.78f),
        PaintFinish("violet_horizon", "Midnight Violet", 0xFF6B2CD9.toInt(), 0.90f)
    )

    fun findById(id: String): PaintFinish = finishes.firstOrNull { it.id == id } ?: finishes.first()
}

data class CarUpgradeLevels(
    val engine: Int = 1,
    val turbo: Int = 1,
    val tires: Int = 1,
    val brakes: Int = 1
) {
    fun levelFor(category: UpgradeCategory): Int = when (category) {
        UpgradeCategory.ENGINE -> engine
        UpgradeCategory.TURBO -> turbo
        UpgradeCategory.TIRES -> tires
        UpgradeCategory.BRAKES -> brakes
    }

    fun withUpgrade(category: UpgradeCategory): CarUpgradeLevels = when (category) {
        UpgradeCategory.ENGINE -> copy(engine = (engine + 1).coerceAtMost(MAX_UPGRADE_LEVEL))
        UpgradeCategory.TURBO -> copy(turbo = (turbo + 1).coerceAtMost(MAX_UPGRADE_LEVEL))
        UpgradeCategory.TIRES -> copy(tires = (tires + 1).coerceAtMost(MAX_UPGRADE_LEVEL))
        UpgradeCategory.BRAKES -> copy(brakes = (brakes + 1).coerceAtMost(MAX_UPGRADE_LEVEL))
    }

    val totalRatingBonus: Int
        get() = (engine + turbo + tires + brakes - 4) * 14

    companion object {
        const val MAX_UPGRADE_LEVEL = 5

        fun upgradeCost(currentLevel: Int, baseTier: Int): Int {
            if (currentLevel >= MAX_UPGRADE_LEVEL) return 0
            return (750 + baseTier * 350) * currentLevel
        }
    }
}

data class CarSpec(
    val id: String,
    val name: String,
    val manufacturer: String,
    val categoryClass: String,
    val bodyStyle: CarBodyStyle,
    val description: String,
    val unlockCost: Int,
    val defaultPaintId: String,
    val basePerformanceIndex: Int,
    // Physics parameters
    val baseTopSpeedKmh: Float,
    val baseAcceleration: Float,
    val baseHandling: Float,
    val baseBraking: Float,
    val baseNitroPower: Float,
    // Visual 3D geometry scale modifiers
    val lengthMeters: Float,
    val widthMeters: Float,
    val heightMeters: Float,
    val wheelRadius: Float
) {
    fun effectiveTopSpeedKmh(upgrades: CarUpgradeLevels): Float =
        baseTopSpeedKmh + (upgrades.engine - 1) * 9.5f + (upgrades.turbo - 1) * 2.5f

    fun effectiveAcceleration(upgrades: CarUpgradeLevels): Float =
        baseAcceleration + (upgrades.turbo - 1) * 1.4f + (upgrades.engine - 1) * 0.7f

    fun effectiveHandling(upgrades: CarUpgradeLevels): Float =
        baseHandling + (upgrades.tires - 1) * 0.08f + (upgrades.brakes - 1) * 0.03f

    fun effectiveBraking(upgrades: CarUpgradeLevels): Float =
        baseBraking + (upgrades.brakes - 1) * 2.6f + (upgrades.tires - 1) * 0.9f

    fun effectiveNitroPower(upgrades: CarUpgradeLevels): Float =
        baseNitroPower + (upgrades.turbo - 1) * 0.07f

    fun speedStatNormalized(upgrades: CarUpgradeLevels): Float =
        ((effectiveTopSpeedKmh(upgrades) - 220f) / 170f).coerceIn(0.25f, 1f)

    fun accelStatNormalized(upgrades: CarUpgradeLevels): Float =
        ((effectiveAcceleration(upgrades) - 18f) / 22f).coerceIn(0.25f, 1f)

    fun handlingStatNormalized(upgrades: CarUpgradeLevels): Float =
        ((effectiveHandling(upgrades) - 0.65f) / 0.55f).coerceIn(0.25f, 1f)

    fun brakingStatNormalized(upgrades: CarUpgradeLevels): Float =
        ((effectiveBraking(upgrades) - 32f) / 28f).coerceIn(0.25f, 1f)
}

object CarCatalog {
    val cars: List<CarSpec> = listOf(
        CarSpec(
            id = "valkyrie_gtr",
            name = "Valkyrie GT-R",
            manufacturer = "Valkyrie Motors",
            categoryClass = "CLASS B • STREET GT",
            bodyStyle = CarBodyStyle.GT_COUPE,
            description = "Twin-turbo V6 grand tourer engineered for balanced cornering and predictable high-speed poise.",
            unlockCost = 0,
            defaultPaintId = "crimson_rush",
            basePerformanceIndex = 580,
            baseTopSpeedKmh = 278f,
            baseAcceleration = 24.5f,
            baseHandling = 0.86f,
            baseBraking = 38f,
            baseNitroPower = 1.26f,
            lengthMeters = 4.45f,
            widthMeters = 1.92f,
            heightMeters = 1.24f,
            wheelRadius = 0.34f
        ),
        CarSpec(
            id = "kurogane_rs",
            name = "Kurogane RS",
            manufacturer = "Kurogane Works",
            categoryClass = "CLASS B+ • DRIFT TUNER",
            bodyStyle = CarBodyStyle.JDM_TUNER,
            description = "Aggressive wide-fender inline-six coupe with rapid boost recovery and razor-sharp drift transitions.",
            unlockCost = 3500,
            defaultPaintId = "solar_amber",
            basePerformanceIndex = 635,
            baseTopSpeedKmh = 294f,
            baseAcceleration = 27.2f,
            baseHandling = 0.94f,
            baseBraking = 41f,
            baseNitroPower = 1.34f,
            lengthMeters = 4.38f,
            widthMeters = 1.94f,
            heightMeters = 1.25f,
            wheelRadius = 0.34f
        ),
        CarSpec(
            id = "solstice_v8",
            name = "Solstice V8",
            manufacturer = "Solstice Performance",
            categoryClass = "CLASS A • MUSCLE TRACK",
            bodyStyle = CarBodyStyle.MUSCLE_WIDEBODY,
            description = "Supercharged 6.2L V8 track weapon delivering thunderous straight-line launch and imposing widebody stance.",
            unlockCost = 7000,
            defaultPaintId = "cobalt_apex",
            basePerformanceIndex = 705,
            baseTopSpeedKmh = 318f,
            baseAcceleration = 30.0f,
            baseHandling = 0.88f,
            baseBraking = 43f,
            baseNitroPower = 1.32f,
            lengthMeters = 4.62f,
            widthMeters = 2.02f,
            heightMeters = 1.26f,
            wheelRadius = 0.36f
        ),
        CarSpec(
            id = "spectre_aero",
            name = "Spectre Aero",
            manufacturer = "Spectre Atelier",
            categoryClass = "CLASS S • MID-ENGINE",
            bodyStyle = CarBodyStyle.MID_ENGINE_WEDGE,
            description = "Carbon-tub mid-engine exotic with active rear aero and ferocious apex grip through technical hairpins.",
            unlockCost = 12500,
            defaultPaintId = "emerald_gt",
            basePerformanceIndex = 785,
            baseTopSpeedKmh = 336f,
            baseAcceleration = 32.5f,
            baseHandling = 1.03f,
            baseBraking = 47f,
            baseNitroPower = 1.36f,
            lengthMeters = 4.48f,
            widthMeters = 2.00f,
            heightMeters = 1.13f,
            wheelRadius = 0.35f
        ),
        CarSpec(
            id = "hyperion_apex",
            name = "Hyperion Apex",
            manufacturer = "Hyperion Motorsport",
            categoryClass = "CLASS X • HYPER PROTOTYPE",
            bodyStyle = CarBodyStyle.LE_MANS_PROTOTYPE,
            description = "Track-homologated endurance hypercar featuring a central dorsal fin, Venturi tunnels, and unmatched velocity.",
            unlockCost = 20000,
            defaultPaintId = "arctic_silver",
            basePerformanceIndex = 860,
            baseTopSpeedKmh = 362f,
            baseAcceleration = 35.8f,
            baseHandling = 1.08f,
            baseBraking = 52f,
            baseNitroPower = 1.42f,
            lengthMeters = 4.72f,
            widthMeters = 2.04f,
            heightMeters = 1.08f,
            wheelRadius = 0.36f
        )
    )

    fun findById(id: String): CarSpec = cars.firstOrNull { it.id == id } ?: cars.first()
}
