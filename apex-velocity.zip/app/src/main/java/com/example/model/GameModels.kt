package com.example.model

enum class GameMode(val label: String, val subtitle: String) {
    CAREER("Career", "Championship events with credit rewards & car unlocks"),
    QUICK_RACE("Quick Race", "Customize track, laps, and AI difficulty"),
    TIME_TRIAL("Time Trial", "Solo hot-lap attack against your track record"),
    PRACTICE("Practice", "Open track session to master drifting and lines")
}

enum class Difficulty(val label: String, val aiSpeedMultiplier: Float, val rewardMultiplier: Float) {
    ROOKIE("Rookie", 0.84f, 1.0f),
    PRO("Pro", 0.96f, 1.35f),
    LEGEND("Legend", 1.06f, 1.75f)
}

enum class GraphicsQuality(
    val label: String,
    val description: String,
    val drawDistance: Float,
    val maxParticles: Int,
    val enableShadows: Boolean,
    val propDensityStep: Int
) {
    LOW("Low", "Battery saver • 30–60 FPS on entry hardware", 240f, 48, false, 2),
    MEDIUM("Medium", "Balanced visuals & smooth 60 FPS", 380f, 110, true, 1),
    HIGH("High", "Full reflections, shadows & dense scenery", 560f, 200, true, 1)
}

enum class CameraMode(val label: String) {
    CHASE("Chase"),
    CLOSE_REAR("Close Rear"),
    BUMPER("Bumper"),
    COCKPIT("Cockpit")
}

data class CareerEvent(
    val id: String,
    val eventNumber: Int,
    val title: String,
    val seriesName: String,
    val trackId: String,
    val timeOfDay: TimeOfDay,
    val laps: Int,
    val difficulty: Difficulty,
    val rewardFirst: Int,
    val rewardSecond: Int,
    val rewardThird: Int,
    val unlockCarId: String? = null,
    val requiredPreviousStars: Int = 0
)

object CareerCatalog {
    val events = listOf(
        CareerEvent(
            id = "career_1",
            eventNumber = 1,
            title = "Downtown Sprint",
            seriesName = "TIER 1 • STREET ROOKIE",
            trackId = "metro_skyline",
            timeOfDay = TimeOfDay.DAYTIME,
            laps = 2,
            difficulty = Difficulty.ROOKIE,
            rewardFirst = 1800,
            rewardSecond = 1100,
            rewardThird = 700,
            requiredPreviousStars = 0
        ),
        CareerEvent(
            id = "career_2",
            eventNumber = 2,
            title = "Pacific Horizon",
            seriesName = "TIER 1 • STREET ROOKIE",
            trackId = "azure_coast",
            timeOfDay = TimeOfDay.GOLDEN_COAST,
            laps = 2,
            difficulty = Difficulty.ROOKIE,
            rewardFirst = 2200,
            rewardSecond = 1400,
            rewardThird = 850,
            unlockCarId = "kurogane_rs",
            requiredPreviousStars = 1
        ),
        CareerEvent(
            id = "career_3",
            eventNumber = 3,
            title = "Timberline Climb",
            seriesName = "TIER 2 • APEX CHALLENGER",
            trackId = "alpine_ridge",
            timeOfDay = TimeOfDay.DAYTIME,
            laps = 2,
            difficulty = Difficulty.PRO,
            rewardFirst = 3000,
            rewardSecond = 1900,
            rewardThird = 1100,
            requiredPreviousStars = 3
        ),
        CareerEvent(
            id = "career_4",
            eventNumber = 4,
            title = "Mojave Dusk",
            seriesName = "TIER 2 • APEX CHALLENGER",
            trackId = "redstone_canyon",
            timeOfDay = TimeOfDay.SUNSET,
            laps = 3,
            difficulty = Difficulty.PRO,
            rewardFirst = 3800,
            rewardSecond = 2400,
            rewardThird = 1400,
            unlockCarId = "solstice_v8",
            requiredPreviousStars = 5
        ),
        CareerEvent(
            id = "career_5",
            eventNumber = 5,
            title = "Midnight Skyline GP",
            seriesName = "TIER 3 • NIGHT SYNDICATE",
            trackId = "metro_skyline",
            timeOfDay = TimeOfDay.NIGHT,
            laps = 3,
            difficulty = Difficulty.PRO,
            rewardFirst = 4600,
            rewardSecond = 2900,
            rewardThird = 1700,
            requiredPreviousStars = 7
        ),
        CareerEvent(
            id = "career_6",
            eventNumber = 6,
            title = "Coastal Endurance",
            seriesName = "TIER 3 • NIGHT SYNDICATE",
            trackId = "azure_coast",
            timeOfDay = TimeOfDay.SUNSET,
            laps = 3,
            difficulty = Difficulty.LEGEND,
            rewardFirst = 5800,
            rewardSecond = 3600,
            rewardThird = 2100,
            unlockCarId = "spectre_aero",
            requiredPreviousStars = 10
        ),
        CareerEvent(
            id = "career_7",
            eventNumber = 7,
            title = "Alpine Midnight",
            seriesName = "TIER 4 • HYPER FINALS",
            trackId = "alpine_ridge",
            timeOfDay = TimeOfDay.NIGHT,
            laps = 3,
            difficulty = Difficulty.LEGEND,
            rewardFirst = 7200,
            rewardSecond = 4400,
            rewardThird = 2500,
            requiredPreviousStars = 13
        ),
        CareerEvent(
            id = "career_8",
            eventNumber = 8,
            title = "Apex World Finale",
            seriesName = "TIER 4 • HYPER FINALS",
            trackId = "redstone_canyon",
            timeOfDay = TimeOfDay.SUNSET,
            laps = 4,
            difficulty = Difficulty.LEGEND,
            rewardFirst = 10000,
            rewardSecond = 6000,
            rewardThird = 3500,
            unlockCarId = "hyperion_apex",
            requiredPreviousStars = 16
        )
    )
}

data class RaceConfig(
    val mode: GameMode,
    val trackId: String,
    val timeOfDay: TimeOfDay,
    val carId: String,
    val laps: Int,
    val difficulty: Difficulty,
    val careerEventId: String? = null
)

data class RacerStanding(
    val name: String,
    val carName: String,
    val isPlayer: Boolean,
    val position: Int,
    val finishTimeMs: Long,
    val bestLapMs: Long,
    val finished: Boolean
)

data class RaceResult(
    val config: RaceConfig,
    val playerPosition: Int,
    val totalTimeMs: Long,
    val bestLapMs: Long,
    val creditsEarned: Int,
    val starsEarned: Int,
    val newlyUnlockedCarId: String?,
    val isNewTrackRecord: Boolean,
    val standings: List<RacerStanding>
)
