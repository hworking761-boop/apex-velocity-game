package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.CameraMode
import com.example.model.GraphicsQuality
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.gameSettingsDataStore by preferencesDataStore(name = "apex_velocity_settings")

data class GameSettings(
    val graphicsQuality: GraphicsQuality = GraphicsQuality.MEDIUM,
    val tiltSteeringEnabled: Boolean = false,
    val tiltSensitivity: Float = 1.0f,
    val soundEnabled: Boolean = true,
    val soundVolume: Float = 0.8f,
    val defaultCamera: CameraMode = CameraMode.CHASE,
    val showMinimap: Boolean = true
)

class GamePreferencesRepository(private val context: Context) {
    private object Keys {
        val GRAPHICS_QUALITY = stringPreferencesKey("graphics_quality")
        val TILT_STEERING = booleanPreferencesKey("tilt_steering")
        val TILT_SENSITIVITY = floatPreferencesKey("tilt_sensitivity")
        val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        val SOUND_VOLUME = floatPreferencesKey("sound_volume")
        val DEFAULT_CAMERA = stringPreferencesKey("default_camera")
        val SHOW_MINIMAP = booleanPreferencesKey("show_minimap")
    }

    val settingsFlow: Flow<GameSettings> = context.gameSettingsDataStore.data.map { prefs ->
        GameSettings(
            graphicsQuality = prefs[Keys.GRAPHICS_QUALITY]
                ?.let { runCatching { GraphicsQuality.valueOf(it) }.getOrNull() }
                ?: GraphicsQuality.MEDIUM,
            tiltSteeringEnabled = prefs[Keys.TILT_STEERING] ?: false,
            tiltSensitivity = (prefs[Keys.TILT_SENSITIVITY] ?: 1.0f).coerceIn(0.5f, 2.0f),
            soundEnabled = prefs[Keys.SOUND_ENABLED] ?: true,
            soundVolume = (prefs[Keys.SOUND_VOLUME] ?: 0.8f).coerceIn(0f, 1f),
            defaultCamera = prefs[Keys.DEFAULT_CAMERA]
                ?.let { runCatching { CameraMode.valueOf(it) }.getOrNull() }
                ?: CameraMode.CHASE,
            showMinimap = prefs[Keys.SHOW_MINIMAP] ?: true
        )
    }

    suspend fun setGraphicsQuality(quality: GraphicsQuality) {
        context.gameSettingsDataStore.edit { it[Keys.GRAPHICS_QUALITY] = quality.name }
    }

    suspend fun setTiltSteeringEnabled(enabled: Boolean) {
        context.gameSettingsDataStore.edit { it[Keys.TILT_STEERING] = enabled }
    }

    suspend fun setTiltSensitivity(sensitivity: Float) {
        context.gameSettingsDataStore.edit { it[Keys.TILT_SENSITIVITY] = sensitivity.coerceIn(0.5f, 2.0f) }
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.gameSettingsDataStore.edit { it[Keys.SOUND_ENABLED] = enabled }
    }

    suspend fun setSoundVolume(volume: Float) {
        context.gameSettingsDataStore.edit { it[Keys.SOUND_VOLUME] = volume.coerceIn(0f, 1f) }
    }

    suspend fun setDefaultCamera(camera: CameraMode) {
        context.gameSettingsDataStore.edit { it[Keys.DEFAULT_CAMERA] = camera.name }
    }

    suspend fun setShowMinimap(show: Boolean) {
        context.gameSettingsDataStore.edit { it[Keys.SHOW_MINIMAP] = show }
    }
}
