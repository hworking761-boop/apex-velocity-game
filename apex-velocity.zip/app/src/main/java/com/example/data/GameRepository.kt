package com.example.data

import com.example.model.CarCatalog
import com.example.model.CarUpgradeLevels
import com.example.model.CareerCatalog
import com.example.model.GameMode
import com.example.model.PaintCatalog
import com.example.model.RaceConfig
import com.example.model.RaceResult
import com.example.model.RacerStanding
import com.example.model.UpgradeCategory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

data class GarageCarSnapshot(
    val carId: String,
    val unlocked: Boolean,
    val paintId: String,
    val upgrades: CarUpgradeLevels
)

class GameRepository(
    private val db: AppDatabase,
    val preferences: GamePreferencesRepository
) {
    private val profileDao = db.playerProfileDao()
    private val carDao = db.carStateDao()
    private val careerDao = db.careerResultDao()
    private val bestLapDao = db.trackBestLapDao()

    val profileFlow: Flow<PlayerProfileEntity> = profileDao.observeProfile()
        .map { it ?: PlayerProfileEntity() }

    val garageCarsFlow: Flow<Map<String, GarageCarSnapshot>> = carDao.observeAll()
        .map { list ->
            list.associate { entity ->
                entity.carId to GarageCarSnapshot(
                    carId = entity.carId,
                    unlocked = entity.unlocked,
                    paintId = entity.paintId,
                    upgrades = CarUpgradeLevels(
                        engine = entity.engineLevel,
                        turbo = entity.turboLevel,
                        tires = entity.tiresLevel,
                        brakes = entity.brakesLevel
                    )
                )
            }
        }

    val careerResultsFlow: Flow<Map<String, CareerResultEntity>> = careerDao.observeAll()
        .map { list -> list.associateBy { it.eventId } }

    val bestLapsFlow: Flow<Map<String, TrackBestLapEntity>> = bestLapDao.observeAll()
        .map { list -> list.associateBy { it.trackId } }

    suspend fun ensureInitialized() {
        if (profileDao.getProfile() == null) {
            profileDao.upsert(PlayerProfileEntity())
        }
        val initialCars = CarCatalog.cars.mapIndexed { index, spec ->
            CarStateEntity(
                carId = spec.id,
                unlocked = index == 0,
                paintId = spec.defaultPaintId
            )
        }
        carDao.insertAllIgnore(initialCars)
    }

    suspend fun selectCar(carId: String): Boolean {
        val state = carDao.getById(carId) ?: return false
        if (!state.unlocked) return false
        val profile = profileDao.getProfile() ?: PlayerProfileEntity()
        profileDao.upsert(profile.copy(selectedCarId = carId))
        return true
    }

    suspend fun purchaseCar(carId: String): Boolean {
        val spec = CarCatalog.findById(carId)
        val state = carDao.getById(carId) ?: return false
        if (state.unlocked) return selectCar(carId)
        val profile = profileDao.getProfile() ?: PlayerProfileEntity()
        if (profile.credits < spec.unlockCost) return false
        profileDao.upsert(
            profile.copy(
                credits = profile.credits - spec.unlockCost,
                selectedCarId = carId
            )
        )
        carDao.upsert(state.copy(unlocked = true))
        return true
    }

    suspend fun setCarPaint(carId: String, paintId: String) {
        val state = carDao.getById(carId) ?: return
        val validPaint = PaintCatalog.findById(paintId).id
        carDao.upsert(state.copy(paintId = validPaint))
    }

    suspend fun upgradeCar(carId: String, category: UpgradeCategory): Boolean {
        val state = carDao.getById(carId) ?: return false
        if (!state.unlocked) return false
        val currentUpgrades = CarUpgradeLevels(
            engine = state.engineLevel,
            turbo = state.turboLevel,
            tires = state.tiresLevel,
            brakes = state.brakesLevel
        )
        val currentLevel = currentUpgrades.levelFor(category)
        if (currentLevel >= CarUpgradeLevels.MAX_UPGRADE_LEVEL) return false
        val tierIndex = CarCatalog.cars.indexOfFirst { it.id == carId }.coerceAtLeast(0)
        val cost = CarUpgradeLevels.upgradeCost(currentLevel, tierIndex)
        val profile = profileDao.getProfile() ?: PlayerProfileEntity()
        if (profile.credits < cost) return false

        val next = currentUpgrades.withUpgrade(category)
        profileDao.upsert(profile.copy(credits = profile.credits - cost))
        carDao.upsert(
            state.copy(
                engineLevel = next.engine,
                turboLevel = next.turbo,
                tiresLevel = next.tires,
                brakesLevel = next.brakes
            )
        )
        return true
    }

    suspend fun recordRaceCompletion(
        config: RaceConfig,
        playerPosition: Int,
        totalTimeMs: Long,
        bestLapMs: Long,
        standings: List<RacerStanding>
    ): RaceResult {
        val profile = profileDao.getProfile() ?: PlayerProfileEntity()

        var creditsEarned = 0
        var starsEarned = 0
        var unlockedCarId: String? = null

        when (config.mode) {
            GameMode.CAREER -> {
                val event = CareerCatalog.events.firstOrNull { it.id == config.careerEventId }
                if (event != null) {
                    creditsEarned = when (playerPosition) {
                        1 -> event.rewardFirst
                        2 -> event.rewardSecond
                        3 -> event.rewardThird
                        else -> 400
                    }
                    starsEarned = when (playerPosition) {
                        1 -> 3
                        2 -> 2
                        3 -> 1
                        else -> 0
                    }
                    val existing = careerDao.getById(event.id)
                    val bestPos = minOf(existing?.bestPosition ?: 99, playerPosition)
                    val bestStars = maxOf(existing?.stars ?: 0, starsEarned)
                    val bestTime = if (existing != null && existing.bestTimeMs > 0) {
                        minOf(existing.bestTimeMs, totalTimeMs)
                    } else {
                        totalTimeMs
                    }
                    careerDao.upsert(
                        CareerResultEntity(
                            eventId = event.id,
                            bestPosition = bestPos,
                            stars = bestStars,
                            bestTimeMs = bestTime
                        )
                    )
                    if (playerPosition <= 2 && event.unlockCarId != null) {
                        val targetCar = carDao.getById(event.unlockCarId)
                        if (targetCar != null && !targetCar.unlocked) {
                            carDao.upsert(targetCar.copy(unlocked = true))
                            unlockedCarId = event.unlockCarId
                        }
                    }
                }
            }

            GameMode.QUICK_RACE -> {
                val base = when (playerPosition) {
                    1 -> 1200
                    2 -> 800
                    3 -> 550
                    else -> 300
                }
                creditsEarned = (base * config.difficulty.rewardMultiplier * (config.laps / 2f)).toInt()
            }

            GameMode.TIME_TRIAL -> {
                creditsEarned = 450 + config.laps * 100
            }

            GameMode.PRACTICE -> {
                creditsEarned = 150
            }
        }

        var isNewTrackRecord = false
        if (bestLapMs > 1000L) {
            val prevRecord = bestLapDao.getByTrackId(config.trackId)
            if (prevRecord == null || bestLapMs < prevRecord.bestLapMs) {
                isNewTrackRecord = true
                bestLapDao.upsert(
                    TrackBestLapEntity(
                        trackId = config.trackId,
                        bestLapMs = bestLapMs,
                        carId = config.carId
                    )
                )
                creditsEarned += 350
            }
        }

        profileDao.upsert(
            profile.copy(
                credits = profile.credits + creditsEarned,
                totalRacesCompleted = profile.totalRacesCompleted + 1,
                totalWins = profile.totalWins + if (playerPosition == 1 && config.mode != GameMode.PRACTICE && config.mode != GameMode.TIME_TRIAL) 1 else 0
            )
        )

        return RaceResult(
            config = config,
            playerPosition = playerPosition,
            totalTimeMs = totalTimeMs,
            bestLapMs = bestLapMs,
            creditsEarned = creditsEarned,
            starsEarned = starsEarned,
            newlyUnlockedCarId = unlockedCarId,
            isNewTrackRecord = isNewTrackRecord,
            standings = standings
        )
    }
}
