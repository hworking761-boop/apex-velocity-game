package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "player_profile")
data class PlayerProfileEntity(
    @PrimaryKey val id: Int = 1,
    val credits: Int = 2500,
    val selectedCarId: String = "valkyrie_gtr",
    val totalRacesCompleted: Int = 0,
    val totalWins: Int = 0
)

@Entity(tableName = "car_states")
data class CarStateEntity(
    @PrimaryKey val carId: String,
    val unlocked: Boolean,
    val paintId: String,
    val engineLevel: Int = 1,
    val turboLevel: Int = 1,
    val tiresLevel: Int = 1,
    val brakesLevel: Int = 1
)

@Entity(tableName = "career_results")
data class CareerResultEntity(
    @PrimaryKey val eventId: String,
    val bestPosition: Int,
    val stars: Int,
    val bestTimeMs: Long
)

@Entity(tableName = "track_best_laps")
data class TrackBestLapEntity(
    @PrimaryKey val trackId: String,
    val bestLapMs: Long,
    val carId: String
)

@Dao
interface PlayerProfileDao {
    @Query("SELECT * FROM player_profile WHERE id = 1")
    fun observeProfile(): Flow<PlayerProfileEntity?>

    @Query("SELECT * FROM player_profile WHERE id = 1")
    suspend fun getProfile(): PlayerProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(profile: PlayerProfileEntity)
}

@Dao
interface CarStateDao {
    @Query("SELECT * FROM car_states")
    fun observeAll(): Flow<List<CarStateEntity>>

    @Query("SELECT * FROM car_states WHERE carId = :carId")
    suspend fun getById(carId: String): CarStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(carState: CarStateEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllIgnore(carStates: List<CarStateEntity>)
}

@Dao
interface CareerResultDao {
    @Query("SELECT * FROM career_results")
    fun observeAll(): Flow<List<CareerResultEntity>>

    @Query("SELECT * FROM career_results WHERE eventId = :eventId")
    suspend fun getById(eventId: String): CareerResultEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(result: CareerResultEntity)
}

@Dao
interface TrackBestLapDao {
    @Query("SELECT * FROM track_best_laps")
    fun observeAll(): Flow<List<TrackBestLapEntity>>

    @Query("SELECT * FROM track_best_laps WHERE trackId = :trackId")
    suspend fun getByTrackId(trackId: String): TrackBestLapEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(record: TrackBestLapEntity)
}

@Database(
    entities = [
        PlayerProfileEntity::class,
        CarStateEntity::class,
        CareerResultEntity::class,
        TrackBestLapEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun playerProfileDao(): PlayerProfileDao
    abstract fun carStateDao(): CarStateDao
    abstract fun careerResultDao(): CareerResultDao
    abstract fun trackBestLapDao(): TrackBestLapDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "apex_velocity_offline.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
