package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.audio.SoundEngine
import com.example.data.GameSettings
import com.example.engine.DriverInput
import com.example.engine.RaceHudSnapshot
import com.example.engine.RacePhase
import com.example.engine.RaceSimulation
import com.example.graphics.RaceGLRenderer
import com.example.graphics.RaceGLView
import com.example.graphics.SceneRenderTarget
import com.example.input.TiltSteeringManager
import com.example.model.CameraMode
import com.example.model.CarCatalog
import com.example.model.CarUpgradeLevels
import com.example.model.GameMode
import com.example.model.RaceConfig
import com.example.model.RaceResult
import com.example.model.RacerStanding
import com.example.ui.components.TrackMinimap
import com.example.ui.components.formatRaceTime
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.ApexCrimson
import com.example.ui.theme.BorderGlass
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.ChampionshipGold
import com.example.ui.theme.DarkGlass
import com.example.ui.theme.ElevatedSteel
import com.example.ui.theme.GraphiteCard
import com.example.ui.theme.IceWhite
import com.example.ui.theme.MonoFont
import com.example.ui.theme.NitroCyan
import com.example.ui.theme.SilverText
import com.example.ui.theme.TelemetryEmerald
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun RaceScreen(
    config: RaceConfig,
    upgrades: CarUpgradeLevels,
    paintId: String,
    settings: GameSettings,
    renderer: RaceGLRenderer,
    soundEngine: SoundEngine,
    tiltManager: TiltSteeringManager,
    raceResult: RaceResult?,
    onHudUpdate: (RaceHudSnapshot) -> Unit,
    hudState: RaceHudSnapshot,
    onRaceCompleted: (Int, Long, Long, List<RacerStanding>) -> Unit,
    onQuitToMenu: () -> Unit
) {
    var restartNonce by remember { mutableIntStateOf(0) }
    var currentCamera by remember(settings.defaultCamera) { mutableStateOf(settings.defaultCamera) }

    val simulation = remember(config, restartNonce) {
        RaceSimulation(
            config = config,
            playerUpgrades = upgrades,
            playerPaintId = paintId
        )
    }

    // Touch input states (multi-touch safe)
    var steerLeftPressed by remember { mutableStateOf(false) }
    var steerRightPressed by remember { mutableStateOf(false) }
    var gasPressed by remember { mutableStateOf(false) }
    var brakePressed by remember { mutableStateOf(false) }
    var nitroPressed by remember { mutableStateOf(false) }
    var isPaused by remember { mutableStateOf(false) }

    // Wire renderer, audio callbacks, and tilt sensor
    LaunchedEffect(simulation) {
        isPaused = false
        renderer.graphicsQuality = settings.graphicsQuality
        renderer.cameraMode = currentCamera
        renderer.resetCameraState()
        renderer.renderTarget = SceneRenderTarget.Race(simulation)

        simulation.onCountdownTick = { soundEngine.playCountdownBeep(isGo = false) }
        simulation.onRaceGo = { soundEngine.playCountdownBeep(isGo = true) }
        simulation.onLapCompleted = { soundEngine.playLapChime() }
        simulation.onCollisionImpact = { soundEngine.playCollisionThud() }
        simulation.onRaceFinished = {
            val standings = simulation.computeStandings()
            val playerPos = standings.firstOrNull { it.isPlayer }?.position ?: 1
            val bestLap = if (simulation.player.bestLapMs > 0L) simulation.player.bestLapMs else simulation.raceElapsedMs
            onRaceCompleted(playerPos, simulation.raceElapsedMs, bestLap, standings)
        }
        onHudUpdate(simulation.buildHudSnapshot())
    }

    LaunchedEffect(currentCamera) {
        renderer.cameraMode = currentCamera
    }

    LaunchedEffect(settings.graphicsQuality) {
        renderer.graphicsQuality = settings.graphicsQuality
    }

    DisposableEffect(settings.tiltSteeringEnabled) {
        tiltManager.sensitivity = settings.tiltSensitivity
        if (settings.tiltSteeringEnabled && tiltManager.isSupported) {
            tiltManager.start()
        } else {
            tiltManager.stop()
        }
        onDispose {
            tiltManager.stop()
            soundEngine.activeRacing = false
        }
    }

    // Feed live player inputs & update procedural engine audio
    LaunchedEffect(
        steerLeftPressed, steerRightPressed, gasPressed, brakePressed, nitroPressed,
        hudState.rpmNormalized, hudState.nitroActive, hudState.isDrifting, hudState.phase
    ) {
        val touchSteer = when {
            steerLeftPressed && !steerRightPressed -> -1f
            steerRightPressed && !steerLeftPressed -> 1f
            else -> 0f
        }
        val finalSteer = if (settings.tiltSteeringEnabled && tiltManager.isSupported && touchSteer == 0f) {
            tiltManager.steerValue
        } else {
            touchSteer
        }

        simulation.playerInput = DriverInput(
            throttle = if (gasPressed) 1f else 0f,
            brake = if (brakePressed) 1f else 0f,
            steer = finalSteer,
            nitro = nitroPressed
        )

        soundEngine.activeRacing = hudState.phase == RacePhase.RACING
        soundEngine.rpmNormalized = hudState.rpmNormalized
        soundEngine.nitroActive = hudState.nitroActive
        soundEngine.drifting = hudState.isDrifting
    }

    BackHandler {
        if (hudState.phase == RacePhase.FINISHED) {
            onQuitToMenu()
        } else if (isPaused) {
            isPaused = false
            simulation.resume()
        } else {
            isPaused = true
            simulation.pause()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // 3D OpenGL ES Race Viewport
        RaceGLView(
            renderer = renderer,
            modifier = Modifier.fillMaxSize()
        )

        // Speed & Nitro Radial Speed-Lines Motion Effect
        if (hudState.speedKmh > 195 || hudState.nitroActive) {
            SpeedStreaksOverlay(
                intensity = if (hudState.nitroActive) 0.85f else ((hudState.speedKmh - 195) / 160f).coerceIn(0.15f, 0.55f),
                isNitro = hudState.nitroActive
            )
        }

        // Minimal Professional Racing HUD
        Box(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            // Top-Left: Position, Lap, Timers & Minimap
            Row(
                modifier = Modifier.align(Alignment.TopStart),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.Top
            ) {
                if (settings.showMinimap) {
                    TrackMinimap(
                        trackPoints = simulation.track.minimapPoints,
                        racerDots = hudState.racerMinimapDots
                    )
                }

                Surface(
                    color = DarkGlass,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, BorderGlass)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (config.mode == GameMode.CAREER || config.mode == GameMode.QUICK_RACE) {
                            Column {
                                Text("POS", style = MaterialTheme.typography.labelSmall, color = SilverText)
                                Text(
                                    text = "${hudState.position}/${hudState.totalRacers}",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = if (hudState.position == 1) ChampionshipGold else IceWhite
                                )
                            }
                            Column {
                                Text("LAP", style = MaterialTheme.typography.labelSmall, color = SilverText)
                                Text(
                                    text = "${hudState.currentLap}/${hudState.totalLaps}",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = IceWhite
                                )
                            }
                        } else {
                            Column {
                                Text("MODE", style = MaterialTheme.typography.labelSmall, color = NitroCyan)
                                Text(
                                    text = "${config.mode.label.uppercase(Locale.US)} • L${hudState.currentLap}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = IceWhite
                                )
                            }
                        }

                        Column {
                            Text("LAP TIME", style = MaterialTheme.typography.labelSmall, color = SilverText)
                            Text(
                                text = formatRaceTime(hudState.currentLapMs),
                                style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFont),
                                color = IceWhite
                            )
                            if (hudState.bestLapMs > 0L) {
                                Text(
                                    text = "BEST ${formatRaceTime(hudState.bestLapMs)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TelemetryEmerald
                                )
                            }
                        }
                    }
                }
            }

            // Top-Right: Camera Switch & Pause (+ Finish Session button for Practice/Time Trial)
            Row(
                modifier = Modifier.align(Alignment.TopEnd),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (config.mode == GameMode.PRACTICE || config.mode == GameMode.TIME_TRIAL) {
                    Surface(
                        color = DarkGlass,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, BorderGlass)
                    ) {
                        Button(
                            onClick = {
                                val bestLap = if (simulation.player.bestLapMs > 0L) simulation.player.bestLapMs else simulation.raceElapsedMs
                                onRaceCompleted(1, simulation.raceElapsedMs, bestLap, simulation.computeStandings())
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ApexCrimson),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(48.dp)
                        ) {
                            Text("FINISH", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }

                Surface(
                    color = DarkGlass,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, BorderGlass)
                ) {
                    IconButton(
                        onClick = {
                            val entries = CameraMode.entries
                            currentCamera = entries[(entries.indexOf(currentCamera) + 1) % entries.size]
                        },
                        modifier = Modifier
                            .height(48.dp)
                            .padding(horizontal = 6.dp)
                            .testTag("race_camera_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Filled.CameraAlt,
                                contentDescription = stringResource(R.string.cd_switch_camera),
                                tint = NitroCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(currentCamera.label.uppercase(Locale.US), style = MaterialTheme.typography.labelSmall, color = IceWhite)
                        }
                    }
                }

                Surface(
                    color = DarkGlass,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, BorderGlass)
                ) {
                    IconButton(
                        onClick = {
                            isPaused = true
                            simulation.pause()
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("race_pause_button")
                    ) {
                        Icon(
                            Icons.Filled.Pause,
                            contentDescription = stringResource(R.string.cd_pause_race),
                            tint = IceWhite
                        )
                    }
                }
            }

            // Center Countdown / GO! / Drift indicator
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (hudState.phase == RacePhase.COUNTDOWN) {
                    Text(
                        text = hudState.countdownValue.coerceAtLeast(1).toString(),
                        style = MaterialTheme.typography.displayLarge.copy(fontSize = 84.sp),
                        color = ChampionshipGold
                    )
                } else if (hudState.goBannerTimer > 0f) {
                    Text(
                        text = "GO!",
                        style = MaterialTheme.typography.displayLarge.copy(fontSize = 72.sp),
                        color = TelemetryEmerald
                    )
                } else if (hudState.isDrifting) {
                    Surface(
                        color = DarkGlass,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, AmberWarning)
                    ) {
                        Text(
                            text = "DRIFT +N2O",
                            style = MaterialTheme.typography.labelLarge,
                            color = AmberWarning,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Bottom-Center: Speedometer, Gear, RPM & Nitro Bar
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 2.dp),
                color = DarkGlass,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, BorderGlass)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "%03d".format(Locale.US, hudState.speedKmh),
                            style = MaterialTheme.typography.displayMedium.copy(fontFamily = MonoFont),
                            color = if (hudState.nitroActive) NitroCyan else IceWhite
                        )
                        Column {
                            Text("KM/H", style = MaterialTheme.typography.labelSmall, color = SilverText)
                            Text(
                                text = "G${hudState.gear}",
                                style = MaterialTheme.typography.labelLarge.copy(fontFamily = MonoFont),
                                color = ChampionshipGold
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    // RPM bar
                    Box(
                        modifier = Modifier
                            .width(150.dp)
                            .height(5.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(ElevatedSteel)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(hudState.rpmNormalized.coerceIn(0f, 1f))
                                .height(5.dp)
                                .background(if (hudState.rpmNormalized > 0.85f) ApexCrimson else TelemetryEmerald)
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    // Nitro gauge
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("N2O", style = MaterialTheme.typography.labelSmall, color = NitroCyan)
                        Spacer(Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .width(114.dp)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(ElevatedSteel)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth((hudState.nitroFuel / 100f).coerceIn(0f, 1f))
                                    .height(6.dp)
                                    .background(NitroCyan)
                            )
                        }
                    }
                }
            }

            // Bottom-Left: Steering Controls (or Tilt Status badge + emergency touch steer)
            Row(
                modifier = Modifier.align(Alignment.BottomStart),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                HoldTouchControlButton(
                    icon = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                    contentDescription = stringResource(R.string.cd_steer_left),
                    testTag = "control_steer_left",
                    isPressed = steerLeftPressed,
                    onPressChanged = { steerLeftPressed = it }
                )
                HoldTouchControlButton(
                    icon = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = stringResource(R.string.cd_steer_right),
                    testTag = "control_steer_right",
                    isPressed = steerRightPressed,
                    onPressChanged = { steerRightPressed = it }
                )
            }

            // Bottom-Right: Nitro, Brake, Gas Pedals
            Row(
                modifier = Modifier.align(Alignment.BottomEnd),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                HoldTouchPedal(
                    label = "N2O",
                    icon = Icons.Filled.Bolt,
                    contentDescription = stringResource(R.string.cd_nitro),
                    testTag = "control_nitro",
                    accent = NitroCyan,
                    widthDp = 64,
                    heightDp = 64,
                    isCircle = true,
                    isPressed = nitroPressed,
                    onPressChanged = { nitroPressed = it }
                )
                HoldTouchPedal(
                    label = "BRAKE",
                    icon = null,
                    contentDescription = stringResource(R.string.cd_brake),
                    testTag = "control_brake",
                    accent = ApexCrimson,
                    widthDp = 74,
                    heightDp = 82,
                    isCircle = false,
                    isPressed = brakePressed,
                    onPressChanged = { brakePressed = it }
                )
                HoldTouchPedal(
                    label = "GAS",
                    icon = null,
                    contentDescription = stringResource(R.string.cd_accelerate),
                    testTag = "control_gas",
                    accent = TelemetryEmerald,
                    widthDp = 82,
                    heightDp = 104,
                    isCircle = false,
                    isPressed = gasPressed,
                    onPressChanged = { gasPressed = it }
                )
            }
        }

        // Pause Modal Overlay
        if (isPaused && hudState.phase != RacePhase.FINISHED) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xBB05070B)),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    modifier = Modifier.width(340.dp),
                    color = GraphiteCard,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, BorderGlass)
                ) {
                    Column(
                        modifier = Modifier.padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("RACE PAUSED", style = MaterialTheme.typography.headlineMedium, color = IceWhite)
                        Button(
                            onClick = {
                                isPaused = false
                                simulation.resume()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ApexCrimson),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("pause_resume_button")
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.action_resume))
                        }
                        OutlinedButton(
                            onClick = {
                                isPaused = false
                                restartNonce++
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("pause_restart_button")
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, tint = IceWhite)
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.action_restart), color = IceWhite)
                        }
                        OutlinedButton(
                            onClick = onQuitToMenu,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("pause_quit_button")
                        ) {
                            Text(stringResource(R.string.action_quit_menu), color = SilverText)
                        }
                    }
                }
            }
        }

        // Post-Race Results Overlay
        if (raceResult != null) {
            RaceResultsOverlay(
                result = raceResult,
                onRestart = {
                    restartNonce++
                },
                onMainMenu = onQuitToMenu
            )
        }
    }
}

@Composable
private fun HoldTouchControlButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    testTag: String,
    isPressed: Boolean,
    onPressChanged: (Boolean) -> Unit
) {
    Surface(
        modifier = Modifier
            .size(72.dp)
            .pointerInput(testTag) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    onPressChanged(true)
                    do {
                        val event = awaitPointerEvent()
                    } while (event.changes.any { it.pressed })
                    onPressChanged(false)
                }
            }
            .testTag(testTag),
        color = if (isPressed) NitroCyan.copy(alpha = 0.45f) else DarkGlass,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.5.dp, if (isPressed) NitroCyan else BorderGlass)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = IceWhite,
                modifier = Modifier.size(38.dp)
            )
        }
    }
}

@Composable
private fun HoldTouchPedal(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector?,
    contentDescription: String,
    testTag: String,
    accent: Color,
    widthDp: Int,
    heightDp: Int,
    isCircle: Boolean,
    isPressed: Boolean,
    onPressChanged: (Boolean) -> Unit
) {
    val shape = if (isCircle) CircleShape else RoundedCornerShape(14.dp)
    Box(
        modifier = Modifier
            .width(widthDp.dp)
            .height(heightDp.dp)
            .clip(shape)
            .background(if (isPressed) accent.copy(alpha = 0.55f) else DarkGlass)
            .border(1.5.dp, if (isPressed) accent else accent.copy(alpha = 0.55f), shape)
            .pointerInput(testTag) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    onPressChanged(true)
                    do {
                        val event = awaitPointerEvent()
                    } while (event.changes.any { it.pressed })
                    onPressChanged(false)
                }
            }
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (icon != null) {
                Icon(icon, contentDescription = contentDescription, tint = IceWhite, modifier = Modifier.size(22.dp))
            }
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = IceWhite)
        }
    }
}

@Composable
private fun SpeedStreaksOverlay(intensity: Float, isNitro: Boolean) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val maxR = size.width * 0.65f
        val lineColor = if (isNitro) NitroCyan else Color.White
        for (i in 0 until 24) {
            val angle = (i / 24.0) * (2.0 * Math.PI)
            val cosA = cos(angle).toFloat()
            val sinA = sin(angle).toFloat()
            val inner = maxR * 0.62f
            val outer = maxR * 0.98f
            drawLine(
                color = lineColor.copy(alpha = intensity * 0.25f),
                start = Offset(cx + cosA * inner, cy + sinA * inner),
                end = Offset(cx + cosA * outer, cy + sinA * outer),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
private fun RaceResultsOverlay(
    result: RaceResult,
    onRestart: () -> Unit,
    onMainMenu: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xD905070B))
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .width(560.dp)
                .padding(16.dp),
            color = GraphiteCard,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, BorderGlass)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (result.config.mode == GameMode.CAREER || result.config.mode == GameMode.QUICK_RACE) {
                                "FINISHED P${result.playerPosition}"
                            } else {
                                "${result.config.mode.label.uppercase(Locale.US)} COMPLETE"
                            },
                            style = MaterialTheme.typography.displayMedium,
                            color = if (result.playerPosition == 1) ChampionshipGold else IceWhite
                        )
                        Text(
                            text = "Best Lap: ${formatRaceTime(result.bestLapMs)} • Total: ${formatRaceTime(result.totalTimeMs)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SilverText
                        )
                    }
                    Surface(
                        color = ElevatedSteel,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, NitroCyan)
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalAlignment = Alignment.End
                        ) {
                            Text("REWARD", style = MaterialTheme.typography.labelSmall, color = NitroCyan)
                            Text(
                                text = "+%,d CR".format(Locale.US, result.creditsEarned),
                                style = MaterialTheme.typography.titleMedium,
                                color = ChampionshipGold
                            )
                        }
                    }
                }

                if (result.isNewTrackRecord) {
                    Text(
                        text = "NEW TRACK LAP RECORD! (+350 CR BONUS)",
                        style = MaterialTheme.typography.labelLarge,
                        color = TelemetryEmerald
                    )
                }
                if (result.newlyUnlockedCarId != null) {
                    val unlocked = CarCatalog.findById(result.newlyUnlockedCarId)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = ChampionshipGold, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "NEW SUPERCAR UNLOCKED: ${unlocked.name.uppercase(Locale.US)}!",
                            style = MaterialTheme.typography.labelLarge,
                            color = ChampionshipGold
                        )
                    }
                }

                // Standings table
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    result.standings.forEach { row ->
                        Surface(
                            color = if (row.isPlayer) ApexCrimson.copy(alpha = 0.25f) else ElevatedSteel.copy(alpha = 0.55f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 7.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${row.position}. ${row.name} (${row.carName})",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = IceWhite
                                )
                                Text(
                                    text = formatRaceTime(row.finishTimeMs),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (row.isPlayer) NitroCyan else SilverText
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onRestart,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("results_restart_button")
                    ) {
                        Text(stringResource(R.string.action_restart), color = IceWhite)
                    }
                    Button(
                        onClick = onMainMenu,
                        colors = ButtonDefaults.buttonColors(containerColor = ApexCrimson),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("results_menu_button")
                    ) {
                        Text(stringResource(R.string.action_quit_menu))
                    }
                }
            }
        }
    }
}
