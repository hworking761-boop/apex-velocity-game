package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val ApexDarkColorScheme = darkColorScheme(
    primary = ApexCrimson,
    onPrimary = IceWhite,
    primaryContainer = ApexCrimsonDark,
    onPrimaryContainer = IceWhite,
    secondary = NitroCyan,
    onSecondary = CarbonBlack,
    secondaryContainer = ElevatedSteel,
    onSecondaryContainer = NitroCyan,
    tertiary = ChampionshipGold,
    onTertiary = CarbonBlack,
    background = CarbonBlack,
    onBackground = IceWhite,
    surface = ObsidianSurface,
    onSurface = IceWhite,
    surfaceVariant = GraphiteCard,
    onSurfaceVariant = SilverText,
    outline = BorderGlass,
    error = ApexCrimson
)

val ApexShapes = Shapes(
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(10.dp),
    large = RoundedCornerShape(16.dp)
)

@Composable
fun ApexVelocityTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ApexDarkColorScheme,
        typography = ApexTypography,
        shapes = ApexShapes,
        content = content
    )
}
