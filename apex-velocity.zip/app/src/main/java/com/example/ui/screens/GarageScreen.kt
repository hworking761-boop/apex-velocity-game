package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.GarageCarSnapshot
import com.example.data.PlayerProfileEntity
import com.example.graphics.RaceGLRenderer
import com.example.graphics.RaceGLView
import com.example.graphics.SceneRenderTarget
import com.example.model.CarCatalog
import com.example.model.CarUpgradeLevels
import com.example.model.PaintCatalog
import com.example.model.UpgradeCategory
import com.example.ui.components.StatMeterBar
import com.example.ui.components.TopTelemetryBar
import com.example.ui.theme.ApexCrimson
import com.example.ui.theme.BorderGlass
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.ChampionshipGold
import com.example.ui.theme.DarkGlass
import com.example.ui.theme.ElevatedSteel
import com.example.ui.theme.GraphiteCard
import com.example.ui.theme.IceWhite
import com.example.ui.theme.NitroCyan
import com.example.ui.theme.SilverText
import com.example.ui.theme.TelemetryEmerald
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
fun GarageScreen(
    renderer: RaceGLRenderer,
    profile: PlayerProfileEntity,
    garageCars: Map<String, GarageCarSnapshot>,
    browsedCarId: String,
    totalStars: Int,
    initialUpgradesTab: Boolean,
    feedbackMessage: String?,
    onClearFeedback: () -> Unit,
    onBrowseCar: (String) -> Unit,
    onSelectCar: (String) -> Unit,
    onPurchaseCar: (String) -> Unit,
    onSelectPaint: (String, String) -> Unit,
    onUpgradeCar: (String, UpgradeCategory) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    var selectedTab by remember(initialUpgradesTab) { mutableIntStateOf(if (initialUpgradesTab) 1 else 0) }
    val carSpec = CarCatalog.findById(browsedCarId)
    val snapshot = garageCars[carSpec.id]
    val isUnlocked = snapshot?.unlocked ?: (carSpec.unlockCost == 0)
    val isEquipped = profile.selectedCarId == carSpec.id
    val paintId = snapshot?.paintId ?: carSpec.defaultPaintId
    val upgrades = snapshot?.upgrades ?: CarUpgradeLevels()
    val carTierIndex = CarCatalog.cars.indexOfFirst { it.id == carSpec.id }.coerceAtLeast(0)
    val pi = carSpec.basePerformanceIndex + upgrades.totalRatingBonus

    LaunchedEffect(carSpec.id, paintId) {
        renderer.showroomDistance = 4.9f
        renderer.renderTarget = SceneRenderTarget.Showroom(
            carId = carSpec.id,
            paintId = paintId,
            autoRotate = false
        )
    }

    LaunchedEffect(feedbackMessage) {
        if (feedbackMessage != null) {
            delay(2000L)
            onClearFeedback()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Fullscreen interactive 3D car preview (swipe to orbit 360°)
        RaceGLView(
            renderer = renderer,
            modifier = Modifier.fillMaxSize(),
            enableOrbitTouch = true
        )

        // Right-side gradient for clear spec readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        0.0f to Color.Transparent,
                        0.50f to Color(0x3307090E),
                        0.68f to Color(0xDD07090E),
                        1.0f to Color(0xF207090E)
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            TopTelemetryBar(
                title = "Garage & Tuning",
                credits = profile.credits,
                totalStars = totalStars,
                onBack = onBack,
                backTestTag = "garage_back_button"
            )

            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left area: 3D car angle presets & feedback toast
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(bottom = 10.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("3/4 Front" to 38f, "Side" to 90f, "Rear" to 150f).forEach { (label, yaw) ->
                            Surface(
                                color = DarkGlass,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, BorderGlass),
                                modifier = Modifier.clickable {
                                    renderer.showroomYawDeg = yaw
                                    renderer.showroomPitchDeg = 13f
                                }
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = IceWhite,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (feedbackMessage != null) {
                            Surface(
                                color = NitroCyan,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = feedbackMessage,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = CarbonBlack,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                        Surface(
                            color = DarkGlass,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, BorderGlass)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "${carSpec.manufacturer.uppercase(Locale.US)} • ${carSpec.categoryClass}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NitroCyan
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = carSpec.name.uppercase(Locale.US),
                                        style = MaterialTheme.typography.headlineMedium,
                                        color = IceWhite
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Surface(color = ApexCrimson, shape = RoundedCornerShape(6.dp)) {
                                        Text(
                                            text = "PI $pi",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = IceWhite,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.width(12.dp))

                // Right Panel: Specs / Paint / Upgrades
                Surface(
                    modifier = Modifier
                        .width(340.dp)
                        .fillMaxHeight()
                        .padding(bottom = 8.dp),
                    color = DarkGlass,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderGlass)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp)
                    ) {
                        // Tab Switcher
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedTab = 0 }
                                    .testTag("garage_tab_specs"),
                                color = if (selectedTab == 0) ApexCrimson else ElevatedSteel,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Filled.Palette, contentDescription = null, tint = IceWhite, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("PAINT & SPECS", style = MaterialTheme.typography.labelSmall, color = IceWhite)
                                }
                            }
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedTab = 1 }
                                    .testTag("garage_tab_upgrades"),
                                color = if (selectedTab == 1) ApexCrimson else ElevatedSteel,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Filled.Build, contentDescription = null, tint = IceWhite, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("UPGRADES", style = MaterialTheme.typography.labelSmall, color = IceWhite)
                                }
                            }
                        }

                        Spacer(Modifier.height(10.dp))

                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (selectedTab == 0) {
                                Text(
                                    text = carSpec.description,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = SilverText
                                )
                                StatMeterBar(
                                    label = "Top Speed",
                                    valueNormalized = carSpec.speedStatNormalized(upgrades),
                                    displayValue = "${carSpec.effectiveTopSpeedKmh(upgrades).toInt()} km/h",
                                    accentColor = ApexCrimson
                                )
                                StatMeterBar(
                                    label = "Acceleration",
                                    valueNormalized = carSpec.accelStatNormalized(upgrades),
                                    displayValue = "%.1f".format(Locale.US, carSpec.effectiveAcceleration(upgrades)),
                                    accentColor = NitroCyan
                                )
                                StatMeterBar(
                                    label = "Handling & Grip",
                                    valueNormalized = carSpec.handlingStatNormalized(upgrades),
                                    displayValue = "%.2f G".format(Locale.US, carSpec.effectiveHandling(upgrades)),
                                    accentColor = TelemetryEmerald
                                )
                                StatMeterBar(
                                    label = "Braking",
                                    valueNormalized = carSpec.brakingStatNormalized(upgrades),
                                    displayValue = "${carSpec.effectiveBraking(upgrades).toInt()}",
                                    accentColor = ChampionshipGold
                                )

                                Spacer(Modifier.height(4.dp))
                                Text("METALLIC FINISH", style = MaterialTheme.typography.labelSmall, color = NitroCyan)
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(PaintCatalog.finishes, key = { it.id }) { finish ->
                                        val isActivePaint = finish.id == paintId
                                        Box(
                                            modifier = Modifier
                                                .size(34.dp)
                                                .clip(CircleShape)
                                                .background(Color(finish.hexRgb))
                                                .border(
                                                    width = if (isActivePaint) 2.5.dp else 1.dp,
                                                    color = if (isActivePaint) IceWhite else BorderGlass,
                                                    shape = CircleShape
                                                )
                                                .clickable { onSelectPaint(carSpec.id, finish.id) }
                                                .testTag("paint_${finish.id}"),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (isActivePaint) {
                                                Icon(
                                                    Icons.Filled.Check,
                                                    contentDescription = finish.name,
                                                    tint = if (finish.id == "pearl_white" || finish.id == "arctic_silver") CarbonBlack else IceWhite,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            } else {
                                UpgradeCategory.entries.forEach { category ->
                                    val lvl = upgrades.levelFor(category)
                                    val isMax = lvl >= CarUpgradeLevels.MAX_UPGRADE_LEVEL
                                    val cost = CarUpgradeLevels.upgradeCost(lvl, carTierIndex)
                                    Surface(
                                        color = GraphiteCard,
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, BorderGlass)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(category.label, style = MaterialTheme.typography.labelLarge, color = IceWhite)
                                                Text(category.shortDesc, style = MaterialTheme.typography.bodyMedium, color = SilverText)
                                                Spacer(Modifier.height(4.dp))
                                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    for (p in 1..CarUpgradeLevels.MAX_UPGRADE_LEVEL) {
                                                        Box(
                                                            modifier = Modifier
                                                                .width(22.dp)
                                                                .height(5.dp)
                                                                .clip(RoundedCornerShape(2.dp))
                                                                .background(if (p <= lvl) NitroCyan else ElevatedSteel)
                                                        )
                                                    }
                                                }
                                            }
                                            Spacer(Modifier.width(8.dp))
                                            Button(
                                                onClick = { onUpgradeCar(carSpec.id, category) },
                                                enabled = isUnlocked && !isMax && profile.credits >= cost,
                                                colors = ButtonDefaults.buttonColors(containerColor = ApexCrimson),
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                                modifier = Modifier.testTag("upgrade_${category.name}")
                                            ) {
                                                Text(
                                                    text = if (isMax) "MAX" else "$cost CR",
                                                    style = MaterialTheme.typography.labelSmall
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(Modifier.height(8.dp))
                        // Primary Car Action CTA
                        Button(
                            onClick = {
                                if (isUnlocked) onSelectCar(carSpec.id) else onPurchaseCar(carSpec.id)
                            },
                            enabled = !isEquipped && (isUnlocked || profile.credits >= carSpec.unlockCost),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isEquipped) TelemetryEmerald else ApexCrimson
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("garage_primary_cta")
                        ) {
                            Text(
                                text = when {
                                    isEquipped -> "SELECTED FOR RACE"
                                    isUnlocked -> "SELECT VEHICLE"
                                    else -> "UNLOCK FOR %,d CR".format(Locale.US, carSpec.unlockCost)
                                },
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }

            // Bottom 5-Supercar Carousel
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(CarCatalog.cars, key = { it.id }) { car ->
                    val snap = garageCars[car.id]
                    val unlocked = snap?.unlocked ?: (car.unlockCost == 0)
                    val selected = car.id == browsedCarId
                    val equipped = car.id == profile.selectedCarId
                    Surface(
                        modifier = Modifier
                            .width(176.dp)
                            .clickable { onBrowseCar(car.id) }
                            .testTag("car_tile_${car.id}"),
                        color = if (selected) ElevatedSteel else DarkGlass,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(
                            width = if (selected) 2.dp else 1.dp,
                            color = if (selected) ApexCrimson else BorderGlass
                        )
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = car.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = IceWhite,
                                    maxLines = 1
                                )
                                if (!unlocked) {
                                    Icon(Icons.Filled.Lock, contentDescription = "Locked", tint = ChampionshipGold, modifier = Modifier.size(15.dp))
                                } else if (equipped) {
                                    Icon(Icons.Filled.Check, contentDescription = "Equipped", tint = TelemetryEmerald, modifier = Modifier.size(16.dp))
                                }
                            }
                            Text(
                                text = if (unlocked) "PI ${car.basePerformanceIndex + (snap?.upgrades?.totalRatingBonus ?: 0)}" else "%,d CR".format(Locale.US, car.unlockCost),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (unlocked) NitroCyan else ChampionshipGold
                            )
                        }
                    }
                }
            }
        }
    }
}
