package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.CareerResultEntity
import com.example.data.GamePreferencesRepository
import com.example.data.GameRepository
import com.example.data.GameSettings
import com.example.data.GarageCarSnapshot
import com.example.data.PlayerProfileEntity
import com.example.data.TrackBestLapEntity
import com.example.model.CameraMode
import com.example.model.CarCatalog
import com.example.model.CarUpgradeLevels
import com.example.model.CareerCatalog
import com.example.model.Difficulty
import com.example.model.GameMode
import com.example.model.GraphicsQuality
import com.example.model.RaceConfig
import com.example.model.RaceResult
import com.example.model.RacerStanding
import com.example.model.TrackCatalog
import com.example.model.UpgradeCategory
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getInstance(application)
    private val prefsRepo = GamePreferencesRepository(application)
    private val repo = GameRepository(db, prefsRepo)

    private val _isInitialized = MutableStateFlow(false)
    val isInitialized: StateFlow<Boolean> = _isInitialized.asStateFlow()

    val profile: StateFlow<PlayerProfileEntity> = repo.profileFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PlayerProfileEntity())

    val garageCars: StateFlow<Map<String, GarageCarSnapshot>> = repo.garageCarsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val careerResults: StateFlow<Map<String, CareerResultEntity>> = repo.careerResultsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val bestLaps: StateFlow<Map<String, TrackBestLapEntity>> = repo.bestLapsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val settings: StateFlow<GameSettings> = prefsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), GameSettings())

    private val _browsedCarId = MutableStateFlow(CarCatalog.cars.first().id)
    val browsedCarId: StateFlow<String> = _browsedCarId.asStateFlow()

    private val _activeRaceConfig = MutableStateFlow<RaceConfig?>(null)
    val activeRaceConfig: StateFlow<RaceConfig?> = _activeRaceConfig.asStateFlow()

    private val _lastRaceResult = MutableStateFlow<RaceResult?>(null)
    val lastRaceResult: StateFlow<RaceResult?> = _lastRaceResult.asStateFlow()

    private val _garageFeedback = MutableStateFlow<String?>(null)
    val garageFeedback: StateFlow<String?> = _garageFeedback.asStateFlow()

    init {
        viewModelScope.launch {
            repo.ensureInitialized()
            val prof = repo.profileFlow.first()
            _browsedCarId.value = prof.selectedCarId
            delay(450L) // Brief engine & asset warm-up display
            _isInitialized.value = true
        }
    }

    fun browseCar(carId: String) {
        _browsedCarId.value = carId
    }

    fun selectCar(carId: String) {
        viewModelScope.launch {
            if (repo.selectCar(carId)) {
                _browsedCarId.value = carId
                _garageFeedback.value = "${CarCatalog.findById(carId).name} selected"
            }
        }
    }

    fun purchaseCar(carId: String) {
        viewModelScope.launch {
            val spec = CarCatalog.findById(carId)
            if (repo.purchaseCar(carId)) {
                _browsedCarId.value = carId
                _garageFeedback.value = "Unlocked ${spec.name}!"
            } else {
                _garageFeedback.value = "Need ${spec.unlockCost} CR to unlock"
            }
        }
    }

    fun setCarPaint(carId: String, paintId: String) {
        viewModelScope.launch {
            repo.setCarPaint(carId, paintId)
        }
    }

    fun upgradeCar(carId: String, category: UpgradeCategory) {
        viewModelScope.launch {
            if (repo.upgradeCar(carId, category)) {
                _garageFeedback.value = "${category.label} upgraded!"
            } else {
                _garageFeedback.value = "Insufficient credits or max level"
            }
        }
    }

    fun clearGarageFeedback() {
        _garageFeedback.value = null
    }

    fun startQuickPlayNow(): RaceConfig {
        val selectedCar = profile.value.selectedCarId
        val totalStars = careerResults.value.values.sumOf { it.stars }
        val nextCareer = CareerCatalog.events.firstOrNull { ev ->
            totalStars >= ev.requiredPreviousStars && (careerResults.value[ev.id]?.stars ?: 0) == 0
        }
        val config = if (nextCareer != null) {
            RaceConfig(
                mode = GameMode.CAREER,
                trackId = nextCareer.trackId,
                timeOfDay = nextCareer.timeOfDay,
                carId = selectedCar,
                laps = nextCareer.laps,
                difficulty = nextCareer.difficulty,
                careerEventId = nextCareer.id
            )
        } else {
            val track = TrackCatalog.tracks.first()
            RaceConfig(
                mode = GameMode.QUICK_RACE,
                trackId = track.id,
                timeOfDay = track.defaultTimeOfDay,
                carId = selectedCar,
                laps = 3,
                difficulty = Difficulty.PRO
            )
        }
        _lastRaceResult.value = null
        _activeRaceConfig.value = config
        return config
    }

    fun prepareRace(config: RaceConfig) {
        _lastRaceResult.value = null
        _activeRaceConfig.value = config
    }

    fun getCurrentCarUpgrades(carId: String): CarUpgradeLevels =
        garageCars.value[carId]?.upgrades ?: CarUpgradeLevels()

    fun getCurrentCarPaintId(carId: String): String =
        garageCars.value[carId]?.paintId ?: CarCatalog.findById(carId).defaultPaintId

    fun recordRaceFinished(
        config: RaceConfig,
        playerPosition: Int,
        totalTimeMs: Long,
        bestLapMs: Long,
        standings: List<RacerStanding>
    ) {
        viewModelScope.launch {
            val result = repo.recordRaceCompletion(
                config = config,
                playerPosition = playerPosition,
                totalTimeMs = totalTimeMs,
                bestLapMs = bestLapMs,
                standings = standings
            )
            _lastRaceResult.value = result
        }
    }

    fun clearRaceResult() {
        _lastRaceResult.value = null
    }

    fun setGraphicsQuality(quality: GraphicsQuality) {
        viewModelScope.launch { prefsRepo.setGraphicsQuality(quality) }
    }

    fun setTiltSteeringEnabled(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.setTiltSteeringEnabled(enabled) }
    }

    fun setTiltSensitivity(sensitivity: Float) {
        viewModelScope.launch { prefsRepo.setTiltSensitivity(sensitivity) }
    }

    fun setSoundEnabled(enabled: Boolean) {
        viewModelScope.launch { prefsRepo.setSoundEnabled(enabled) }
    }

    fun setSoundVolume(volume: Float) {
        viewModelScope.launch { prefsRepo.setSoundVolume(volume) }
    }

    fun setDefaultCamera(camera: CameraMode) {
        viewModelScope.launch { prefsRepo.setDefaultCamera(camera) }
    }

    fun setShowMinimap(show: Boolean) {
        viewModelScope.launch { prefsRepo.setShowMinimap(show) }
    }
}
