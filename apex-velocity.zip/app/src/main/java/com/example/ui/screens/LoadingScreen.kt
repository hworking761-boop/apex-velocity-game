package com.example.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.ApexCrimson
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.ElevatedSteel
import com.example.ui.theme.IceWhite
import com.example.ui.theme.NitroCyan
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.SilverText

@Composable
fun LoadingScreen() {
    val infinite = rememberInfiniteTransition(label = "loading_pulse")
    val pulse by infinite.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse),
        label = "alpha"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(ObsidianSurface, CarbonBlack)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(32.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Speed,
                    contentDescription = null,
                    tint = ApexCrimson.copy(alpha = pulse),
                    modifier = Modifier.size(44.dp)
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    text = "APEX VELOCITY",
                    style = MaterialTheme.typography.displayLarge,
                    color = IceWhite
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = stringResource(R.string.tagline_subtitle),
                style = MaterialTheme.typography.labelLarge,
                color = NitroCyan
            )
            Spacer(Modifier.height(28.dp))
            LinearProgressIndicator(
                modifier = Modifier
                    .width(280.dp)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = ApexCrimson,
                trackColor = ElevatedSteel
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = stringResource(R.string.loading_engine),
                style = MaterialTheme.typography.labelSmall,
                color = SilverText
            )
        }
    }
}
