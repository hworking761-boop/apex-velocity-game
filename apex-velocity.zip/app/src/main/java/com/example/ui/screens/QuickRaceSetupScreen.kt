package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.PlayerProfileEntity
import com.example.data.TrackBestLapEntity
import com.example.model.CarCatalog
import com.example.model.Difficulty
import com.example.model.GameMode
import com.example.model.RaceConfig
import com.example.model.TimeOfDay
import com.example.model.TrackCatalog
import com.example.ui.components.TopTelemetryBar
import com.example.ui.components.formatRaceTime
import com.example.ui.theme.ApexCrimson
import com.example.ui.theme.BorderGlass
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.ChampionshipGold
import com.example.ui.theme.ElevatedSteel
import com.example.ui.theme.GraphiteCard
import com.example.ui.theme.IceWhite
import com.example.ui.theme.NitroCyan
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.SilverText
import java.util.Locale

@Composable
fun QuickRaceSetupScreen(
    initialMode: GameMode,
    profile: PlayerProfileEntity,
    bestLaps: Map<String, TrackBestLapEntity>,
    totalStars: Int,
    onBack: () -> Unit,
    onOpenGarage: () -> Unit,
    onStartRace: (RaceConfig) -> Unit
) {
    BackHandler(onBack = onBack)

    var selectedMode by remember(initialMode) {
        mutableStateOf(if (initialMode == GameMode.CAREER) GameMode.QUICK_RACE else initialMode)
    }
    var selectedTrackId by remember { mutableStateOf(TrackCatalog.tracks.first().id) }
    val selectedTrack = TrackCatalog.findById(selectedTrackId)
    var selectedTimeOfDay by remember(selectedTrackId) { mutableStateOf(selectedTrack.defaultTimeOfDay) }
    var laps by remember { mutableIntStateOf(3) }
    var difficulty by remember { mutableStateOf(Difficulty.PRO) }

    val activeCar = CarCatalog.findById(profile.selectedCarId)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(ObsidianSurface, CarbonBlack)))
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            TopTelemetryBar(
                title = "Event Setup",
                credits = profile.credits,
                totalStars = totalStars,
                onBack = onBack,
                backTestTag = "setup_back_button"
            )

            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Left: Track list
                LazyColumn(
                    modifier = Modifier
                        .weight(1.15f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 12.dp)
                ) {
                    items(TrackCatalog.tracks, key = { it.id }) { track ->
                        val isSelected = track.id == selectedTrackId
                        val best = bestLaps[track.id]
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedTrackId = track.id
                                    selectedTimeOfDay = track.defaultTimeOfDay
                                }
                                .testTag("track_card_${track.id}"),
                            color = if (isSelected) ElevatedSteel else GraphiteCard,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) Color(track.accentHex) else BorderGlass
                            )
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = track.name.uppercase(Locale.US),
                                        style = MaterialTheme.typography.titleMedium,
                                        color = IceWhite
                                    )
                                    Text(
                                        text = "${track.lengthLabel} • ${track.difficultyLabel}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(track.accentHex)
                                    )
                                }
                                Spacer(Modifier.height(3.dp))
                                Text(
                                    text = track.location,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SilverText
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = track.description,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = SilverText
                                )
                                if (best != null) {
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        text = "Track Record: ${formatRaceTime(best.bestLapMs)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = ChampionshipGold
                                    )
                                }
                            }
                        }
                    }
                }

                // Right: Mode, Time of Day, Laps, Difficulty, Launch
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    color = GraphiteCard,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderGlass)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("GAME MODE", style = MaterialTheme.typography.labelSmall, color = NitroCyan)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(GameMode.QUICK_RACE, GameMode.TIME_TRIAL, GameMode.PRACTICE).forEach { mode ->
                                    FilterChip(
                                        selected = selectedMode == mode,
                                        onClick = { selectedMode = mode },
                                        label = { Text(mode.label, style = MaterialTheme.typography.labelSmall) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = ApexCrimson,
                                            selectedLabelColor = IceWhite
                                        ),
                                        modifier = Modifier.testTag("mode_chip_${mode.name}")
                                    )
                                }
                            }

                            Text("LIGHTING / TIME OF DAY", style = MaterialTheme.typography.labelSmall, color = NitroCyan)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                TimeOfDay.entries.forEach { tod ->
                                    FilterChip(
                                        selected = selectedTimeOfDay == tod,
                                        onClick = { selectedTimeOfDay = tod },
                                        label = { Text(tod.label, style = MaterialTheme.typography.labelSmall) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = NitroCyan,
                                            selectedLabelColor = CarbonBlack
                                        )
                                    )
                                }
                            }

                            if (selectedMode == GameMode.QUICK_RACE) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("LAPS", style = MaterialTheme.typography.labelSmall, color = NitroCyan)
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            listOf(2, 3, 5).forEach { count ->
                                                FilterChip(
                                                    selected = laps == count,
                                                    onClick = { laps = count },
                                                    label = { Text("$count") }
                                                )
                                            }
                                        }
                                    }
                                    Column(modifier = Modifier.weight(1.3f)) {
                                        Text("AI DIFFICULTY", style = MaterialTheme.typography.labelSmall, color = NitroCyan)
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Difficulty.entries.forEach { diff ->
                                                FilterChip(
                                                    selected = difficulty == diff,
                                                    onClick = { difficulty = diff },
                                                    label = { Text(diff.label, style = MaterialTheme.typography.labelSmall) }
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(onClick = onOpenGarage),
                                color = ElevatedSteel,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, BorderGlass)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("SELECTED VEHICLE", style = MaterialTheme.typography.labelSmall, color = SilverText)
                                        Text(activeCar.name, style = MaterialTheme.typography.titleMedium, color = IceWhite)
                                    }
                                    Text("CHANGE IN GARAGE", style = MaterialTheme.typography.labelSmall, color = NitroCyan)
                                }
                            }
                        }

                        Button(
                            onClick = {
                                onStartRace(
                                    RaceConfig(
                                        mode = selectedMode,
                                        trackId = selectedTrackId,
                                        timeOfDay = selectedTimeOfDay,
                                        carId = activeCar.id,
                                        laps = laps,
                                        difficulty = difficulty
                                    )
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ApexCrimson),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("start_race_button")
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.action_start_race),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }
    }
}
