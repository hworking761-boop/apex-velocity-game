package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Motorsport Dark Carbon & Racing Telemetry Palette
val CarbonBlack = Color(0xFF07090E)
val ObsidianSurface = Color(0xFF0E131D)
val GraphiteCard = Color(0xFF161D2B)
val ElevatedSteel = Color(0xFF212B3D)

val ApexCrimson = Color(0xFFFF2A4B)
val ApexCrimsonDark = Color(0xFFB8122E)
val NitroCyan = Color(0xFF00E5FF)
val NitroBlue = Color(0xFF0091EA)
val ChampionshipGold = Color(0xFFFFC400)
val TelemetryEmerald = Color(0xFF00E676)
val AmberWarning = Color(0xFFFF9100)

val IceWhite = Color(0xFFF4F7FB)
val SilverText = Color(0xFFA7B3C7)
val MutedSteel = Color(0xFF6B7890)
val BorderGlass = Color(0x33FFFFFF)
val DarkGlass = Color(0xCC0A0E17)
