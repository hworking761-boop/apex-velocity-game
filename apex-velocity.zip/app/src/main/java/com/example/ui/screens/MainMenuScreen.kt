package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.GarageCarSnapshot
import com.example.data.PlayerProfileEntity
import com.example.graphics.RaceGLRenderer
import com.example.graphics.RaceGLView
import com.example.graphics.SceneRenderTarget
import com.example.model.CarCatalog
import com.example.model.CarUpgradeLevels
import com.example.model.GameMode
import com.example.ui.components.RacingMenuButton
import com.example.ui.components.TelemetryPill
import com.example.ui.theme.ApexCrimson
import com.example.ui.theme.BorderGlass
import com.example.ui.theme.ChampionshipGold
import com.example.ui.theme.DarkGlass
import com.example.ui.theme.IceWhite
import com.example.ui.theme.NitroCyan
import com.example.ui.theme.SilverText
import java.util.Locale

@Composable
fun MainMenuScreen(
    renderer: RaceGLRenderer,
    profile: PlayerProfileEntity,
    garageCars: Map<String, GarageCarSnapshot>,
    totalStars: Int,
    onPlayNow: () -> Unit,
    onCareer: () -> Unit,
    onQuickRace: (GameMode) -> Unit,
    onGarage: (openUpgradesTab: Boolean) -> Unit,
    onSettings: () -> Unit
) {
    val activeCar = CarCatalog.findById(profile.selectedCarId)
    val carSnapshot = garageCars[activeCar.id]
    val activePaintId = carSnapshot?.paintId ?: activeCar.defaultPaintId
    val upgrades = carSnapshot?.upgrades ?: CarUpgradeLevels()
    val pi = activeCar.basePerformanceIndex + upgrades.totalRatingBonus

    LaunchedEffect(activeCar.id, activePaintId) {
        renderer.showroomDistance = 5.2f
        renderer.showroomPitchDeg = 13f
        renderer.renderTarget = SceneRenderTarget.Showroom(
            carId = activeCar.id,
            paintId = activePaintId,
            autoRotate = true
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Live 3D Supercar Turntable Backdrop
        RaceGLView(
            renderer = renderer,
            modifier = Modifier.fillMaxSize(),
            enableOrbitTouch = true
        )

        // Subtle left vignette gradient for crisp menu readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        0.0f to Color(0xE607090E),
                        0.40f to Color(0xB307090E),
                        0.72f to Color(0x1807090E),
                        1.0f to Color(0x3307090E)
                    )
                )
        )

        Row(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left Command Rail
            Column(
                modifier = Modifier
                    .width(290.dp)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "APEX VELOCITY",
                        style = MaterialTheme.typography.displayMedium,
                        color = IceWhite
                    )
                    Text(
                        text = "OFFLINE 3D STREET CHAMPIONSHIP",
                        style = MaterialTheme.typography.labelSmall,
                        color = ApexCrimson
                    )
                }

                Spacer(Modifier.height(8.dp))

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    RacingMenuButton(
                        label = stringResource(R.string.action_play),
                        subtitle = "Jump into next race",
                        icon = Icons.Filled.PlayArrow,
                        onClick = onPlayNow,
                        testTag = "menu_play_button",
                        accent = true
                    )
                    RacingMenuButton(
                        label = stringResource(R.string.action_career),
                        icon = Icons.Filled.EmojiEvents,
                        onClick = onCareer,
                        testTag = "menu_career_button"
                    )
                    RacingMenuButton(
                        label = stringResource(R.string.action_quick_race),
                        icon = Icons.Filled.Flag,
                        onClick = { onQuickRace(GameMode.QUICK_RACE) },
                        testTag = "menu_quick_race_button"
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        RacingMenuButton(
                            label = stringResource(R.string.action_time_trial),
                            icon = Icons.Filled.Timer,
                            onClick = { onQuickRace(GameMode.TIME_TRIAL) },
                            testTag = "menu_time_trial_button",
                            modifier = Modifier.weight(1f)
                        )
                        RacingMenuButton(
                            label = stringResource(R.string.action_practice),
                            icon = Icons.Filled.Speed,
                            onClick = { onQuickRace(GameMode.PRACTICE) },
                            testTag = "menu_practice_button",
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        RacingMenuButton(
                            label = stringResource(R.string.action_garage),
                            icon = Icons.Filled.DirectionsCar,
                            onClick = { onGarage(false) },
                            testTag = "menu_garage_button",
                            modifier = Modifier.weight(1f)
                        )
                        RacingMenuButton(
                            label = stringResource(R.string.action_upgrades),
                            icon = Icons.Filled.Build,
                            onClick = { onGarage(true) },
                            testTag = "menu_upgrades_button",
                            modifier = Modifier.weight(1f)
                        )
                    }
                    RacingMenuButton(
                        label = stringResource(R.string.action_settings),
                        icon = Icons.Filled.Settings,
                        onClick = onSettings,
                        testTag = "menu_settings_button"
                    )
                }
            }

            // Right side: Top Telemetry + Bottom Active Supercar Card
            Column(
                modifier = Modifier.fillMaxHeight(),
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TelemetryPill(
                        icon = Icons.Filled.EmojiEvents,
                        iconTint = ChampionshipGold,
                        text = "$totalStars ★"
                    )
                    TelemetryPill(
                        icon = Icons.Filled.Speed,
                        iconTint = NitroCyan,
                        text = "%,d CR".format(Locale.US, profile.credits)
                    )
                }

                Surface(
                    color = DarkGlass,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderGlass)
                ) {
                    Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
                        Text(
                            text = activeCar.categoryClass,
                            style = MaterialTheme.typography.labelSmall,
                            color = NitroCyan
                        )
                        Spacer(Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = activeCar.name.uppercase(Locale.US),
                                style = MaterialTheme.typography.headlineMedium,
                                color = IceWhite
                            )
                            Spacer(Modifier.width(12.dp))
                            Surface(
                                color = ApexCrimson,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "PI $pi",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = IceWhite,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = "Drag backdrop to rotate 360° • Offline Ready",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SilverText
                        )
                    }
                }
            }
        }
    }
}
