package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.CareerResultEntity
import com.example.data.PlayerProfileEntity
import com.example.model.CarCatalog
import com.example.model.CareerCatalog
import com.example.model.CareerEvent
import com.example.model.GameMode
import com.example.model.RaceConfig
import com.example.model.TrackCatalog
import com.example.ui.components.TopTelemetryBar
import com.example.ui.components.formatRaceTime
import com.example.ui.theme.ApexCrimson
import com.example.ui.theme.BorderGlass
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.ChampionshipGold
import com.example.ui.theme.ElevatedSteel
import com.example.ui.theme.GraphiteCard
import com.example.ui.theme.IceWhite
import com.example.ui.theme.MutedSteel
import com.example.ui.theme.NitroCyan
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.SilverText
import java.util.Locale

@Composable
fun CareerScreen(
    profile: PlayerProfileEntity,
    careerResults: Map<String, CareerResultEntity>,
    totalStars: Int,
    onBack: () -> Unit,
    onLaunchEvent: (RaceConfig) -> Unit
) {
    BackHandler(onBack = onBack)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(ObsidianSurface, CarbonBlack)))
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            TopTelemetryBar(
                title = "Career Championship",
                credits = profile.credits,
                totalStars = totalStars,
                onBack = onBack,
                backTestTag = "career_back_button"
            )

            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 310.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(CareerCatalog.events, key = { it.id }) { event ->
                    val result = careerResults[event.id]
                    val unlocked = totalStars >= event.requiredPreviousStars
                    CareerEventCard(
                        event = event,
                        result = result,
                        unlocked = unlocked,
                        onStart = {
                            onLaunchEvent(
                                RaceConfig(
                                    mode = GameMode.CAREER,
                                    trackId = event.trackId,
                                    timeOfDay = event.timeOfDay,
                                    carId = profile.selectedCarId,
                                    laps = event.laps,
                                    difficulty = event.difficulty,
                                    careerEventId = event.id
                                )
                            )
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun CareerEventCard(
    event: CareerEvent,
    result: CareerResultEntity?,
    unlocked: Boolean,
    onStart: () -> Unit
) {
    val track = TrackCatalog.findById(event.trackId)
    val stars = result?.stars ?: 0

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (unlocked) Modifier.clickable(onClick = onStart) else Modifier)
            .testTag("career_event_${event.eventNumber}"),
        color = if (unlocked) GraphiteCard else Color(0xFF0E121B),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            1.dp,
            if (stars == 3) ChampionshipGold.copy(alpha = 0.55f) else BorderGlass
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "EVENT ${event.eventNumber} • ${event.seriesName}",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (unlocked) NitroCyan else MutedSteel
                )
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    for (s in 1..3) {
                        Icon(
                            imageVector = Icons.Filled.Star,
                            contentDescription = null,
                            tint = if (s <= stars) ChampionshipGold else ElevatedSteel,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(6.dp))
            Text(
                text = event.title.uppercase(Locale.US),
                style = MaterialTheme.typography.titleMedium,
                color = if (unlocked) IceWhite else MutedSteel
            )
            Text(
                text = "${track.name} • ${event.timeOfDay.label} • ${event.laps} Laps • ${event.difficulty.label}",
                style = MaterialTheme.typography.bodyMedium,
                color = SilverText
            )

            Spacer(Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "1st Prize: %,d CR".format(Locale.US, event.rewardFirst),
                        style = MaterialTheme.typography.labelSmall,
                        color = ChampionshipGold
                    )
                    if (event.unlockCarId != null) {
                        val unlockCar = CarCatalog.findById(event.unlockCarId)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Filled.DirectionsCar,
                                contentDescription = null,
                                tint = NitroCyan,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                text = "Podium Top 2 unlocks ${unlockCar.name}",
                                style = MaterialTheme.typography.labelSmall,
                                color = NitroCyan
                            )
                        }
                    } else if (result != null && result.bestTimeMs > 0L) {
                        Text(
                            text = "Best Time: ${formatRaceTime(result.bestTimeMs)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = SilverText
                        )
                    }
                }

                if (unlocked) {
                    Button(
                        onClick = onStart,
                        colors = ButtonDefaults.buttonColors(containerColor = ApexCrimson),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("career_start_${event.eventNumber}")
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("RACE", style = MaterialTheme.typography.labelLarge)
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Lock, contentDescription = null, tint = MutedSteel, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "${event.requiredPreviousStars} ★ Req",
                            style = MaterialTheme.typography.labelSmall,
                            color = MutedSteel
                        )
                    }
                }
            }
        }
    }
}
