package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.GameSettings
import com.example.data.PlayerProfileEntity
import com.example.model.CameraMode
import com.example.model.GraphicsQuality
import com.example.ui.components.TopTelemetryBar
import com.example.ui.theme.ApexCrimson
import com.example.ui.theme.BorderGlass
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.GraphiteCard
import com.example.ui.theme.IceWhite
import com.example.ui.theme.NitroCyan
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.SilverText

@Composable
fun SettingsScreen(
    settings: GameSettings,
    profile: PlayerProfileEntity,
    totalStars: Int,
    tiltSupported: Boolean,
    onGraphicsChange: (GraphicsQuality) -> Unit,
    onTiltToggle: (Boolean) -> Unit,
    onTiltSensitivity: (Float) -> Unit,
    onSoundToggle: (Boolean) -> Unit,
    onSoundVolume: (Float) -> Unit,
    onDefaultCamera: (CameraMode) -> Unit,
    onShowMinimap: (Boolean) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(ObsidianSurface, CarbonBlack)))
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            TopTelemetryBar(
                title = "Settings & Optimization",
                credits = profile.credits,
                totalStars = totalStars,
                onBack = onBack,
                backTestTag = "settings_back_button"
            )

            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Left column: Graphics & Camera
                Surface(
                    modifier = Modifier.weight(1f),
                    color = GraphiteCard,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderGlass)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("3D GRAPHICS QUALITY", style = MaterialTheme.typography.labelSmall, color = NitroCyan)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            GraphicsQuality.entries.forEach { quality ->
                                FilterChip(
                                    selected = settings.graphicsQuality == quality,
                                    onClick = { onGraphicsChange(quality) },
                                    label = { Text(quality.label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = ApexCrimson,
                                        selectedLabelColor = IceWhite
                                    ),
                                    modifier = Modifier.testTag("gfx_${quality.name}")
                                )
                            }
                        }
                        Text(
                            text = settings.graphicsQuality.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = SilverText
                        )

                        Spacer(Modifier.height(4.dp))
                        Text("DEFAULT CAMERA VIEW", style = MaterialTheme.typography.labelSmall, color = NitroCyan)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            CameraMode.entries.forEach { cam ->
                                FilterChip(
                                    selected = settings.defaultCamera == cam,
                                    onClick = { onDefaultCamera(cam) },
                                    label = { Text(cam.label, style = MaterialTheme.typography.labelSmall) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = NitroCyan,
                                        selectedLabelColor = CarbonBlack
                                    )
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Track Minimap HUD", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                                Text("Show live circuit & rival positions", style = MaterialTheme.typography.bodyMedium, color = SilverText)
                            }
                            Switch(
                                checked = settings.showMinimap,
                                onCheckedChange = onShowMinimap,
                                colors = SwitchDefaults.colors(checkedThumbColor = IceWhite, checkedTrackColor = NitroCyan)
                            )
                        }
                    }
                }

                // Right column: Controls & Audio
                Surface(
                    modifier = Modifier.weight(1f),
                    color = GraphiteCard,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderGlass)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("STEERING CONTROLS", style = MaterialTheme.typography.labelSmall, color = NitroCyan)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Tilt Steering (Gyro / Accel)", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                                Text(
                                    text = if (tiltSupported) "Steer by tilting device in landscape" else "Device sensor unavailable — Touch mode active",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = SilverText
                                )
                            }
                            Switch(
                                checked = settings.tiltSteeringEnabled && tiltSupported,
                                enabled = tiltSupported,
                                onCheckedChange = onTiltToggle,
                                colors = SwitchDefaults.colors(checkedThumbColor = IceWhite, checkedTrackColor = ApexCrimson),
                                modifier = Modifier.testTag("tilt_switch")
                            )
                        }

                        if (settings.tiltSteeringEnabled && tiltSupported) {
                            Column {
                                Text(
                                    text = "Tilt Sensitivity: ${(settings.tiltSensitivity * 100).toInt()}%",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = SilverText
                                )
                                Slider(
                                    value = settings.tiltSensitivity,
                                    onValueChange = onTiltSensitivity,
                                    valueRange = 0.5f..2.0f,
                                    colors = SliderDefaults.colors(thumbColor = ApexCrimson, activeTrackColor = ApexCrimson)
                                )
                            }
                        }

                        Spacer(Modifier.height(4.dp))
                        Text("PROCEDURAL AUDIO", style = MaterialTheme.typography.labelSmall, color = NitroCyan)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Engine & Race SFX", style = MaterialTheme.typography.titleMedium, color = IceWhite)
                                Text("Offline synthesized engine RPM, nitro & tire screech", style = MaterialTheme.typography.bodyMedium, color = SilverText)
                            }
                            Switch(
                                checked = settings.soundEnabled,
                                onCheckedChange = onSoundToggle,
                                colors = SwitchDefaults.colors(checkedThumbColor = IceWhite, checkedTrackColor = ApexCrimson),
                                modifier = Modifier.testTag("sound_switch")
                            )
                        }

                        Column {
                            Text(
                                text = "Master Volume: ${(settings.soundVolume * 100).toInt()}%",
                                style = MaterialTheme.typography.bodyMedium,
                                color = SilverText
                            )
                            Slider(
                                value = settings.soundVolume,
                                onValueChange = onSoundVolume,
                                enabled = settings.soundEnabled,
                                valueRange = 0f..1f,
                                colors = SliderDefaults.colors(thumbColor = NitroCyan, activeTrackColor = NitroCyan)
                            )
                        }
                    }
                }
            }
        }
    }
}
