package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.ApexCrimson
import com.example.ui.theme.BorderGlass
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.ChampionshipGold
import com.example.ui.theme.DarkGlass
import com.example.ui.theme.ElevatedSteel
import com.example.ui.theme.GraphiteCard
import com.example.ui.theme.IceWhite
import com.example.ui.theme.MonoFont
import com.example.ui.theme.NitroCyan
import com.example.ui.theme.SilverText
import java.util.Locale

@Composable
fun TopTelemetryBar(
    title: String,
    credits: Int,
    totalStars: Int,
    onBack: (() -> Unit)? = null,
    backTestTag: String = "back_button",
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) {
                Surface(
                    color = DarkGlass,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, BorderGlass)
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag(backTestTag)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back),
                            tint = IceWhite
                        )
                    }
                }
                Spacer(Modifier.width(12.dp))
            }
            Column {
                Text(
                    text = title.uppercase(Locale.US),
                    style = MaterialTheme.typography.headlineMedium,
                    color = IceWhite,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TelemetryPill(
                icon = Icons.Filled.EmojiEvents,
                iconTint = ChampionshipGold,
                text = "$totalStars ★"
            )
            TelemetryPill(
                icon = Icons.Filled.MonetizationOn,
                iconTint = NitroCyan,
                text = "%,d CR".format(Locale.US, credits)
            )
        }
    }
}

@Composable
fun TelemetryPill(
    icon: ImageVector,
    iconTint: Color,
    text: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = DarkGlass,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, BorderGlass)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge.copy(fontFamily = MonoFont),
                color = IceWhite
            )
        }
    }
}

@Composable
fun RacingMenuButton(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    testTag: String,
    accent: Boolean = false,
    subtitle: String? = null,
    modifier: Modifier = Modifier
) {
    val bgBrush = if (accent) {
        Brush.horizontalGradient(listOf(ApexCrimson, Color(0xFFD0143A)))
    } else {
        Brush.horizontalGradient(listOf(DarkGlass, Color(0xAA171E2E)))
    }
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .height(if (subtitle != null) 58.dp else 48.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(bgBrush)
            .border(
                width = 1.dp,
                color = if (accent) Color(0x66FF8FA3) else BorderGlass,
                shape = RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
            .testTag(testTag),
        color = Color.Transparent
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (accent) IceWhite else NitroCyan,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelLarge,
                    color = IceWhite,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (accent) Color(0xFFFFD8DF) else SilverText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun StatMeterBar(
    label: String,
    valueNormalized: Float,
    displayValue: String,
    accentColor: Color = NitroCyan,
    modifier: Modifier = Modifier
) {
    val animated by animateFloatAsState(
        targetValue = valueNormalized.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 360),
        label = "stat_bar"
    )
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.bodyMedium, color = SilverText)
            Text(
                text = displayValue,
                style = MaterialTheme.typography.labelSmall,
                color = IceWhite,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(7.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(ElevatedSteel)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(animated)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        Brush.horizontalGradient(listOf(accentColor.copy(alpha = 0.7f), accentColor))
                    )
            )
        }
    }
}

@Composable
fun TrackMinimap(
    trackPoints: List<Pair<Float, Float>>,
    racerDots: List<Triple<Float, Float, Boolean>>,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.size(104.dp),
        color = DarkGlass,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, BorderGlass)
    ) {
        Canvas(modifier = Modifier.padding(10.dp)) {
            if (trackPoints.size < 3) return@Canvas
            val path = Path()
            trackPoints.forEachIndexed { idx, (nx, nz) ->
                val px = nx * size.width
                val py = nz * size.height
                if (idx == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close()
            drawPath(
                path = path,
                color = Color(0x66FFFFFF),
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            )
            // Rival dots first, player dot on top
            racerDots.filter { !it.third }.forEach { (nx, nz, _) ->
                drawCircle(
                    color = Color(0xFFFF9100),
                    radius = 3.5.dp.toPx(),
                    center = Offset(nx * size.width, nz * size.height)
                )
            }
            racerDots.firstOrNull { it.third }?.let { (nx, nz, _) ->
                drawCircle(
                    color = NitroCyan,
                    radius = 5.dp.toPx(),
                    center = Offset(nx * size.width, nz * size.height)
                )
                drawCircle(
                    color = IceWhite,
                    radius = 2.dp.toPx(),
                    center = Offset(nx * size.width, nz * size.height)
                )
            }
        }
    }
}

fun formatRaceTime(ms: Long): String {
    if (ms <= 0L) return "--:--.--"
    val totalHundredths = ms / 10L
    val hundredths = (totalHundredths % 100L).toInt()
    val totalSeconds = (totalHundredths / 100L).toInt()
    val seconds = totalSeconds % 60
    val minutes = totalSeconds / 60
    return String.format(Locale.US, "%02d:%02d.%02d", minutes, seconds, hundredths)
}
