package com.example.input

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.abs

class TiltSteeringManager(context: Context) : SensorEventListener {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val tiltSensor: Sensor? =
        sensorManager?.getDefaultSensor(Sensor.TYPE_GRAVITY)
            ?: sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    val isSupported: Boolean = tiltSensor != null

    @Volatile
    var steerValue: Float = 0f
        private set

    @Volatile
    var sensitivity: Float = 1.0f

    private var filteredAxis = 0f
    private var active = false

    fun start() {
        if (active || tiltSensor == null) return
        active = true
        filteredAxis = 0f
        steerValue = 0f
        sensorManager?.registerListener(this, tiltSensor, SensorManager.SENSOR_DELAY_GAME)
    }

    fun stop() {
        if (!active) return
        active = false
        sensorManager?.unregisterListener(this)
        steerValue = 0f
    }

    override fun onSensorChanged(event: SensorEvent?) {
        val ev = event ?: return
        // In landscape mode, tilting phone left/right changes values[1] (device Y axis)
        val raw = ev.values[1] / 9.81f
        filteredAxis += (raw - filteredAxis) * 0.25f
        val deadzone = 0.055f
        val adjusted = if (abs(filteredAxis) < deadzone) {
            0f
        } else {
            val sign = if (filteredAxis > 0f) 1f else -1f
            ((abs(filteredAxis) - deadzone) * 2.4f * sensitivity * sign).coerceIn(-1f, 1f)
        }
        steerValue = adjusted
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
