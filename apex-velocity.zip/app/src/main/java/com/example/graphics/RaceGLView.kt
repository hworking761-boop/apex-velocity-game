package com.example.graphics

import android.opengl.GLSurfaceView
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

@Composable
fun RaceGLView(
    renderer: RaceGLRenderer,
    modifier: Modifier = Modifier,
    enableOrbitTouch: Boolean = false
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val glSurfaceView = remember(context) {
        GLSurfaceView(context).apply {
            setEGLContextClientVersion(3)
            setEGLConfigChooser(8, 8, 8, 8, 16, 0)
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            preserveEGLContextOnPause = true
        }
    }

    DisposableEffect(lifecycleOwner, glSurfaceView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> glSurfaceView.onResume()
                Lifecycle.Event.ON_PAUSE -> glSurfaceView.onPause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            glSurfaceView.onPause()
        }
    }

    val orbitModifier = if (enableOrbitTouch) {
        Modifier.pointerInput(renderer) {
            detectDragGestures { change, dragAmount ->
                change.consume()
                renderer.showroomYawDeg = (renderer.showroomYawDeg - dragAmount.x * 0.35f) % 360f
                renderer.showroomPitchDeg = (renderer.showroomPitchDeg + dragAmount.y * 0.18f).coerceIn(5f, 42f)
            }
        }
    } else {
        Modifier
    }

    AndroidView(
        factory = { glSurfaceView },
        modifier = modifier.then(orbitModifier)
    )
}
