package com.example.graphics

import android.opengl.GLES30
import com.example.engine.TrackSpline
import com.example.engine.Vec3
import com.example.model.CarBodyStyle
import com.example.model.CarSpec
import com.example.model.TrackEnvironmentType
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class GlMesh(vertices: FloatArray, indices: IntArray) {
    private val vaoId: Int
    private val vboId: Int
    private val eboId: Int
    val indexCount: Int = indices.size

    init {
        val vaos = IntArray(1)
        val vbos = IntArray(1)
        val ebos = IntArray(1)
        GLES30.glGenVertexArrays(1, vaos, 0)
        GLES30.glGenBuffers(1, vbos, 0)
        GLES30.glGenBuffers(1, ebos, 0)
        vaoId = vaos[0]
        vboId = vbos[0]
        eboId = ebos[0]

        val vBuf = ByteBuffer.allocateDirect(vertices.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply { put(vertices); position(0) }

        val iBuf = ByteBuffer.allocateDirect(indices.size * 4)
            .order(ByteOrder.nativeOrder())
            .asIntBuffer()
            .apply { put(indices); position(0) }

        GLES30.glBindVertexArray(vaoId)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vboId)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, vertices.size * 4, vBuf, GLES30.GL_STATIC_DRAW)

        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, eboId)
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, indices.size * 4, iBuf, GLES30.GL_STATIC_DRAW)

        val stride = 12 * 4 // 12 floats per vertex
        // pos (3)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, stride, 0)
        // normal (3)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, stride, 3 * 4)
        // uv (2)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, stride, 6 * 4)
        // color (4)
        GLES30.glEnableVertexAttribArray(3)
        GLES30.glVertexAttribPointer(3, 4, GLES30.GL_FLOAT, false, stride, 8 * 4)

        GLES30.glBindVertexArray(0)
    }

    fun draw() {
        GLES30.glBindVertexArray(vaoId)
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, indexCount, GLES30.GL_UNSIGNED_INT, 0)
        GLES30.glBindVertexArray(0)
    }

    fun release() {
        GLES30.glDeleteVertexArrays(1, intArrayOf(vaoId), 0)
        GLES30.glDeleteBuffers(1, intArrayOf(vboId, eboId), 0)
    }
}

class MeshAccumulator {
    private val verts = ArrayList<Float>(4096)
    private val idx = ArrayList<Int>(2048)

    fun addVertex(
        px: Float, py: Float, pz: Float,
        nx: Float, ny: Float, nz: Float,
        u: Float, v: Float,
        r: Float, g: Float, b: Float, a: Float = 1f
    ): Int {
        val index = verts.size / 12
        verts.add(px); verts.add(py); verts.add(pz)
        verts.add(nx); verts.add(ny); verts.add(nz)
        verts.add(u); verts.add(v)
        verts.add(r); verts.add(g); verts.add(b); verts.add(a)
        return index
    }

    fun addQuad(i0: Int, i1: Int, i2: Int, i3: Int) {
        idx.add(i0); idx.add(i1); idx.add(i2)
        idx.add(i0); idx.add(i2); idx.add(i3)
    }

    fun addTriangle(i0: Int, i1: Int, i2: Int) {
        idx.add(i0); idx.add(i1); idx.add(i2)
    }

    fun addBox(
        cx: Float, cy: Float, cz: Float,
        hx: Float, hy: Float, hz: Float,
        r: Float, g: Float, b: Float, a: Float = 1f,
        taperTopX: Float = 1f, taperTopZ: Float = 1f,
        uvScale: Float = 1f
    ) {
        val bx = hx; val tx = hx * taperTopX
        val bz = hz; val tz = hz * taperTopZ
        val y0 = cy - hy; val y1 = cy + hy

        // Top
        addFace(
            cx - tx, y1, cz + tz, cx + tx, y1, cz + tz, cx + tx, y1, cz - tz, cx - tx, y1, cz - tz,
            0f, 1f, 0f, r, g, b, a, uvScale
        )
        // Bottom
        addFace(
            cx - bx, y0, cz - bz, cx + bx, y0, cz - bz, cx + bx, y0, cz + bz, cx - bx, y0, cz + bz,
            0f, -1f, 0f, r, g, b, a, uvScale
        )
        // Front (-Z)
        addFace(
            cx + bx, y0, cz - bz, cx - bx, y0, cz - bz, cx - tx, y1, cz - tz, cx + tx, y1, cz - tz,
            0f, 0.25f, -0.97f, r, g, b, a, uvScale
        )
        // Back (+Z)
        addFace(
            cx - bx, y0, cz + bz, cx + bx, y0, cz + bz, cx + tx, y1, cz + tz, cx - tx, y1, cz + tz,
            0f, 0.25f, 0.97f, r, g, b, a, uvScale
        )
        // Left (-X)
        addFace(
            cx - bx, y0, cz - bz, cx - bx, y0, cz + bz, cx - tx, y1, cz + tz, cx - tx, y1, cz - tz,
            -0.97f, 0.25f, 0f, r, g, b, a, uvScale
        )
        // Right (+X)
        addFace(
            cx + bx, y0, cz + bz, cx + bx, y0, cz - bz, cx + tx, y1, cz - tz, cx + tx, y1, cz + tz,
            0.97f, 0.25f, 0f, r, g, b, a, uvScale
        )
    }

    private fun addFace(
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        nx: Float, ny: Float, nz: Float,
        r: Float, g: Float, b: Float, a: Float,
        uvScale: Float
    ) {
        val i0 = addVertex(x0, y0, z0, nx, ny, nz, 0f, 0f, r, g, b, a)
        val i1 = addVertex(x1, y1, z1, nx, ny, nz, uvScale, 0f, r, g, b, a)
        val i2 = addVertex(x2, y2, z2, nx, ny, nz, uvScale, uvScale, r, g, b, a)
        val i3 = addVertex(x3, y3, z3, nx, ny, nz, 0f, uvScale, r, g, b, a)
        addQuad(i0, i1, i2, i3)
    }

    fun addCylinderY(
        cx: Float, yBottom: Float, cz: Float,
        radiusBottom: Float, radiusTop: Float, height: Float,
        segments: Int, r: Float, g: Float, b: Float
    ) {
        val yTop = yBottom + height
        for (i in 0 until segments) {
            val a0 = (i.toFloat() / segments) * (2f * PI.toFloat())
            val a1 = ((i + 1).toFloat() / segments) * (2f * PI.toFloat())
            val c0 = cos(a0); val s0 = sin(a0)
            val c1 = cos(a1); val s1 = sin(a1)
            val v0 = addVertex(cx + c0 * radiusBottom, yBottom, cz + s0 * radiusBottom, c0, 0.1f, s0, 0f, 0f, r, g, b)
            val v1 = addVertex(cx + c1 * radiusBottom, yBottom, cz + s1 * radiusBottom, c1, 0.1f, s1, 1f, 0f, r, g, b)
            val v2 = addVertex(cx + c1 * radiusTop, yTop, cz + s1 * radiusTop, c1, 0.1f, s1, 1f, 1f, r, g, b)
            val v3 = addVertex(cx + c0 * radiusTop, yTop, cz + s0 * radiusTop, c0, 0.1f, s0, 0f, 1f, r, g, b)
            addQuad(v0, v1, v2, v3)
        }
    }

    fun addWheelX(radius: Float, width: Float, tireR: Float, tireG: Float, tireB: Float, rimR: Float, rimG: Float, rimB: Float) {
        val segs = 20
        val hw = width * 0.5f
        for (i in 0 until segs) {
            val a0 = (i.toFloat() / segs) * (2f * PI.toFloat())
            val a1 = ((i + 1).toFloat() / segs) * (2f * PI.toFloat())
            val y0 = cos(a0) * radius; val z0 = sin(a0) * radius
            val y1 = cos(a1) * radius; val z1 = sin(a1) * radius
            val ny = cos((a0 + a1) * 0.5f); val nz = sin((a0 + a1) * 0.5f)
            // Tire tread
            val t0 = addVertex(-hw, y0, z0, 0f, ny, nz, 0f, 0f, tireR, tireG, tireB)
            val t1 = addVertex(hw, y0, z0, 0f, ny, nz, 1f, 0f, tireR, tireG, tireB)
            val t2 = addVertex(hw, y1, z1, 0f, ny, nz, 1f, 1f, tireR, tireG, tireB)
            val t3 = addVertex(-hw, y1, z1, 0f, ny, nz, 0f, 1f, tireR, tireG, tireB)
            addQuad(t0, t1, t2, t3)

            // Alloy rim disc (outer & inner)
            val rimRadius = radius * 0.68f
            val ry0 = cos(a0) * rimRadius; val rz0 = sin(a0) * rimRadius
            val ry1 = cos(a1) * rimRadius; val rz1 = sin(a1) * rimRadius
            val isSpoke = (i % 4 == 0)
            val sr = if (isSpoke) rimR else rimR * 0.25f
            val sg = if (isSpoke) rimG else rimG * 0.25f
            val sb = if (isSpoke) rimB else rimB * 0.28f

            val rcR = addVertex(hw + 0.005f, 0f, 0f, 1f, 0f, 0f, 0.5f, 0.5f, sr, sg, sb)
            val r1 = addVertex(hw + 0.005f, ry0, rz0, 1f, 0f, 0f, 0f, 0f, sr, sg, sb)
            val r2 = addVertex(hw + 0.005f, ry1, rz1, 1f, 0f, 0f, 1f, 0f, sr, sg, sb)
            addTriangle(rcR, r2, r1)

            val rcL = addVertex(-hw - 0.005f, 0f, 0f, -1f, 0f, 0f, 0.5f, 0.5f, sr, sg, sb)
            val l1 = addVertex(-hw - 0.005f, ry0, rz0, -1f, 0f, 0f, 0f, 0f, sr, sg, sb)
            val l2 = addVertex(-hw - 0.005f, ry1, rz1, -1f, 0f, 0f, 1f, 0f, sr, sg, sb)
            addTriangle(rcL, l1, l2)

            // Tire sidewall rings
            val sw0 = addVertex(hw, ry0, rz0, 1f, 0f, 0f, 0f, 0f, tireR, tireG, tireB)
            val sw1 = addVertex(hw, y0, z0, 1f, 0f, 0f, 1f, 0f, tireR, tireG, tireB)
            val sw2 = addVertex(hw, y1, z1, 1f, 0f, 0f, 1f, 1f, tireR, tireG, tireB)
            val sw3 = addVertex(hw, ry1, rz1, 1f, 0f, 0f, 0f, 1f, tireR, tireG, tireB)
            addQuad(sw0, sw3, sw2, sw1)

            val lw0 = addVertex(-hw, ry0, rz0, -1f, 0f, 0f, 0f, 0f, tireR, tireG, tireB)
            val lw1 = addVertex(-hw, y0, z0, -1f, 0f, 0f, 1f, 0f, tireR, tireG, tireB)
            val lw2 = addVertex(-hw, y1, z1, -1f, 0f, 0f, 1f, 1f, tireR, tireG, tireB)
            val lw3 = addVertex(-hw, ry1, rz1, -1f, 0f, 0f, 0f, 1f, tireR, tireG, tireB)
            addQuad(lw0, lw1, lw2, lw3)
        }
    }

    fun build(): GlMesh {
        val vArr = FloatArray(verts.size) { verts[it] }
        val iArr = IntArray(idx.size) { idx[it] }
        return GlMesh(vArr, iArr)
    }
}

class CarMeshSet(spec: CarSpec) {
    val bodyMesh: GlMesh
    val trimMesh: GlMesh
    val glassMesh: GlMesh
    val headlightMesh: GlMesh
    val taillightMesh: GlMesh
    val wheelMesh: GlMesh
    val shadowMesh: GlMesh

    init {
        val L = spec.lengthMeters
        val W = spec.widthMeters
        val H = spec.heightMeters
        val hw = W * 0.5f
        val hl = L * 0.5f

        val body = MeshAccumulator()
        val trim = MeshAccumulator()
        val glass = MeshAccumulator()
        val heads = MeshAccumulator()
        val tails = MeshAccumulator()

        // Main lower sculpted chassis
        val noseSlope = when (spec.bodyStyle) {
            CarBodyStyle.MID_ENGINE_WEDGE, CarBodyStyle.LE_MANS_PROTOTYPE -> 0.80f
            else -> 0.88f
        }
        body.addBox(0f, H * 0.34f, 0f, hw * 0.96f, H * 0.21f, hl * 0.95f, 1f, 1f, 1f, 1f, noseSlope, 0.92f)

        // Sculpted front hood & fender blisters
        val hoodZ = -hl * 0.45f
        val fenderH = H * 0.42f
        body.addBox(-hw * 0.72f, fenderH, hoodZ, hw * 0.22f, H * 0.14f, hl * 0.42f, 1f, 1f, 1f, 1f, 0.82f, 0.88f)
        body.addBox(hw * 0.72f, fenderH, hoodZ, hw * 0.22f, H * 0.14f, hl * 0.42f, 1f, 1f, 1f, 1f, 0.82f, 0.88f)
        body.addBox(0f, H * 0.41f, hoodZ, hw * 0.54f, H * 0.10f, hl * 0.40f, 1f, 1f, 1f, 1f, 0.86f, 0.90f)

        // Rear muscular haunches
        val rearZ = hl * 0.44f
        body.addBox(-hw * 0.74f, H * 0.45f, rearZ, hw * 0.23f, H * 0.16f, hl * 0.44f, 1f, 1f, 1f, 1f, 0.84f, 0.92f)
        body.addBox(hw * 0.74f, H * 0.45f, rearZ, hw * 0.23f, H * 0.16f, hl * 0.44f, 1f, 1f, 1f, 1f, 0.84f, 0.92f)

        // Cabin roof & greenhouse glass tailored per body style
        val cabinZ = when (spec.bodyStyle) {
            CarBodyStyle.MID_ENGINE_WEDGE, CarBodyStyle.LE_MANS_PROTOTYPE -> -hl * 0.05f
            CarBodyStyle.MUSCLE_WIDEBODY -> hl * 0.12f
            else -> hl * 0.06f
        }
        val cabinLen = hl * if (spec.bodyStyle == CarBodyStyle.LE_MANS_PROTOTYPE) 0.42f else 0.46f
        val cabinW = hw * if (spec.bodyStyle == CarBodyStyle.LE_MANS_PROTOTYPE) 0.62f else 0.74f

        glass.addBox(0f, H * 0.70f, cabinZ, cabinW, H * 0.19f, cabinLen, 0.08f, 0.11f, 0.16f, 0.92f, 0.76f, 0.66f)
        // Painted roof panel
        body.addBox(0f, H * 0.88f, cabinZ + cabinLen * 0.08f, cabinW * 0.72f, H * 0.035f, cabinLen * 0.55f, 1f, 1f, 1f, 1f, 0.92f, 0.88f)

        // Side mirrors
        body.addBox(-hw * 0.98f, H * 0.58f, cabinZ - cabinLen * 0.35f, 0.11f, 0.055f, 0.14f, 1f, 1f, 1f)
        body.addBox(hw * 0.98f, H * 0.58f, cabinZ - cabinLen * 0.35f, 0.11f, 0.055f, 0.14f, 1f, 1f, 1f)

        // Carbon fiber front splitter, side skirts, rear diffuser & interior dash silhouette
        trim.addBox(0f, H * 0.12f, -hl * 0.94f, hw * 0.98f, 0.035f, 0.24f, 0.10f, 0.11f, 0.13f)
        trim.addBox(-hw * 0.96f, H * 0.14f, 0f, 0.07f, 0.045f, hl * 0.68f, 0.10f, 0.11f, 0.13f)
        trim.addBox(hw * 0.96f, H * 0.14f, 0f, 0.07f, 0.045f, hl * 0.68f, 0.10f, 0.11f, 0.13f)
        trim.addBox(0f, H * 0.16f, hl * 0.94f, hw * 0.88f, 0.09f, 0.18f, 0.08f, 0.09f, 0.11f)
        // Exhaust tips
        trim.addBox(-hw * 0.42f, H * 0.20f, hl * 0.98f, 0.09f, 0.06f, 0.12f, 0.65f, 0.68f, 0.72f)
        trim.addBox(hw * 0.42f, H * 0.20f, hl * 0.98f, 0.09f, 0.06f, 0.12f, 0.65f, 0.68f, 0.72f)

        // Distinct rear aero / wing / hood details per car body style
        when (spec.bodyStyle) {
            CarBodyStyle.GT_COUPE -> {
                // Swan-neck GT carbon wing
                trim.addBox(-hw * 0.42f, H * 0.74f, hl * 0.86f, 0.035f, H * 0.16f, 0.14f, 0.12f, 0.13f, 0.15f)
                trim.addBox(hw * 0.42f, H * 0.74f, hl * 0.86f, 0.035f, H * 0.16f, 0.14f, 0.12f, 0.13f, 0.15f)
                body.addBox(0f, H * 0.90f, hl * 0.90f, hw * 0.92f, 0.035f, 0.20f, 1f, 1f, 1f)
            }
            CarBodyStyle.JDM_TUNER -> {
                // Tall dual-plane tuner wing + hood vent
                trim.addBox(-hw * 0.56f, H * 0.79f, hl * 0.88f, 0.035f, H * 0.22f, 0.15f, 0.10f, 0.11f, 0.13f)
                trim.addBox(hw * 0.56f, H * 0.79f, hl * 0.88f, 0.035f, H * 0.22f, 0.15f, 0.10f, 0.11f, 0.13f)
                trim.addBox(0f, H * 1.00f, hl * 0.91f, hw * 0.98f, 0.035f, 0.22f, 0.14f, 0.15f, 0.17f)
                trim.addBox(0f, H * 0.52f, -hl * 0.48f, hw * 0.34f, 0.03f, 0.26f, 0.10f, 0.11f, 0.13f)
            }
            CarBodyStyle.MUSCLE_WIDEBODY -> {
                // Supercharger hood blower bulge + ducktail lip
                body.addBox(0f, H * 0.55f, -hl * 0.36f, hw * 0.30f, 0.08f, hl * 0.28f, 1f, 1f, 1f, 1f, 0.78f, 0.82f)
                trim.addBox(0f, H * 0.62f, -hl * 0.50f, hw * 0.20f, 0.04f, 0.12f, 0.22f, 0.24f, 0.28f)
                body.addBox(0f, H * 0.65f, hl * 0.92f, hw * 0.94f, 0.08f, 0.14f, 1f, 1f, 1f, 1f, 0.95f, 0.6f)
            }
            CarBodyStyle.MID_ENGINE_WEDGE -> {
                // Side air intake blades + active aero deck wing
                trim.addBox(-hw * 0.92f, H * 0.46f, hl * 0.22f, 0.10f, H * 0.16f, 0.36f, 0.09f, 0.10f, 0.12f)
                trim.addBox(hw * 0.92f, H * 0.46f, hl * 0.22f, 0.10f, H * 0.16f, 0.36f, 0.09f, 0.10f, 0.12f)
                trim.addBox(-hw * 0.36f, H * 0.70f, hl * 0.86f, 0.03f, H * 0.14f, 0.14f, 0.12f, 0.13f, 0.16f)
                trim.addBox(hw * 0.36f, H * 0.70f, hl * 0.86f, 0.03f, H * 0.14f, 0.14f, 0.12f, 0.13f, 0.16f)
                body.addBox(0f, H * 0.84f, hl * 0.89f, hw * 0.94f, 0.03f, 0.22f, 1f, 1f, 1f)
            }
            CarBodyStyle.LE_MANS_PROTOTYPE -> {
                // Dorsal shark-fin spine + full-width endurance wing + endplates
                body.addBox(0f, H * 0.78f, hl * 0.45f, 0.03f, H * 0.20f, hl * 0.42f, 1f, 1f, 1f)
                trim.addBox(0f, H * 0.96f, hl * 0.90f, hw * 1.00f, 0.035f, 0.26f, 0.12f, 0.13f, 0.15f)
                body.addBox(-hw * 1.00f, H * 0.84f, hl * 0.88f, 0.03f, H * 0.22f, 0.28f, 1f, 1f, 1f)
                body.addBox(hw * 1.00f, H * 0.84f, hl * 0.88f, 0.03f, H * 0.22f, 0.28f, 1f, 1f, 1f)
            }
        }

        // LED Headlights
        heads.addBox(-hw * 0.68f, H * 0.38f, -hl * 0.95f, hw * 0.20f, 0.055f, 0.08f, 0.92f, 0.97f, 1.0f)
        heads.addBox(hw * 0.68f, H * 0.38f, -hl * 0.95f, hw * 0.20f, 0.055f, 0.08f, 0.92f, 0.97f, 1.0f)

        // LED Taillights / Brake light bar
        tails.addBox(-hw * 0.66f, H * 0.48f, hl * 0.96f, hw * 0.24f, 0.055f, 0.06f, 1.0f, 0.14f, 0.18f)
        tails.addBox(hw * 0.66f, H * 0.48f, hl * 0.96f, hw * 0.24f, 0.055f, 0.06f, 1.0f, 0.14f, 0.18f)
        tails.addBox(0f, H * 0.49f, hl * 0.965f, hw * 0.42f, 0.025f, 0.04f, 1.0f, 0.12f, 0.16f)

        // Wheel mesh
        val wheelAcc = MeshAccumulator()
        wheelAcc.addWheelX(
            radius = spec.wheelRadius,
            width = 0.28f,
            tireR = 0.10f, tireG = 0.10f, tireB = 0.12f,
            rimR = 0.84f, rimG = 0.87f, rimB = 0.92f
        )

        // Contact shadow quad
        val shAcc = MeshAccumulator()
        val sW = hw * 1.24f
        val sL = hl * 1.15f
        val s0 = shAcc.addVertex(-sW, 0.025f, -sL, 0f, 1f, 0f, 0f, 0f, 0.02f, 0.03f, 0.05f, 0.72f)
        val s1 = shAcc.addVertex(sW, 0.025f, -sL, 0f, 1f, 0f, 1f, 0f, 0.02f, 0.03f, 0.05f, 0.72f)
        val s2 = shAcc.addVertex(sW, 0.025f, sL, 0f, 1f, 0f, 1f, 1f, 0.02f, 0.03f, 0.05f, 0.72f)
        val s3 = shAcc.addVertex(-sW, 0.025f, sL, 0f, 1f, 0f, 0f, 1f, 0.02f, 0.03f, 0.05f, 0.72f)
        shAcc.addQuad(s0, s1, s2, s3)

        bodyMesh = body.build()
        trimMesh = trim.build()
        glassMesh = glass.build()
        headlightMesh = heads.build()
        taillightMesh = tails.build()
        wheelMesh = wheelAcc.build()
        shadowMesh = shAcc.build()
    }

    fun release() {
        bodyMesh.release()
        trimMesh.release()
        glassMesh.release()
        headlightMesh.release()
        taillightMesh.release()
        wheelMesh.release()
        shadowMesh.release()
    }
}

class TrackMeshSet(track: TrackSpline, propDensityStep: Int) {
    val roadMesh: GlMesh
    val finishLineMesh: GlMesh
    val gantryAndBarriersMesh: GlMesh
    val groundMesh: GlMesh
    val buildingsMesh: GlMesh
    val foliageAndPropsMesh: GlMesh

    init {
        val samples = track.samples
        val hw = track.roadHalfWidth
        val n = samples.size

        // 1. Road ribbon
        val roadAcc = MeshAccumulator()
        for (i in 0 until n) {
            val s0 = samples[i]
            val s1 = samples[(i + 1) % n]
            val v0 = s0.distanceAlong * 0.14f
            val v1 = (s0.distanceAlong + (track.totalLength / n)) * 0.14f

            val l0 = s0.pos - s0.right * hw
            val r0 = s0.pos + s0.right * hw
            val l1 = s1.pos - s1.right * hw
            val r1 = s1.pos + s1.right * hw

            val i0 = roadAcc.addVertex(l0.x, l0.y + 0.02f, l0.z, s0.up.x, s0.up.y, s0.up.z, 0f, v0, 1f, 1f, 1f)
            val i1 = roadAcc.addVertex(r0.x, r0.y + 0.02f, r0.z, s0.up.x, s0.up.y, s0.up.z, 1f, v0, 1f, 1f, 1f)
            val i2 = roadAcc.addVertex(r1.x, r1.y + 0.02f, r1.z, s1.up.x, s1.up.y, s1.up.z, 1f, v1, 1f, 1f, 1f)
            val i3 = roadAcc.addVertex(l1.x, l1.y + 0.02f, l1.z, s1.up.x, s1.up.y, s1.up.z, 0f, v1, 1f, 1f, 1f)
            roadAcc.addQuad(i0, i1, i2, i3)
        }
        roadMesh = roadAcc.build()

        // 2. Checkered start/finish line strip + gantry banner
        val finishAcc = MeshAccumulator()
        val sf0 = samples[0]
        val sf1 = samples[1]
        val fl0 = sf0.pos - sf0.right * (hw - 0.4f)
        val fr0 = sf0.pos + sf0.right * (hw - 0.4f)
        val fl1 = sf1.pos - sf1.right * (hw - 0.4f)
        val fr1 = sf1.pos + sf1.right * (hw - 0.4f)
        val fi0 = finishAcc.addVertex(fl0.x, fl0.y + 0.045f, fl0.z, 0f, 1f, 0f, 0f, 0f, 1f, 1f, 1f)
        val fi1 = finishAcc.addVertex(fr0.x, fr0.y + 0.045f, fr0.z, 0f, 1f, 0f, 3f, 0f, 1f, 1f, 1f)
        val fi2 = finishAcc.addVertex(fr1.x, fr1.y + 0.045f, fr1.z, 0f, 1f, 0f, 3f, 0.5f, 1f, 1f, 1f)
        val fi3 = finishAcc.addVertex(fl1.x, fl1.y + 0.045f, fl1.z, 0f, 1f, 0f, 0f, 0.5f, 1f, 1f, 1f)
        finishAcc.addQuad(fi0, fi1, fi2, fi3)
        finishLineMesh = finishAcc.build()

        // 3. Guardrail barriers + road shoulder + overhead start gantry
        val barAcc = MeshAccumulator()
        val bc = track.definition.barrierColorRgb
        for (i in 0 until n step 2) {
            val s0 = samples[i]
            val s1 = samples[(i + 2) % n]
            val stripe = if ((i / 2) % 2 == 0) 1.0f else 0.72f
            val rCol = bc[0] * stripe
            val gCol = bc[1] * stripe
            val bCol = bc[2] * stripe

            for (side in listOf(-1f, 1f)) {
                val p0 = s0.pos + s0.right * ((hw + 0.6f) * side)
                val p1 = s1.pos + s1.right * ((hw + 0.6f) * side)
                val nx = -s0.right.x * side
                val nz = -s0.right.z * side

                val b0 = barAcc.addVertex(p0.x, p0.y - 0.3f, p0.z, nx, 0.2f, nz, 0f, 0f, rCol, gCol, bCol)
                val b1 = barAcc.addVertex(p1.x, p1.y - 0.3f, p1.z, nx, 0.2f, nz, 1f, 0f, rCol, gCol, bCol)
                val b2 = barAcc.addVertex(p1.x, p1.y + 0.95f, p1.z, nx, 0.2f, nz, 1f, 1f, rCol, gCol, bCol)
                val b3 = barAcc.addVertex(p0.x, p0.y + 0.95f, p0.z, nx, 0.2f, nz, 0f, 1f, rCol, gCol, bCol)
                if (side > 0f) barAcc.addQuad(b0, b1, b2, b3) else barAcc.addQuad(b1, b0, b3, b2)

                // Shoulder embankment down to terrain
                val out0 = s0.pos + s0.right * ((hw + 4.5f) * side)
                val out1 = s1.pos + s1.right * ((hw + 4.5f) * side)
                val gc = track.definition.groundColorRgb
                val e0 = barAcc.addVertex(p0.x, p0.y - 0.1f, p0.z, 0f, 1f, 0f, 0f, 0f, gc[0], gc[1], gc[2])
                val e1 = barAcc.addVertex(p1.x, p1.y - 0.1f, p1.z, 0f, 1f, 0f, 1f, 0f, gc[0], gc[1], gc[2])
                val e2 = barAcc.addVertex(out1.x, out1.y - 1.5f, out1.z, 0f, 1f, 0f, 1f, 1f, gc[0], gc[1], gc[2])
                val e3 = barAcc.addVertex(out0.x, out0.y - 1.5f, out0.z, 0f, 1f, 0f, 0f, 1f, gc[0], gc[1], gc[2])
                if (side > 0f) barAcc.addQuad(e0, e1, e2, e3) else barAcc.addQuad(e1, e0, e3, e2)
            }
        }
        // Start/finish overhead steel truss gantry
        val gL = sf0.pos - sf0.right * (hw + 0.8f)
        val gR = sf0.pos + sf0.right * (hw + 0.8f)
        barAcc.addBox(gL.x, gL.y + 3.8f, gL.z, 0.45f, 3.8f, 0.45f, 0.22f, 0.25f, 0.30f)
        barAcc.addBox(gR.x, gR.y + 3.8f, gR.z, 0.45f, 3.8f, 0.45f, 0.22f, 0.25f, 0.30f)
        val gMid = sf0.pos
        barAcc.addBox(gMid.x, gMid.y + 7.2f, gMid.z, hw + 1.2f, 0.9f, 0.55f, 0.92f, 0.16f, 0.26f)
        gantryAndBarriersMesh = barAcc.build()

        // 4. Expansive ground / ocean plane
        val groundAcc = MeshAccumulator()
        val gc = track.definition.groundColorRgb
        val extent = 1600f
        val gy = -1.6f
        val gr0 = groundAcc.addVertex(-extent, gy, -extent, 0f, 1f, 0f, 0f, 0f, gc[0], gc[1], gc[2])
        val gr1 = groundAcc.addVertex(extent, gy, -extent, 0f, 1f, 0f, 1f, 0f, gc[0], gc[1], gc[2])
        val gr2 = groundAcc.addVertex(extent, gy, extent, 0f, 1f, 0f, 1f, 1f, gc[0], gc[1], gc[2])
        val gr3 = groundAcc.addVertex(-extent, gy, extent, 0f, 1f, 0f, 0f, 1f, gc[0], gc[1], gc[2])
        groundAcc.addQuad(gr0, gr1, gr2, gr3)

        if (track.definition.environment == TrackEnvironmentType.COASTAL_HIGHWAY) {
            // Shimmering ocean water extending west & north-west
            val o0 = groundAcc.addVertex(-2200f, -1.35f, -2200f, 0f, 1f, 0f, 0f, 0f, 0.05f, 0.36f, 0.56f)
            val o1 = groundAcc.addVertex(-180f, -1.35f, -2200f, 0f, 1f, 0f, 1f, 0f, 0.08f, 0.46f, 0.68f)
            val o2 = groundAcc.addVertex(-180f, -1.35f, 2200f, 0f, 1f, 0f, 1f, 1f, 0.08f, 0.46f, 0.68f)
            val o3 = groundAcc.addVertex(-2200f, -1.35f, 2200f, 0f, 1f, 0f, 0f, 1f, 0.05f, 0.36f, 0.56f)
            groundAcc.addQuad(o0, o1, o2, o3)
        }
        groundMesh = groundAcc.build()

        // 5. Environment-specific buildings & roadside props
        val bldAcc = MeshAccumulator()
        val propAcc = MeshAccumulator()
        val rng = Random(track.definition.id.hashCode().toLong())
        val step = 6 * propDensityStep

        for (i in 0 until n step step) {
            val s = samples[i]
            val sides = if (i % (step * 2) == 0) listOf(-1f, 1f) else listOf(1f)
            for (side in sides) {
                val distOut = hw + 9f + rng.nextFloat() * 14f
                val px = s.pos.x + s.right.x * (distOut * side)
                val pz = s.pos.z + s.right.z * (distOut * side)
                val py = s.pos.y - 1.2f

                // Ensure prop is not accidentally near another section of the closed track
                var tooClose = false
                for (checkIdx in 0 until n step 6) {
                    val cs = samples[checkIdx]
                    val dx = px - cs.pos.x
                    val dz = pz - cs.pos.z
                    if (dx * dx + dz * dz < (hw + 5.5f) * (hw + 5.5f)) {
                        tooClose = true
                        break
                    }
                }
                if (tooClose) continue

                when (track.definition.environment) {
                    TrackEnvironmentType.CITY_DAY -> {
                        val bW = 7f + rng.nextFloat() * 8f
                        val bH = 18f + rng.nextFloat() * 44f
                        val tint = 0.72f + rng.nextFloat() * 0.25f
                        bldAcc.addBox(px, py + bH * 0.5f, pz, bW, bH * 0.5f, bW, tint, tint, tint + 0.05f, 1f, 1f, 1f, 2f)
                        // Streetlamp closer to barrier
                        val lx = s.pos.x + s.right.x * ((hw + 1.8f) * side)
                        val lz = s.pos.z + s.right.z * ((hw + 1.8f) * side)
                        propAcc.addBox(lx, s.pos.y + 3.2f, lz, 0.14f, 3.2f, 0.14f, 0.35f, 0.38f, 0.42f)
                        propAcc.addBox(lx - s.right.x * side * 0.9f, s.pos.y + 6.4f, lz - s.right.z * side * 0.9f, 0.45f, 0.12f, 0.22f, 0.95f, 0.95f, 0.85f)
                    }

                    TrackEnvironmentType.COASTAL_HIGHWAY -> {
                        // Palm tree trunk + frond crown
                        val h = 7.5f + rng.nextFloat() * 4f
                        propAcc.addCylinderY(px, py, pz, 0.32f, 0.18f, h, 6, 0.45f, 0.32f, 0.20f)
                        propAcc.addBox(px, py + h + 0.3f, pz, 2.4f, 0.35f, 0.7f, 0.14f, 0.55f, 0.22f, 1f, 0.6f, 0.6f)
                        propAcc.addBox(px, py + h + 0.3f, pz, 0.7f, 0.35f, 2.4f, 0.16f, 0.60f, 0.25f, 1f, 0.6f, 0.6f)
                        if (rng.nextFloat() > 0.65f) {
                            // Coastal resort villa / tower
                            val bH = 9f + rng.nextFloat() * 14f
                            bldAcc.addBox(px + s.right.x * side * 14f, py + bH * 0.5f, pz + s.right.z * side * 14f, 8f, bH * 0.5f, 6f, 0.92f, 0.88f, 0.80f, 1f, 1f, 1f, 1f)
                        }
                    }

                    TrackEnvironmentType.MOUNTAIN_ALPINE -> {
                        // Tiered pine tree
                        val trunkH = 3.5f
                        propAcc.addCylinderY(px, py, pz, 0.34f, 0.22f, trunkH, 6, 0.32f, 0.22f, 0.14f)
                        propAcc.addCylinderY(px, py + 2.6f, pz, 2.5f, 0.1f, 4.5f, 7, 0.10f, 0.34f, 0.16f)
                        propAcc.addCylinderY(px, py + 5.2f, pz, 1.9f, 0.1f, 4.0f, 7, 0.12f, 0.40f, 0.19f)
                        if (rng.nextFloat() > 0.6f) {
                            // Alpine rock cliff
                            val rx = px + s.right.x * side * 16f
                            val rz = pz + s.right.z * side * 16f
                            val rh = 16f + rng.nextFloat() * 26f
                            propAcc.addBox(rx, py + rh * 0.45f, rz, 10f, rh * 0.5f, 10f, 0.42f, 0.44f, 0.48f, 1f, 0.45f, 0.45f)
                        }
                    }

                    TrackEnvironmentType.DESERT_SUNSET -> {
                        if (rng.nextFloat() > 0.45f) {
                            // Sandstone desert mesa / rock spire
                            val mh = 12f + rng.nextFloat() * 28f
                            val mw = 7f + rng.nextFloat() * 10f
                            propAcc.addBox(px + s.right.x * side * 10f, py + mh * 0.45f, pz + s.right.z * side * 10f, mw, mh * 0.5f, mw, 0.72f, 0.36f, 0.22f, 1f, 0.68f, 0.68f)
                        } else {
                            // Saguaro cactus
                            val ch = 4.2f + rng.nextFloat() * 2.5f
                            propAcc.addCylinderY(px, py, pz, 0.26f, 0.22f, ch, 6, 0.18f, 0.44f, 0.20f)
                            propAcc.addBox(px + 0.55f, py + ch * 0.62f, pz, 0.45f, 0.18f, 0.18f, 0.18f, 0.44f, 0.20f)
                            propAcc.addCylinderY(px + 0.9f, py + ch * 0.62f, pz, 0.17f, 0.15f, 1.3f, 5, 0.18f, 0.44f, 0.20f)
                        }
                    }
                }
            }
        }

        buildingsMesh = bldAcc.build()
        foliageAndPropsMesh = propAcc.build()
    }

    fun release() {
        roadMesh.release()
        finishLineMesh.release()
        gantryAndBarriersMesh.release()
        groundMesh.release()
        buildingsMesh.release()
        foliageAndPropsMesh.release()
    }
}

object ShowroomMeshFactory {
    fun createPedestalMesh(): GlMesh {
        val acc = MeshAccumulator()
        // Outer metallic ring
        acc.addCylinderY(0f, -0.22f, 0f, 3.6f, 3.4f, 0.22f, 36, 0.14f, 0.17f, 0.24f)
        // Glowing accent rim
        acc.addCylinderY(0f, -0.02f, 0f, 3.42f, 3.38f, 0.04f, 36, 0.95f, 0.18f, 0.30f)
        // Floor studio disc
        acc.addCylinderY(0f, -0.26f, 0f, 18f, 18f, 0.04f, 28, 0.06f, 0.08f, 0.12f)
        return acc.build()
    }

    fun createCockpitDashboardMesh(): GlMesh {
        val acc = MeshAccumulator()
        // Lower dash cowl
        acc.addBox(0f, -0.35f, -0.78f, 0.95f, 0.18f, 0.26f, 0.09f, 0.10f, 0.12f)
        // Left & right A-pillars
        acc.addBox(-0.68f, 0.15f, -0.68f, 0.045f, 0.42f, 0.055f, 0.07f, 0.08f, 0.10f)
        acc.addBox(0.68f, 0.15f, -0.68f, 0.045f, 0.42f, 0.055f, 0.07f, 0.08f, 0.10f)
        // Top roof header strip
        acc.addBox(0f, 0.54f, -0.66f, 0.72f, 0.05f, 0.08f, 0.06f, 0.07f, 0.09f)
        return acc.build()
    }

    fun createSteeringWheelMesh(): GlMesh {
        val acc = MeshAccumulator()
        // Wheel hub
        acc.addBox(0f, 0f, 0f, 0.09f, 0.07f, 0.04f, 0.12f, 0.13f, 0.16f)
        // Top, bottom, left, right rim segments (flat-bottom motorsport wheel)
        acc.addBox(0f, 0.15f, 0f, 0.15f, 0.024f, 0.024f, 0.85f, 0.15f, 0.25f)
        acc.addBox(0f, -0.14f, 0f, 0.13f, 0.024f, 0.024f, 0.16f, 0.17f, 0.20f)
        acc.addBox(-0.15f, 0f, 0f, 0.024f, 0.14f, 0.024f, 0.16f, 0.17f, 0.20f)
        acc.addBox(0.15f, 0f, 0f, 0.024f, 0.14f, 0.024f, 0.16f, 0.17f, 0.20f)
        return acc.build()
    }
}
