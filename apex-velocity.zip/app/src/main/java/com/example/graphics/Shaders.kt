package com.example.graphics

import android.opengl.GLES30
import android.util.Log

class ShaderProgram(vertexSrc: String, fragmentSrc: String) {
    val programId: Int

    init {
        val vs = compileShader(GLES30.GL_VERTEX_SHADER, vertexSrc)
        val fs = compileShader(GLES30.GL_FRAGMENT_SHADER, fragmentSrc)
        programId = GLES30.glCreateProgram()
        GLES30.glAttachShader(programId, vs)
        GLES30.glAttachShader(programId, fs)
        GLES30.glLinkProgram(programId)
        val linkStatus = IntArray(1)
        GLES30.glGetProgramiv(programId, GLES30.GL_LINK_STATUS, linkStatus, 0)
        if (linkStatus[0] == 0) {
            Log.e("ShaderProgram", "Link error: ${GLES30.glGetProgramInfoLog(programId)}")
            GLES30.glDeleteProgram(programId)
        }
        GLES30.glDeleteShader(vs)
        GLES30.glDeleteShader(fs)
    }

    fun use() {
        GLES30.glUseProgram(programId)
    }

    fun uniformLocation(name: String): Int = GLES30.glGetUniformLocation(programId, name)

    fun release() {
        GLES30.glDeleteProgram(programId)
    }

    private fun compileShader(type: Int, src: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, src)
        GLES30.glCompileShader(shader)
        val status = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            Log.e("ShaderProgram", "Compile error: ${GLES30.glGetShaderInfoLog(shader)}")
        }
        return shader
    }
}

object Shaders {
    const val SKY_VS = """#version 300 es
layout(location = 0) in vec2 aPos;
out vec2 vUv;
void main() {
    vUv = aPos * 0.5 + 0.5;
    gl_Position = vec4(aPos, 0.999, 1.0);
}
"""

    const val SKY_FS = """#version 300 es
precision mediump float;
in vec2 vUv;
uniform vec3 uSkyTop;
uniform vec3 uSkyHorizon;
uniform vec3 uSunColor;
uniform vec2 uSunScreenPos;
uniform float uSunVisible;
out vec4 fragColor;

void main() {
    float h = clamp(vUv.y, 0.0, 1.0);
    float curve = pow(h, 0.65);
    vec3 col = mix(uSkyHorizon, uSkyTop, curve);
    if (uSunVisible > 0.5) {
        vec2 d = vUv - uSunScreenPos;
        d.x *= 1.75;
        float dist = length(d);
        float halo = exp(-dist * 5.0) * 0.45;
        float disc = smoothstep(0.055, 0.025, dist) * 0.9;
        col += uSunColor * (halo + disc);
    }
    fragColor = vec4(col, 1.0);
}
"""

    const val WORLD_VS = """#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec2 aUv;
layout(location = 3) in vec4 aColor;

uniform mat4 uMVP;
uniform mat4 uModel;

out vec3 vWorldPos;
out vec3 vNormal;
out vec2 vUv;
out vec4 vColor;

void main() {
    vec4 wp = uModel * vec4(aPos, 1.0);
    vWorldPos = wp.xyz;
    vNormal = normalize(mat3(uModel) * aNormal);
    vUv = aUv;
    vColor = aColor;
    gl_Position = uMVP * vec4(aPos, 1.0);
}
"""

    const val WORLD_FS = """#version 300 es
precision mediump float;
in vec3 vWorldPos;
in vec3 vNormal;
in vec2 vUv;
in vec4 vColor;

uniform sampler2D uTex;
uniform vec3 uCamPos;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform vec3 uAmbientColor;
uniform vec3 uFogColor;
uniform float uFogDensity;
uniform float uSpecularStrength;

out vec4 fragColor;

void main() {
    vec4 tex = texture(uTex, vUv);
    vec3 baseCol = tex.rgb * vColor.rgb;
    float alpha = tex.a * vColor.a;

    vec3 N = normalize(vNormal);
    vec3 L = normalize(uSunDir);
    vec3 V = normalize(uCamPos - vWorldPos);
    vec3 H = normalize(L + V);

    float ndotl = max(dot(N, L), 0.0);
    float hemi = N.y * 0.5 + 0.5;
    vec3 ambient = uAmbientColor * mix(0.65, 1.15, hemi);
    float spec = pow(max(dot(N, H), 0.0), 48.0) * uSpecularStrength;

    vec3 lit = baseCol * (ambient + uSunColor * ndotl * 0.92) + uSunColor * spec;

    float dist = length(uCamPos - vWorldPos);
    float fogFactor = 1.0 - exp(-pow(dist * uFogDensity, 1.8));
    fogFactor = clamp(fogFactor, 0.0, 1.0);

    vec3 finalCol = mix(lit, uFogColor, fogFactor);
    fragColor = vec4(finalCol, alpha);
}
"""

    const val CAR_VS = """#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec2 aUv;
layout(location = 3) in vec4 aColor;

uniform mat4 uMVP;
uniform mat4 uModel;

out vec3 vWorldPos;
out vec3 vNormal;
out vec4 vColor;

void main() {
    vec4 wp = uModel * vec4(aPos, 1.0);
    vWorldPos = wp.xyz;
    vNormal = normalize(mat3(uModel) * aNormal);
    vColor = aColor;
    gl_Position = uMVP * vec4(aPos, 1.0);
}
"""

    const val CAR_FS = """#version 300 es
precision mediump float;
in vec3 vWorldPos;
in vec3 vNormal;
in vec4 vColor;

uniform vec3 uCamPos;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform vec3 uAmbientColor;
uniform vec3 uFogColor;
uniform vec3 uSkyTop;
uniform vec3 uSkyHorizon;
uniform float uFogDensity;
uniform vec3 uPaintTint;
uniform float uUseTint;
uniform float uMetallic;
uniform float uEmissive;

out vec4 fragColor;

void main() {
    vec3 baseCol = mix(vColor.rgb, uPaintTint, uUseTint);
    if (uEmissive > 0.01) {
        vec3 em = baseCol * uEmissive;
        float dist = length(uCamPos - vWorldPos);
        float fog = clamp(1.0 - exp(-pow(dist * uFogDensity, 1.8)), 0.0, 0.85);
        fragColor = vec4(mix(em, uFogColor, fog), vColor.a);
        return;
    }

    vec3 N = normalize(vNormal);
    vec3 L = normalize(uSunDir);
    vec3 V = normalize(uCamPos - vWorldPos);
    vec3 H = normalize(L + V);
    vec3 R = reflect(-V, N);

    float ndotl = max(dot(N, L), 0.0);
    float fresnel = pow(1.0 - max(dot(N, V), 0.0), 3.2);
    float spec = pow(max(dot(N, H), 0.0), mix(36.0, 96.0, uMetallic));

    vec3 envRef = mix(uSkyHorizon, uSkyTop, clamp(R.y * 0.5 + 0.5, 0.0, 1.0));
    vec3 diffuse = baseCol * (uAmbientColor * 1.1 + uSunColor * ndotl * 0.95);
    vec3 clearcoat = envRef * (0.14 + 0.62 * fresnel * uMetallic) + uSunColor * spec * (0.45 + 0.75 * uMetallic);

    vec3 lit = diffuse + clearcoat;
    float dist = length(uCamPos - vWorldPos);
    float fogFactor = clamp(1.0 - exp(-pow(dist * uFogDensity, 1.8)), 0.0, 1.0);
    fragColor = vec4(mix(lit, uFogColor, fogFactor), vColor.a);
}
"""

    const val PARTICLE_VS = """#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUv;
layout(location = 2) in vec4 aColor;

uniform mat4 uVP;

out vec2 vUv;
out vec4 vColor;

void main() {
    vUv = aUv;
    vColor = aColor;
    gl_Position = uVP * vec4(aPos, 1.0);
}
"""

    const val PARTICLE_FS = """#version 300 es
precision mediump float;
in vec2 vUv;
in vec4 vColor;
uniform sampler2D uTex;
out vec4 fragColor;

void main() {
    vec4 tex = texture(uTex, vUv);
    fragColor = vec4(vColor.rgb * tex.rgb, vColor.a * tex.a);
}
"""
}
