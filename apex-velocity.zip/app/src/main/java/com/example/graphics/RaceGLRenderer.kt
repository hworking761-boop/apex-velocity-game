package com.example.graphics

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.example.engine.Math3D
import com.example.engine.RaceHudSnapshot
import com.example.engine.RaceSimulation
import com.example.engine.RacerState
import com.example.model.CameraMode
import com.example.model.CarCatalog
import com.example.model.CarSpec
import com.example.model.GraphicsQuality
import com.example.model.PaintCatalog
import com.example.model.TimeOfDay
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

sealed interface SceneRenderTarget {
    data class Showroom(
        val carId: String,
        val paintId: String,
        val autoRotate: Boolean
    ) : SceneRenderTarget

    data class Race(
        val simulation: RaceSimulation
    ) : SceneRenderTarget
}

class RaceGLRenderer(
    private val onHudTick: (RaceHudSnapshot) -> Unit = {}
) : GLSurfaceView.Renderer {

    @Volatile
    var renderTarget: SceneRenderTarget = SceneRenderTarget.Showroom("valkyrie_gtr", "crimson_rush", true)

    @Volatile
    var graphicsQuality: GraphicsQuality = GraphicsQuality.MEDIUM

    @Volatile
    var cameraMode: CameraMode = CameraMode.CHASE

    // Showroom orbit state
    @Volatile
    var showroomYawDeg: Float = 38f
    @Volatile
    var showroomPitchDeg: Float = 14f
    @Volatile
    var showroomDistance: Float = 5.4f

    private lateinit var skyShader: ShaderProgram
    private lateinit var worldShader: ShaderProgram
    private lateinit var carShader: ShaderProgram
    private lateinit var particleShader: ShaderProgram
    private lateinit var textures: TextureBundle

    private var skyQuadVao = 0
    private var skyQuadVbo = 0

    // Dynamic buffers for particles & skid marks
    private var dynVao = 0
    private var dynVbo = 0
    private val maxDynFloats = 2500 * 9
    private val dynFloatArray = FloatArray(maxDynFloats)
    private lateinit var dynBuffer: FloatBuffer

    private val carMeshes = HashMap<String, CarMeshSet>()
    private var cachedTrackId: String? = null
    private var cachedPropStep: Int = -1
    private var trackMeshSet: TrackMeshSet? = null
    private lateinit var pedestalMesh: GlMesh
    private lateinit var cockpitDashMesh: GlMesh
    private lateinit var steeringWheelMesh: GlMesh

    private val projMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val vpMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    private var aspectRatio = 16f / 9f
    private var lastFrameNs = System.nanoTime()
    private var hudNotifyAccum = 0f

    // Smooth race camera state
    private var camX = 0f
    private var camY = 4f
    private var camZ = 10f
    private var camLookX = 0f
    private var camLookY = 1f
    private var camLookZ = 0f
    private var camFov = 60f
    private var cameraInitialized = false

    fun resetCameraState() {
        cameraInitialized = false
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        GLES30.glCullFace(GLES30.GL_BACK)
        GLES30.glClearColor(0.05f, 0.07f, 0.11f, 1f)

        skyShader = ShaderProgram(Shaders.SKY_VS, Shaders.SKY_FS)
        worldShader = ShaderProgram(Shaders.WORLD_VS, Shaders.WORLD_FS)
        carShader = ShaderProgram(Shaders.CAR_VS, Shaders.CAR_FS)
        particleShader = ShaderProgram(Shaders.PARTICLE_VS, Shaders.PARTICLE_FS)
        textures = TextureBundle()

        initSkyQuad()
        initDynamicBuffer()

        CarCatalog.cars.forEach { spec ->
            carMeshes[spec.id] = CarMeshSet(spec)
        }
        pedestalMesh = ShowroomMeshFactory.createPedestalMesh()
        cockpitDashMesh = ShowroomMeshFactory.createCockpitDashboardMesh()
        steeringWheelMesh = ShowroomMeshFactory.createSteeringWheelMesh()
        lastFrameNs = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES30.glViewport(0, 0, width, height)
        aspectRatio = width.toFloat() / height.coerceAtLeast(1).toFloat()
    }

    override fun onDrawFrame(gl: GL10?) {
        val nowNs = System.nanoTime()
        val dt = ((nowNs - lastFrameNs) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
        lastFrameNs = nowNs

        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        when (val target = renderTarget) {
            is SceneRenderTarget.Showroom -> drawShowroom(target, dt)
            is SceneRenderTarget.Race -> drawRace(target, dt)
        }
    }

    private fun drawShowroom(target: SceneRenderTarget.Showroom, dt: Float) {
        if (target.autoRotate) {
            showroomYawDeg = (showroomYawDeg + dt * 22f) % 360f
        }
        val spec = CarCatalog.findById(target.carId)
        val paint = PaintCatalog.findById(target.paintId)

        val yawRad = Math.toRadians(showroomYawDeg.toDouble()).toFloat()
        val pitchRad = Math.toRadians(showroomPitchDeg.coerceIn(5f, 45f).toDouble()).toFloat()
        val dist = showroomDistance.coerceIn(3.6f, 8.0f)

        val cx = dist * cos(pitchRad) * sin(yawRad)
        val cy = 0.85f + dist * sin(pitchRad)
        val cz = dist * cos(pitchRad) * cos(yawRad)

        Matrix.perspectiveM(projMatrix, 0, 44f, aspectRatio, 0.2f, 120f)
        Matrix.setLookAtM(viewMatrix, 0, cx, cy, cz, 0f, 0.58f, 0f, 0f, 1f, 0f)
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        val skyTop = floatArrayOf(0.04f, 0.06f, 0.11f)
        val skyHorizon = floatArrayOf(0.11f, 0.16f, 0.25f)
        val sunDir = floatArrayOf(0.6f, 0.85f, 0.45f)
        val sunCol = floatArrayOf(0.95f, 0.96f, 1.0f)
        val ambCol = floatArrayOf(0.32f, 0.36f, 0.44f)

        drawSky(skyTop, skyHorizon, sunCol, sunVisible = false, sunX = 0.5f, sunY = 0.7f)

        // Draw studio turntable pedestal
        worldShader.use()
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, modelMatrix, 0)
        GLES30.glUniformMatrix4fv(worldShader.uniformLocation("uMVP"), 1, false, mvpMatrix, 0)
        GLES30.glUniformMatrix4fv(worldShader.uniformLocation("uModel"), 1, false, modelMatrix, 0)
        GLES30.glUniform3f(worldShader.uniformLocation("uCamPos"), cx, cy, cz)
        GLES30.glUniform3fv(worldShader.uniformLocation("uSunDir"), 1, sunDir, 0)
        GLES30.glUniform3fv(worldShader.uniformLocation("uSunColor"), 1, sunCol, 0)
        GLES30.glUniform3fv(worldShader.uniformLocation("uAmbientColor"), 1, ambCol, 0)
        GLES30.glUniform3fv(worldShader.uniformLocation("uFogColor"), 1, skyHorizon, 0)
        GLES30.glUniform1f(worldShader.uniformLocation("uFogDensity"), 0.02f)
        GLES30.glUniform1f(worldShader.uniformLocation("uSpecularStrength"), 0.55f)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textures.whiteTex)
        GLES30.glUniform1i(worldShader.uniformLocation("uTex"), 0)
        pedestalMesh.draw()

        // Draw showcased car
        drawCarModel(
            spec = spec,
            x = 0f, y = 0f, z = 0f,
            yawRad = 0f, pitchRad = 0f, rollRad = 0f,
            steerVisualRad = 0.18f,
            wheelSpinRad = 0f,
            paintHexRgb = paint.hexRgb,
            metallic = paint.metallic,
            brakeActive = false,
            headlightIntensity = 1.15f,
            camX = cx, camY = cy, camZ = cz,
            sunDir = sunDir, sunCol = sunCol, ambCol = ambCol,
            fogCol = skyHorizon, fogDensity = 0.015f,
            skyTop = skyTop, skyHorizon = skyHorizon
        )
    }

    private fun drawRace(target: SceneRenderTarget.Race, dt: Float) {
        val sim = target.simulation
        val quality = graphicsQuality
        sim.step(dt, quality.maxParticles)

        hudNotifyAccum += dt
        if (hudNotifyAccum >= 0.05f) { // ~20Hz crisp Compose HUD telemetry updates
            hudNotifyAccum = 0f
            onHudTick(sim.buildHudSnapshot())
        }

        // Rebuild track mesh if track or quality prop density changed
        val trackDef = sim.track.definition
        if (cachedTrackId != trackDef.id || cachedPropStep != quality.propDensityStep) {
            trackMeshSet?.release()
            trackMeshSet = TrackMeshSet(sim.track, quality.propDensityStep)
            cachedTrackId = trackDef.id
            cachedPropStep = quality.propDensityStep
            cameraInitialized = false
        }

        val player = sim.player
        val tod: TimeOfDay = sim.config.timeOfDay
        updateRaceCamera(player, dt)

        Matrix.perspectiveM(projMatrix, 0, camFov, aspectRatio, 0.25f, quality.drawDistance)
        Matrix.setLookAtM(viewMatrix, 0, camX, camY, camZ, camLookX, camLookY, camLookZ, 0f, 1f, 0f)
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        // Compute sun screen projection for halo
        val sunVec = tod.sunDir
        val sunWorldX = camX + sunVec[0] * 100f
        val sunWorldY = camY + sunVec[1] * 100f
        val sunWorldZ = camZ + sunVec[2] * 100f
        val clip = FloatArray(4)
        Matrix.multiplyMV(clip, 0, vpMatrix, 0, floatArrayOf(sunWorldX, sunWorldY, sunWorldZ, 1f), 0)
        val sunVisible = clip[3] > 0.1f
        val sunSx = if (sunVisible) (clip[0] / clip[3]) * 0.5f + 0.5f else 0.5f
        val sunSy = if (sunVisible) (clip[1] / clip[3]) * 0.5f + 0.5f else 0.7f

        drawSky(tod.skyTopRgb, tod.skyHorizonRgb, tod.sunColor, sunVisible, sunSx, sunSy)

        val fogDensity = when (quality) {
            GraphicsQuality.LOW -> 0.0046f
            GraphicsQuality.MEDIUM -> 0.0030f
            GraphicsQuality.HIGH -> 0.0022f
        }

        val tMesh = trackMeshSet ?: return
        worldShader.use()
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, modelMatrix, 0)
        GLES30.glUniformMatrix4fv(worldShader.uniformLocation("uMVP"), 1, false, mvpMatrix, 0)
        GLES30.glUniformMatrix4fv(worldShader.uniformLocation("uModel"), 1, false, modelMatrix, 0)
        GLES30.glUniform3f(worldShader.uniformLocation("uCamPos"), camX, camY, camZ)
        GLES30.glUniform3fv(worldShader.uniformLocation("uSunDir"), 1, tod.sunDir, 0)
        GLES30.glUniform3fv(worldShader.uniformLocation("uSunColor"), 1, tod.sunColor, 0)
        GLES30.glUniform3fv(worldShader.uniformLocation("uAmbientColor"), 1, tod.ambientColor, 0)
        GLES30.glUniform3fv(worldShader.uniformLocation("uFogColor"), 1, tod.fogRgb, 0)
        GLES30.glUniform1f(worldShader.uniformLocation("uFogDensity"), fogDensity)
        GLES30.glUniform1i(worldShader.uniformLocation("uTex"), 0)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)

        // Ground & Ocean
        GLES30.glUniform1f(worldShader.uniformLocation("uSpecularStrength"), 0.12f)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textures.whiteTex)
        tMesh.groundMesh.draw()

        // Road surface with specular sheen
        GLES30.glUniform1f(worldShader.uniformLocation("uSpecularStrength"), 0.38f)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textures.roadTex)
        tMesh.roadMesh.draw()

        // Finish line
        GLES30.glUniform1f(worldShader.uniformLocation("uSpecularStrength"), 0.25f)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textures.finishTex)
        tMesh.finishLineMesh.draw()

        // Barriers & Gantry
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textures.whiteTex)
        tMesh.gantryAndBarriersMesh.draw()
        tMesh.foliageAndPropsMesh.draw()

        // Buildings with facade texture
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textures.buildingTex)
        tMesh.buildingsMesh.draw()

        // Skid marks on asphalt
        drawSkidMarks(sim)

        // Draw all racers
        for (racer in sim.racers) {
            if (racer.isPlayer && cameraMode == CameraMode.COCKPIT) {
                drawCockpitInterior(racer, tod)
                continue
            }
            if (racer.isPlayer && cameraMode == CameraMode.BUMPER) {
                continue
            }
            drawCarModel(
                spec = racer.carSpec,
                x = racer.x, y = racer.y, z = racer.z,
                yawRad = racer.yawRad, pitchRad = racer.pitchRad, rollRad = racer.rollRad,
                steerVisualRad = racer.steerVisualRad,
                wheelSpinRad = racer.wheelSpinRad,
                paintHexRgb = racer.paint.hexRgb,
                metallic = racer.paint.metallic,
                brakeActive = racer.brakeActive,
                headlightIntensity = tod.headlightIntensity,
                camX = camX, camY = camY, camZ = camZ,
                sunDir = tod.sunDir, sunCol = tod.sunColor, ambCol = tod.ambientColor,
                fogCol = tod.fogRgb, fogDensity = fogDensity,
                skyTop = tod.skyTopRgb, skyHorizon = tod.skyHorizonRgb,
                drawShadow = quality.enableShadows
            )
        }

        // Alpha-blended particles (tire smoke, nitro flame, sparks)
        drawParticles(sim)
    }

    private fun updateRaceCamera(player: RacerState, dt: Float) {
        val fwdX = -sin(player.yawRad)
        val fwdZ = -cos(player.yawRad)
        val shake = player.collisionFlash * 0.22f * sin(System.nanoTime() * 0.00004f)

        val targetFov = when (cameraMode) {
            CameraMode.CHASE -> if (player.nitroActive) 74f else 62f + (player.speedKmh / 360f) * 8f
            CameraMode.CLOSE_REAR -> if (player.nitroActive) 76f else 65f + (player.speedKmh / 360f) * 8f
            CameraMode.BUMPER -> if (player.nitroActive) 82f else 72f
            CameraMode.COCKPIT -> if (player.nitroActive) 76f else 68f
        }
        camFov = Math3D.lerp(camFov, targetFov, (dt * 7f).coerceAtMost(1f))

        val (tx, ty, tz, lx, ly, lz) = when (cameraMode) {
            CameraMode.CHASE -> FloatArray(6).apply {
                this[0] = player.x - fwdX * 6.4f + shake
                this[1] = player.y + 2.45f + shake * 0.5f
                this[2] = player.z - fwdZ * 6.4f
                this[3] = player.x + fwdX * 8f
                this[4] = player.y + 0.95f
                this[5] = player.z + fwdZ * 8f
            }
            CameraMode.CLOSE_REAR -> FloatArray(6).apply {
                this[0] = player.x - fwdX * 4.35f + shake
                this[1] = player.y + 1.55f
                this[2] = player.z - fwdZ * 4.35f
                this[3] = player.x + fwdX * 10f
                this[4] = player.y + 0.85f
                this[5] = player.z + fwdZ * 10f
            }
            CameraMode.BUMPER -> FloatArray(6).apply {
                this[0] = player.x + fwdX * (player.carSpec.lengthMeters * 0.45f)
                this[1] = player.y + 0.72f
                this[2] = player.z + fwdZ * (player.carSpec.lengthMeters * 0.45f)
                this[3] = player.x + fwdX * 20f
                this[4] = player.y + 0.65f
                this[5] = player.z + fwdZ * 20f
            }
            CameraMode.COCKPIT -> FloatArray(6).apply {
                this[0] = player.x + fwdX * 0.15f
                this[1] = player.y + player.carSpec.heightMeters * 0.72f
                this[2] = player.z + fwdZ * 0.15f
                this[3] = player.x + fwdX * 18f
                this[4] = player.y + player.carSpec.heightMeters * 0.68f
                this[5] = player.z + fwdZ * 18f
            }
        }

        if (!cameraInitialized || cameraMode == CameraMode.BUMPER || cameraMode == CameraMode.COCKPIT) {
            camX = tx; camY = ty; camZ = tz
            camLookX = lx; camLookY = ly; camLookZ = lz
            cameraInitialized = true
        } else {
            val posLerp = (dt * 11.5f).coerceAtMost(1f)
            val lookLerp = (dt * 15f).coerceAtMost(1f)
            camX = Math3D.lerp(camX, tx, posLerp)
            camY = Math3D.lerp(camY, ty, posLerp)
            camZ = Math3D.lerp(camZ, tz, posLerp)
            camLookX = Math3D.lerp(camLookX, lx, lookLerp)
            camLookY = Math3D.lerp(camLookY, ly, lookLerp)
            camLookZ = Math3D.lerp(camLookZ, lz, lookLerp)
        }
    }

    private fun drawCockpitInterior(player: RacerState, tod: TimeOfDay) {
        carShader.use()
        GLES30.glUniform3f(carShader.uniformLocation("uCamPos"), camX, camY, camZ)
        GLES30.glUniform3fv(carShader.uniformLocation("uSunDir"), 1, tod.sunDir, 0)
        GLES30.glUniform3fv(carShader.uniformLocation("uSunColor"), 1, tod.sunColor, 0)
        GLES30.glUniform3fv(carShader.uniformLocation("uAmbientColor"), 1, tod.ambientColor, 0)
        GLES30.glUniform3fv(carShader.uniformLocation("uFogColor"), 1, tod.fogRgb, 0)
        GLES30.glUniform3fv(carShader.uniformLocation("uSkyTop"), 1, tod.skyTopRgb, 0)
        GLES30.glUniform3fv(carShader.uniformLocation("uSkyHorizon"), 1, tod.skyHorizonRgb, 0)
        GLES30.glUniform1f(carShader.uniformLocation("uFogDensity"), 0.001f)
        GLES30.glUniform1f(carShader.uniformLocation("uUseTint"), 0f)
        GLES30.glUniform1f(carShader.uniformLocation("uMetallic"), 0.25f)
        GLES30.glUniform1f(carShader.uniformLocation("uEmissive"), 0f)

        // Dashboard cowl attached to camera/car frame
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, camX, camY, camZ)
        Matrix.rotateM(modelMatrix, 0, Math.toDegrees(player.yawRad.toDouble()).toFloat(), 0f, 1f, 0f)
        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, modelMatrix, 0)
        GLES30.glUniformMatrix4fv(carShader.uniformLocation("uMVP"), 1, false, mvpMatrix, 0)
        GLES30.glUniformMatrix4fv(carShader.uniformLocation("uModel"), 1, false, modelMatrix, 0)
        cockpitDashMesh.draw()

        // Rotating motorsport steering wheel
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, camX, camY, camZ)
        Matrix.rotateM(modelMatrix, 0, Math.toDegrees(player.yawRad.toDouble()).toFloat(), 0f, 1f, 0f)
        Matrix.translateM(modelMatrix, 0, 0f, -0.22f, -0.58f)
        Matrix.rotateM(modelMatrix, 0, Math.toDegrees(player.steerVisualRad.toDouble()).toFloat() * 1.9f, 0f, 0f, 1f)
        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, modelMatrix, 0)
        GLES30.glUniformMatrix4fv(carShader.uniformLocation("uMVP"), 1, false, mvpMatrix, 0)
        GLES30.glUniformMatrix4fv(carShader.uniformLocation("uModel"), 1, false, modelMatrix, 0)
        steeringWheelMesh.draw()
    }

    private fun drawCarModel(
        spec: CarSpec,
        x: Float, y: Float, z: Float,
        yawRad: Float, pitchRad: Float, rollRad: Float,
        steerVisualRad: Float,
        wheelSpinRad: Float,
        paintHexRgb: Int,
        metallic: Float,
        brakeActive: Boolean,
        headlightIntensity: Float,
        camX: Float, camY: Float, camZ: Float,
        sunDir: FloatArray, sunCol: FloatArray, ambCol: FloatArray,
        fogCol: FloatArray, fogDensity: Float,
        skyTop: FloatArray, skyHorizon: FloatArray,
        drawShadow: Boolean = true
    ) {
        val meshes = carMeshes[spec.id] ?: return
        val pr = ((paintHexRgb shr 16) and 0xFF) / 255f
        val pg = ((paintHexRgb shr 8) and 0xFF) / 255f
        val pb = (paintHexRgb and 0xFF) / 255f

        val baseModel = FloatArray(16)
        Matrix.setIdentityM(baseModel, 0)
        Matrix.translateM(baseModel, 0, x, y, z)
        Matrix.rotateM(baseModel, 0, Math.toDegrees(yawRad.toDouble()).toFloat(), 0f, 1f, 0f)
        Matrix.rotateM(baseModel, 0, Math.toDegrees(pitchRad.toDouble()).toFloat(), 1f, 0f, 0f)
        Matrix.rotateM(baseModel, 0, Math.toDegrees(rollRad.toDouble()).toFloat(), 0f, 0f, 1f)

        carShader.use()
        GLES30.glUniform3f(carShader.uniformLocation("uCamPos"), camX, camY, camZ)
        GLES30.glUniform3fv(carShader.uniformLocation("uSunDir"), 1, sunDir, 0)
        GLES30.glUniform3fv(carShader.uniformLocation("uSunColor"), 1, sunCol, 0)
        GLES30.glUniform3fv(carShader.uniformLocation("uAmbientColor"), 1, ambCol, 0)
        GLES30.glUniform3fv(carShader.uniformLocation("uFogColor"), 1, fogCol, 0)
        GLES30.glUniform3fv(carShader.uniformLocation("uSkyTop"), 1, skyTop, 0)
        GLES30.glUniform3fv(carShader.uniformLocation("uSkyHorizon"), 1, skyHorizon, 0)
        GLES30.glUniform1f(carShader.uniformLocation("uFogDensity"), fogDensity)

        // Contact shadow
        if (drawShadow) {
            GLES30.glEnable(GLES30.GL_BLEND)
            GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
            Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, baseModel, 0)
            GLES30.glUniformMatrix4fv(carShader.uniformLocation("uMVP"), 1, false, mvpMatrix, 0)
            GLES30.glUniformMatrix4fv(carShader.uniformLocation("uModel"), 1, false, baseModel, 0)
            GLES30.glUniform1f(carShader.uniformLocation("uUseTint"), 0f)
            GLES30.glUniform1f(carShader.uniformLocation("uMetallic"), 0f)
            GLES30.glUniform1f(carShader.uniformLocation("uEmissive"), 0f)
            meshes.shadowMesh.draw()
            GLES30.glDisable(GLES30.GL_BLEND)
        }

        // Painted body
        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, baseModel, 0)
        GLES30.glUniformMatrix4fv(carShader.uniformLocation("uMVP"), 1, false, mvpMatrix, 0)
        GLES30.glUniformMatrix4fv(carShader.uniformLocation("uModel"), 1, false, baseModel, 0)
        GLES30.glUniform3f(carShader.uniformLocation("uPaintTint"), pr, pg, pb)
        GLES30.glUniform1f(carShader.uniformLocation("uUseTint"), 1f)
        GLES30.glUniform1f(carShader.uniformLocation("uMetallic"), metallic)
        GLES30.glUniform1f(carShader.uniformLocation("uEmissive"), 0f)
        meshes.bodyMesh.draw()

        // Carbon trim
        GLES30.glUniform1f(carShader.uniformLocation("uUseTint"), 0f)
        GLES30.glUniform1f(carShader.uniformLocation("uMetallic"), 0.25f)
        meshes.trimMesh.draw()

        // Reflective glass
        GLES30.glUniform1f(carShader.uniformLocation("uMetallic"), 0.96f)
        meshes.glassMesh.draw()

        // Emissive LED headlights
        GLES30.glUniform1f(carShader.uniformLocation("uEmissive"), headlightIntensity)
        meshes.headlightMesh.draw()

        // Emissive taillights (brightens sharply when braking)
        GLES30.glUniform1f(carShader.uniformLocation("uEmissive"), if (brakeActive) 2.2f else 0.75f)
        meshes.taillightMesh.draw()

        // 4 Wheels (spinning + front wheels turning with steering angle)
        GLES30.glUniform1f(carShader.uniformLocation("uEmissive"), 0f)
        GLES30.glUniform1f(carShader.uniformLocation("uMetallic"), 0.55f)
        val wx = spec.widthMeters * 0.44f
        val wzFront = -spec.lengthMeters * 0.30f
        val wzRear = spec.lengthMeters * 0.30f
        val wy = spec.wheelRadius
        val spinDeg = Math.toDegrees((-wheelSpinRad).toDouble()).toFloat()
        val steerDeg = Math.toDegrees(steerVisualRad.toDouble()).toFloat()

        val wheelConfigs = arrayOf(
            floatArrayOf(-wx, wy, wzFront, steerDeg),
            floatArrayOf(wx, wy, wzFront, steerDeg),
            floatArrayOf(-wx, wy, wzRear, 0f),
            floatArrayOf(wx, wy, wzRear, 0f)
        )
        for (wc in wheelConfigs) {
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, wc[0], wc[1], wc[2])
            if (wc[3] != 0f) Matrix.rotateM(modelMatrix, 0, wc[3], 0f, 1f, 0f)
            Matrix.rotateM(modelMatrix, 0, spinDeg, 1f, 0f, 0f)
            val fullWheelMat = FloatArray(16)
            Matrix.multiplyMM(fullWheelMat, 0, baseModel, 0, modelMatrix, 0)
            Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, fullWheelMat, 0)
            GLES30.glUniformMatrix4fv(carShader.uniformLocation("uMVP"), 1, false, mvpMatrix, 0)
            GLES30.glUniformMatrix4fv(carShader.uniformLocation("uModel"), 1, false, fullWheelMat, 0)
            meshes.wheelMesh.draw()
        }
    }

    private fun drawSky(
        skyTop: FloatArray,
        skyHorizon: FloatArray,
        sunColor: FloatArray,
        sunVisible: Boolean,
        sunX: Float,
        sunY: Float
    ) {
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthMask(false)
        skyShader.use()
        GLES30.glUniform3fv(skyShader.uniformLocation("uSkyTop"), 1, skyTop, 0)
        GLES30.glUniform3fv(skyShader.uniformLocation("uSkyHorizon"), 1, skyHorizon, 0)
        GLES30.glUniform3fv(skyShader.uniformLocation("uSunColor"), 1, sunColor, 0)
        GLES30.glUniform2f(skyShader.uniformLocation("uSunScreenPos"), sunX, sunY)
        GLES30.glUniform1f(skyShader.uniformLocation("uSunVisible"), if (sunVisible) 1f else 0f)

        GLES30.glBindVertexArray(skyQuadVao)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        GLES30.glBindVertexArray(0)
        GLES30.glDepthMask(true)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
    }

    private fun drawSkidMarks(sim: RaceSimulation) {
        val segs = sim.skidMarks
        if (segs.isEmpty()) return

        var count = 0
        val halfW = 0.16f
        for (s in segs) {
            if ((count + 6) * 9 >= maxDynFloats) break
            val ox = s.rx * halfW
            val oz = s.rz * halfW
            putDynVert(count++, s.x1 - ox, s.y1, s.z1 - oz, 0.5f, 0.5f, 0.04f, 0.04f, 0.05f, 0.58f)
            putDynVert(count++, s.x1 + ox, s.y1, s.z1 + oz, 0.5f, 0.5f, 0.04f, 0.04f, 0.05f, 0.58f)
            putDynVert(count++, s.x2 + ox, s.y2, s.z2 + oz, 0.5f, 0.5f, 0.04f, 0.04f, 0.05f, 0.58f)

            putDynVert(count++, s.x1 - ox, s.y1, s.z1 - oz, 0.5f, 0.5f, 0.04f, 0.04f, 0.05f, 0.58f)
            putDynVert(count++, s.x2 + ox, s.y2, s.z2 + oz, 0.5f, 0.5f, 0.04f, 0.04f, 0.05f, 0.58f)
            putDynVert(count++, s.x2 - ox, s.y2, s.z2 - oz, 0.5f, 0.5f, 0.04f, 0.04f, 0.05f, 0.58f)
        }
        drawDynTriangles(count, textures.whiteTex, additive = false)
    }

    private fun drawParticles(sim: RaceSimulation) {
        val rightX = viewMatrix[0]
        val rightY = viewMatrix[4]
        val rightZ = viewMatrix[8]
        val upX = viewMatrix[1]
        val upY = viewMatrix[5]
        val upZ = viewMatrix[9]

        var count = 0
        for (p in sim.particles) {
            if (!p.active) continue
            if ((count + 6) * 9 >= maxDynFloats) break
            val lifeFrac = (p.life / p.maxLife).coerceIn(0f, 1f)
            val a = p.alpha * lifeFrac
            val hs = p.size * 0.5f

            val x0 = p.x - rightX * hs - upX * hs
            val y0 = p.y - rightY * hs - upY * hs
            val z0 = p.z - rightZ * hs - upZ * hs

            val x1 = p.x + rightX * hs - upX * hs
            val y1 = p.y + rightY * hs - upY * hs
            val z1 = p.z + rightZ * hs - upZ * hs

            val x2 = p.x + rightX * hs + upX * hs
            val y2 = p.y + rightY * hs + upY * hs
            val z2 = p.z + rightZ * hs + upZ * hs

            val x3 = p.x - rightX * hs + upX * hs
            val y3 = p.y - rightY * hs + upY * hs
            val z3 = p.z - rightZ * hs + upZ * hs

            putDynVert(count++, x0, y0, z0, 0f, 0f, p.r, p.g, p.b, a)
            putDynVert(count++, x1, y1, z1, 1f, 0f, p.r, p.g, p.b, a)
            putDynVert(count++, x2, y2, z2, 1f, 1f, p.r, p.g, p.b, a)

            putDynVert(count++, x0, y0, z0, 0f, 0f, p.r, p.g, p.b, a)
            putDynVert(count++, x2, y2, z2, 1f, 1f, p.r, p.g, p.b, a)
            putDynVert(count++, x3, y3, z3, 0f, 1f, p.r, p.g, p.b, a)
        }
        if (count > 0) {
            drawDynTriangles(count, textures.particleTex, additive = false)
        }
    }

    private fun putDynVert(idx: Int, x: Float, y: Float, z: Float, u: Float, v: Float, r: Float, g: Float, b: Float, a: Float) {
        val base = idx * 9
        dynFloatArray[base] = x
        dynFloatArray[base + 1] = y
        dynFloatArray[base + 2] = z
        dynFloatArray[base + 3] = u
        dynFloatArray[base + 4] = v
        dynFloatArray[base + 5] = r
        dynFloatArray[base + 6] = g
        dynFloatArray[base + 7] = b
        dynFloatArray[base + 8] = a
    }

    private fun drawDynTriangles(vertexCount: Int, texId: Int, additive: Boolean) {
        if (vertexCount <= 0) return
        dynBuffer.clear()
        dynBuffer.put(dynFloatArray, 0, vertexCount * 9)
        dynBuffer.position(0)

        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(
            GLES30.GL_SRC_ALPHA,
            if (additive) GLES30.GL_ONE else GLES30.GL_ONE_MINUS_SRC_ALPHA
        )
        GLES30.glDepthMask(false)
        GLES30.glDisable(GLES30.GL_CULL_FACE)

        particleShader.use()
        GLES30.glUniformMatrix4fv(particleShader.uniformLocation("uVP"), 1, false, vpMatrix, 0)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, texId)
        GLES30.glUniform1i(particleShader.uniformLocation("uTex"), 0)

        GLES30.glBindVertexArray(dynVao)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, dynVbo)
        GLES30.glBufferSubData(GLES30.GL_ARRAY_BUFFER, 0, vertexCount * 9 * 4, dynBuffer)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, vertexCount)
        GLES30.glBindVertexArray(0)

        GLES30.glEnable(GLES30.GL_CULL_FACE)
        GLES30.glDepthMask(true)
        GLES30.glDisable(GLES30.GL_BLEND)
    }

    private fun initSkyQuad() {
        val quad = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
        val buf = ByteBuffer.allocateDirect(quad.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        buf.put(quad).position(0)
        val vaos = IntArray(1); val vbos = IntArray(1)
        GLES30.glGenVertexArrays(1, vaos, 0)
        GLES30.glGenBuffers(1, vbos, 0)
        skyQuadVao = vaos[0]; skyQuadVbo = vbos[0]
        GLES30.glBindVertexArray(skyQuadVao)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, skyQuadVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, quad.size * 4, buf, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 8, 0)
        GLES30.glBindVertexArray(0)
    }

    private fun initDynamicBuffer() {
        dynBuffer = ByteBuffer.allocateDirect(maxDynFloats * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        val vaos = IntArray(1); val vbos = IntArray(1)
        GLES30.glGenVertexArrays(1, vaos, 0)
        GLES30.glGenBuffers(1, vbos, 0)
        dynVao = vaos[0]; dynVbo = vbos[0]
        GLES30.glBindVertexArray(dynVao)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, dynVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, maxDynFloats * 4, null, GLES30.GL_DYNAMIC_DRAW)
        val stride = 9 * 4
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, stride, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, stride, 3 * 4)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 4, GLES30.GL_FLOAT, false, stride, 5 * 4)
        GLES30.glBindVertexArray(0)
    }

    private operator fun FloatArray.component1() = this[0]
    private operator fun FloatArray.component2() = this[1]
    private operator fun FloatArray.component3() = this[2]
    private operator fun FloatArray.component4() = this[3]
    private operator fun FloatArray.component5() = this[4]
    private operator fun FloatArray.component6() = this[5]
}
