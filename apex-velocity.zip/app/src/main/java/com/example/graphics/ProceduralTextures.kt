package com.example.graphics

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.opengl.GLES30
import android.opengl.GLUtils
import java.util.Random

class TextureBundle {
    val roadTex: Int
    val finishTex: Int
    val buildingTex: Int
    val particleTex: Int
    val whiteTex: Int

    init {
        roadTex = uploadBitmap(createAsphaltBitmap(), repeat = true)
        finishTex = uploadBitmap(createCheckeredBitmap(), repeat = true)
        buildingTex = uploadBitmap(createBuildingFacadeBitmap(), repeat = true)
        particleTex = uploadBitmap(createSoftParticleBitmap(), repeat = false)
        whiteTex = uploadBitmap(createWhiteBitmap(), repeat = true)
    }

    fun release() {
        val ids = intArrayOf(roadTex, finishTex, buildingTex, particleTex, whiteTex)
        GLES30.glDeleteTextures(ids.size, ids, 0)
    }

    private fun uploadBitmap(bmp: Bitmap, repeat: Boolean): Int {
        val texIds = IntArray(1)
        GLES30.glGenTextures(1, texIds, 0)
        val id = texIds[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id)
        val wrap = if (repeat) GLES30.GL_REPEAT else GLES30.GL_CLAMP_TO_EDGE
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, wrap)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, wrap)
        GLES30.glTexParameteri(
            GLES30.GL_TEXTURE_2D,
            GLES30.GL_TEXTURE_MIN_FILTER,
            GLES30.GL_LINEAR_MIPMAP_LINEAR
        )
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        bmp.recycle()
        return id
    }

    private fun createAsphaltBitmap(): Bitmap {
        val w = 512
        val h = 512
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint()

        // Asphalt base
        canvas.drawColor(Color.rgb(42, 45, 50))

        // Fine asphalt aggregate grain
        val rng = Random(42L)
        for (i in 0 until 18000) {
            val x = rng.nextInt(w).toFloat()
            val y = rng.nextInt(h).toFloat()
            val v = 30 + rng.nextInt(32)
            paint.color = Color.rgb(v, v + 2, v + 5)
            canvas.drawRect(x, y, x + 2f, y + 2f, paint)
        }

        // Subtle dark rubber racing tire grooves in both lanes
        paint.color = Color.argb(46, 16, 18, 22)
        canvas.drawRect(95f, 0f, 195f, h.toFloat(), paint)
        canvas.drawRect(317f, 0f, 417f, h.toFloat(), paint)

        // Red-and-white racing curbs on outer 6% edges
        val curbWidth = 28f
        val blockH = 64f
        var y = 0f
        var toggle = true
        while (y < h) {
            paint.color = if (toggle) Color.rgb(218, 36, 48) else Color.rgb(236, 238, 242)
            canvas.drawRect(0f, y, curbWidth, y + blockH, paint)
            canvas.drawRect(w - curbWidth, y, w.toFloat(), y + blockH, paint)
            toggle = !toggle
            y += blockH
        }

        // Crisp white outer road boundary lines
        paint.color = Color.rgb(235, 238, 242)
        canvas.drawRect(curbWidth + 8f, 0f, curbWidth + 16f, h.toFloat(), paint)
        canvas.drawRect(w - curbWidth - 16f, 0f, w - curbWidth - 8f, h.toFloat(), paint)

        // Dashed center lane divider
        paint.color = Color.rgb(245, 200, 66)
        canvas.drawRect(w * 0.5f - 4f, 24f, w * 0.5f + 4f, 160f, paint)
        canvas.drawRect(w * 0.5f - 4f, 280f, w * 0.5f + 4f, 416f, paint)

        return bmp
    }

    private fun createCheckeredBitmap(): Bitmap {
        val size = 256
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint()
        val cell = size / 8
        for (row in 0 until 8) {
            for (col in 0 until 8) {
                paint.color = if ((row + col) % 2 == 0) Color.WHITE else Color.rgb(18, 20, 26)
                canvas.drawRect(
                    (col * cell).toFloat(),
                    (row * cell).toFloat(),
                    ((col + 1) * cell).toFloat(),
                    ((row + 1) * cell).toFloat(),
                    paint
                )
            }
        }
        return bmp
    }

    private fun createBuildingFacadeBitmap(): Bitmap {
        val size = 256
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint()
        canvas.drawColor(Color.rgb(44, 52, 66))

        val rng = Random(1337L)
        val cols = 8
        val rows = 12
        val cw = size.toFloat() / cols
        val rh = size.toFloat() / rows
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val lit = rng.nextFloat() > 0.45f
                paint.color = if (lit) {
                    Color.rgb(180 + rng.nextInt(60), 195 + rng.nextInt(45), 215 + rng.nextInt(35))
                } else {
                    Color.rgb(28, 36, 52)
                }
                canvas.drawRect(c * cw + 3f, r * rh + 3f, (c + 1) * cw - 3f, (r + 1) * rh - 3f, paint)
            }
        }
        return bmp
    }

    private fun createSoftParticleBitmap(): Bitmap {
        val size = 128
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val half = size * 0.5f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = RadialGradient(
            half,
            half,
            half,
            intArrayOf(
                Color.argb(255, 255, 255, 255),
                Color.argb(170, 255, 255, 255),
                Color.argb(0, 255, 255, 255)
            ),
            floatArrayOf(0f, 0.45f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(half, half, half, paint)
        return bmp
    }

    private fun createWhiteBitmap(): Bitmap {
        val bmp = Bitmap.createBitmap(4, 4, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        return bmp
    }
}
