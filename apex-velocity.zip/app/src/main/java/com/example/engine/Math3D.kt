package com.example.engine

import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class Vec3(var x: Float = 0f, var y: Float = 0f, var z: Float = 0f) {
    fun set(nx: Float, ny: Float, nz: Float): Vec3 {
        x = nx
        y = ny
        z = nz
        return this
    }

    fun length(): Float = sqrt(x * x + y * y + z * z)

    fun normalized(): Vec3 {
        val len = length()
        return if (len > 1e-6f) Vec3(x / len, y / len, z / len) else Vec3(0f, 1f, 0f)
    }

    operator fun plus(other: Vec3): Vec3 = Vec3(x + other.x, y + other.y, z + other.z)
    operator fun minus(other: Vec3): Vec3 = Vec3(x - other.x, y - other.y, z - other.z)
    operator fun times(scalar: Float): Vec3 = Vec3(x * scalar, y * scalar, z * scalar)

    companion object {
        fun dot(a: Vec3, b: Vec3): Float = a.x * b.x + a.y * b.y + a.z * b.z

        fun cross(a: Vec3, b: Vec3): Vec3 = Vec3(
            a.y * b.z - a.z * b.y,
            a.z * b.x - a.x * b.z,
            a.x * b.y - a.y * b.x
        )

        fun lerp(a: Vec3, b: Vec3, t: Float): Vec3 = Vec3(
            a.x + (b.x - a.x) * t,
            a.y + (b.y - a.y) * t,
            a.z + (b.z - a.z) * t
        )
    }
}

object Math3D {
    const val TWO_PI = (2.0 * PI).toFloat()
    const val HALF_PI = (PI / 2.0).toFloat()

    fun clamp(value: Float, min: Float, max: Float): Float =
        when {
            value < min -> min
            value > max -> max
            else -> value
        }

    fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    fun wrapAngleRad(angle: Float): Float {
        var a = angle % TWO_PI
        if (a > PI.toFloat()) a -= TWO_PI
        if (a < -PI.toFloat()) a += TWO_PI
        return a
    }

    fun lerpAngleRad(from: Float, to: Float, t: Float): Float {
        val diff = wrapAngleRad(to - from)
        return wrapAngleRad(from + diff * t)
    }

    fun catmullRom(p0: Vec3, p1: Vec3, p2: Vec3, p3: Vec3, t: Float): Vec3 {
        val t2 = t * t
        val t3 = t2 * t
        val x = 0.5f * ((2f * p1.x) +
            (-p0.x + p2.x) * t +
            (2f * p0.x - 5f * p1.x + 4f * p2.x - p3.x) * t2 +
            (-p0.x + 3f * p1.x - 3f * p2.x + p3.x) * t3)
        val y = 0.5f * ((2f * p1.y) +
            (-p0.y + p2.y) * t +
            (2f * p0.y - 5f * p1.y + 4f * p2.y - p3.y) * t2 +
            (-p0.y + 3f * p1.y - 3f * p2.y + p3.y) * t3)
        val z = 0.5f * ((2f * p1.z) +
            (-p0.z + p2.z) * t +
            (2f * p0.z - 5f * p1.z + 4f * p2.z - p3.z) * t2 +
            (-p0.z + 3f * p1.z - 3f * p2.z + p3.z) * t3)
        return Vec3(x, y, z)
    }

    fun yawFromForwardXZ(dx: Float, dz: Float): Float = atan2(-dx, -dz)

    fun forwardFromYaw(yaw: Float): Vec3 = Vec3(-sin(yaw), 0f, -cos(yaw))

    fun rightFromYaw(yaw: Float): Vec3 = Vec3(cos(yaw), 0f, -sin(yaw))
}
