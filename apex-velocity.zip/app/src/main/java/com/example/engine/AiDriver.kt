package com.example.engine

import com.example.model.Difficulty
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class AiDriver(
    private val preferredLaneOffset: Float,
    private val difficulty: Difficulty,
    private val aggressionSeed: Float
) {
    private var laneTimer: Float = aggressionSeed * 3f
    private var dynamicLaneOffset: Float = preferredLaneOffset

    fun computeInput(
        self: RacerState,
        allRacers: List<RacerState>,
        track: TrackSpline,
        dt: Float
    ): DriverInput {
        laneTimer += dt
        if (laneTimer > 2.4f) {
            laneTimer = 0f
            dynamicLaneOffset = preferredLaneOffset + sin(aggressionSeed * 7f + self.distanceAlongTrack * 0.02f) * 1.4f
        }

        // Check if another car is close ahead and shift lane to overtake
        var overtakeShift = 0f
        for (other in allRacers) {
            if (other.id == self.id) continue
            val dz = ((other.distanceAlongTrack - self.distanceAlongTrack + track.totalLength) % track.totalLength)
            if (dz in 1.5f..18f && abs(other.lateralOffset - self.lateralOffset) < 2.8f) {
                overtakeShift = if (other.lateralOffset > 0f) -3.2f else 3.2f
                break
            }
        }

        val targetLane = Math3D.clamp(
            dynamicLaneOffset + overtakeShift,
            -(track.roadHalfWidth - 2.2f),
            track.roadHalfWidth - 2.2f
        )

        val lookaheadMeters = (16f + self.speedMps * 0.42f).coerceIn(16f, 44f)
        val targetSample = track.sampleAtDistance(self.distanceAlongTrack + lookaheadMeters)
        val targetX = targetSample.pos.x + targetSample.right.x * targetLane
        val targetZ = targetSample.pos.z + targetSample.right.z * targetLane

        val desiredYaw = Math3D.yawFromForwardXZ(targetX - self.x, targetZ - self.z)
        val angleDiff = Math3D.wrapAngleRad(desiredYaw - self.yawRad)
        // Positive steer = turn right = negative yawDelta -> steer = -angleDiff
        val steer = Math3D.clamp(-angleDiff * 2.1f, -1f, 1f)

        // Look further ahead for cornering brake check
        val farSample = track.sampleAtDistance(self.distanceAlongTrack + 52f)
        val cornerSeverity = maxOf(targetSample.curvature, farSample.curvature)
        val targetCornerSpeed = when {
            cornerSeverity > 0.14f -> 26f
            cornerSeverity > 0.08f -> 40f
            else -> 120f
        } * difficulty.aiSpeedMultiplier

        val shouldBrake = self.speedMps > targetCornerSpeed && abs(angleDiff) > 0.18f
        val throttle = if (shouldBrake) 0.15f else 1f
        val brake = if (shouldBrake) 0.65f else 0f
        val useNitro = !shouldBrake && cornerSeverity < 0.04f && abs(angleDiff) < 0.12f && self.nitroFuel > 35f

        return DriverInput(
            throttle = throttle,
            brake = brake,
            steer = steer,
            nitro = useNitro
        )
    }
}
