package com.example.engine

import com.example.model.TrackDefinition
import kotlin.math.abs
import kotlin.math.sqrt

data class TrackSample(
    val index: Int,
    val pos: Vec3,
    val forward: Vec3,
    val right: Vec3,
    val up: Vec3,
    val distanceAlong: Float,
    val curvature: Float
)

data class TrackProjection(
    val sampleIndex: Int,
    val sample: TrackSample,
    val lateralOffset: Float,
    val roadY: Float,
    val distanceAlong: Float,
    val normalizedProgress: Float
)

class TrackSpline(val definition: TrackDefinition) {
    val samples: List<TrackSample>
    val totalLength: Float
    val roadHalfWidth: Float = definition.roadHalfWidth
    val minimapPoints: List<Pair<Float, Float>>

    init {
        val rawPts = definition.waypoints.map { Vec3(it.x, it.y, it.z) }
        val denseCount = rawPts.size * 28
        val densePoints = ArrayList<Vec3>(denseCount)
        val n = rawPts.size
        for (i in 0 until n) {
            val p0 = rawPts[(i - 1 + n) % n]
            val p1 = rawPts[i]
            val p2 = rawPts[(i + 1) % n]
            val p3 = rawPts[(i + 2) % n]
            for (step in 0 until 28) {
                val t = step / 28f
                densePoints.add(Math3D.catmullRom(p0, p1, p2, p3, t))
            }
        }

        // Compute cumulative arc length
        val cumDist = FloatArray(densePoints.size + 1)
        var acc = 0f
        for (i in densePoints.indices) {
            val a = densePoints[i]
            val b = densePoints[(i + 1) % densePoints.size]
            val dx = b.x - a.x
            val dy = b.y - a.y
            val dz = b.z - a.z
            acc += sqrt(dx * dx + dy * dy + dz * dz)
            cumDist[i + 1] = acc
        }
        totalLength = acc

        // Resample to uniform arc-length samples (~420 samples for crisp road & smooth physics)
        val uniformCount = 420
        val uniformPos = ArrayList<Vec3>(uniformCount)
        var denseIdx = 0
        for (k in 0 until uniformCount) {
            val targetDist = (k.toFloat() / uniformCount) * totalLength
            while (denseIdx < densePoints.size - 1 && cumDist[denseIdx + 1] < targetDist) {
                denseIdx++
            }
            val d0 = cumDist[denseIdx]
            val d1 = cumDist[denseIdx + 1]
            val frac = if (d1 > d0 + 1e-5f) (targetDist - d0) / (d1 - d0) else 0f
            val a = densePoints[denseIdx]
            val b = densePoints[(denseIdx + 1) % densePoints.size]
            uniformPos.add(Vec3.lerp(a, b, frac))
        }

        val built = ArrayList<TrackSample>(uniformCount)
        val worldUp = Vec3(0f, 1f, 0f)
        for (i in 0 until uniformCount) {
            val prev = uniformPos[(i - 1 + uniformCount) % uniformCount]
            val curr = uniformPos[i]
            val next = uniformPos[(i + 1) % uniformCount]
            val prev2 = uniformPos[(i - 4 + uniformCount) % uniformCount]
            val next2 = uniformPos[(i + 4) % uniformCount]

            val fwd = (next - prev).normalized()
            val right = Vec3.cross(fwd, worldUp).normalized()
            val up = Vec3.cross(right, fwd).normalized()

            val f1 = (curr - prev2).normalized()
            val f2 = (next2 - curr).normalized()
            val crossY = f1.x * f2.z - f1.z * f2.x
            val curvature = abs(crossY)

            built.add(
                TrackSample(
                    index = i,
                    pos = curr,
                    forward = fwd,
                    right = right,
                    up = up,
                    distanceAlong = (i.toFloat() / uniformCount) * totalLength,
                    curvature = curvature
                )
            )
        }
        samples = built

        // Normalized 0..1 minimap points for HUD
        var minX = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var minZ = Float.MAX_VALUE
        var maxZ = -Float.MAX_VALUE
        for (s in samples) {
            if (s.pos.x < minX) minX = s.pos.x
            if (s.pos.x > maxX) maxX = s.pos.x
            if (s.pos.z < minZ) minZ = s.pos.z
            if (s.pos.z > maxZ) maxZ = s.pos.z
        }
        val span = maxOf(maxX - minX, maxZ - minZ, 1f)
        val padX = (span - (maxX - minX)) * 0.5f
        val padZ = (span - (maxZ - minZ)) * 0.5f
        minimapPoints = samples.filterIndexed { idx, _ -> idx % 3 == 0 }.map { s ->
            Pair((s.pos.x - minX + padX) / span, (s.pos.z - minZ + padZ) / span)
        }
    }

    fun normalizePointForMinimap(x: Float, z: Float): Pair<Float, Float> {
        var minX = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var minZ = Float.MAX_VALUE
        var maxZ = -Float.MAX_VALUE
        for (s in samples) {
            if (s.pos.x < minX) minX = s.pos.x
            if (s.pos.x > maxX) maxX = s.pos.x
            if (s.pos.z < minZ) minZ = s.pos.z
            if (s.pos.z > maxZ) maxZ = s.pos.z
        }
        val span = maxOf(maxX - minX, maxZ - minZ, 1f)
        val padX = (span - (maxX - minX)) * 0.5f
        val padZ = (span - (maxZ - minZ)) * 0.5f
        return Pair((x - minX + padX) / span, (z - minZ + padZ) / span)
    }

    fun sampleAtDistance(distance: Float): TrackSample {
        val wrapped = ((distance % totalLength) + totalLength) % totalLength
        val idx = ((wrapped / totalLength) * samples.size).toInt().coerceIn(0, samples.size - 1)
        return samples[idx]
    }

    fun projectToTrack(x: Float, z: Float, hintIndex: Int = -1): TrackProjection {
        val n = samples.size
        var bestIdx = 0
        var bestDistSq = Float.MAX_VALUE

        if (hintIndex in 0 until n) {
            val window = 26
            for (offset in -window..window) {
                val idx = (hintIndex + offset + n) % n
                val s = samples[idx]
                val dx = x - s.pos.x
                val dz = z - s.pos.z
                val d2 = dx * dx + dz * dz
                if (d2 < bestDistSq) {
                    bestDistSq = d2
                    bestIdx = idx
                }
            }
        }

        // Fallback global search if car jumped or hint missed
        if (bestDistSq > 45f * 45f || hintIndex !in 0 until n) {
            bestDistSq = Float.MAX_VALUE
            for (i in 0 until n) {
                val s = samples[i]
                val dx = x - s.pos.x
                val dz = z - s.pos.z
                val d2 = dx * dx + dz * dz
                if (d2 < bestDistSq) {
                    bestDistSq = d2
                    bestIdx = i
                }
            }
        }

        val sample = samples[bestIdx]
        val dx = x - sample.pos.x
        val dz = z - sample.pos.z
        val lateral = dx * sample.right.x + dz * sample.right.z
        val forwardProj = dx * sample.forward.x + dz * sample.forward.z
        val distAlong = ((sample.distanceAlong + forwardProj) % totalLength + totalLength) % totalLength
        val roadY = sample.pos.y + sample.forward.y * forwardProj

        return TrackProjection(
            sampleIndex = bestIdx,
            sample = sample,
            lateralOffset = lateral,
            roadY = roadY,
            distanceAlong = distAlong,
            normalizedProgress = (distAlong / totalLength).coerceIn(0f, 0.9999f)
        )
    }
}
