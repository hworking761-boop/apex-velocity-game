package com.example.engine

import com.example.model.CarSpec
import com.example.model.CarUpgradeLevels
import com.example.model.PaintFinish
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

data class DriverInput(
    val throttle: Float = 0f,
    val brake: Float = 0f,
    val steer: Float = 0f, // -1 (left) to +1 (right)
    val nitro: Boolean = false
)

class RacerState(
    val id: String,
    val driverName: String,
    val carSpec: CarSpec,
    val upgrades: CarUpgradeLevels,
    val paint: PaintFinish,
    val isPlayer: Boolean,
    val aiSkillMultiplier: Float = 1f
) {
    var x: Float = 0f
    var y: Float = 0f
    var z: Float = 0f
    var yawRad: Float = 0f
    var pitchRad: Float = 0f
    var rollRad: Float = 0f

    var speedMps: Float = 0f
    var lateralSpeedMps: Float = 0f
    var steerVisualRad: Float = 0f
    var wheelSpinRad: Float = 0f

    var throttleActive: Boolean = false
    var brakeActive: Boolean = false
    var nitroFuel: Float = 100f
    var nitroActive: Boolean = false
    var isDrifting: Boolean = false

    var gear: Int = 1
    var rpmNormalized: Float = 0.18f

    var lastSampleIndex: Int = 0
    var lateralOffset: Float = 0f
    var distanceAlongTrack: Float = 0f
    var normalizedProgress: Float = 0f
    var currentLap: Int = 1
    var highestSector: Int = 0
    var totalRaceDistance: Float = 0f

    var lapStartTimeMs: Long = 0L
    var currentLapMs: Long = 0L
    var bestLapMs: Long = 0L
    var finished: Boolean = false
    var finishTimeMs: Long = 0L

    var collisionFlash: Float = 0f

    val speedKmh: Float
        get() = abs(speedMps) * 3.6f

    fun stepPhysics(
        dt: Float,
        input: DriverInput,
        track: TrackSpline,
        raceElapsedMs: Long,
        totalLaps: Int
    ) {
        val topSpeedMps = (carSpec.effectiveTopSpeedKmh(upgrades) / 3.6f) * aiSkillMultiplier
        val accelBase = carSpec.effectiveAcceleration(upgrades) * aiSkillMultiplier
        val handling = carSpec.effectiveHandling(upgrades)
        val brakingForce = carSpec.effectiveBraking(upgrades)
        val nitroMult = carSpec.effectiveNitroPower(upgrades)

        // Nitro activation & recharge
        val wantsNitro = input.nitro && nitroFuel > 2f && speedMps > 8f && !finished
        if (wantsNitro) {
            nitroActive = true
            nitroFuel = max(0f, nitroFuel - 26f * dt)
        } else {
            nitroActive = false
            val passiveRecharge = if (isDrifting) 16f else 4.2f
            nitroFuel = min(100f, nitroFuel + passiveRecharge * dt)
        }

        val effectiveTopSpeed = if (nitroActive) topSpeedMps * nitroMult else topSpeedMps
        val effectiveAccel = if (nitroActive) accelBase * 1.48f else accelBase

        throttleActive = input.throttle > 0.05f
        brakeActive = input.brake > 0.05f

        // Longitudinal forces
        var accel = 0f
        if (input.throttle > 0.01f) {
            val speedRatio = (speedMps / effectiveTopSpeed).coerceIn(0f, 1.25f)
            val torqueCurve = (1.15f - 0.65f * speedRatio).coerceAtLeast(0.18f)
            accel += input.throttle * effectiveAccel * torqueCurve
        }

        if (input.brake > 0.01f) {
            if (speedMps > 1.5f) {
                accel -= input.brake * brakingForce
            } else {
                // Reverse gear
                accel -= input.brake * 14f
            }
        }

        // Aerodynamic drag & rolling resistance
        val drag = 0.0022f * speedMps * abs(speedMps) + 0.16f * speedMps
        val rollingResistance = if (abs(input.throttle) < 0.05f && abs(input.brake) < 0.05f) {
            speedMps * 0.45f
        } else 0f

        speedMps += (accel - drag - rollingResistance) * dt
        speedMps = speedMps.coerceIn(-18f, effectiveTopSpeed * 1.04f)

        // Steering & lateral drift dynamics
        val speedFactor = (abs(speedMps) / 14f).coerceIn(0f, 1f)
        val highSpeedStabilizer = 1f - (abs(speedMps) / 115f).coerceIn(0f, 0.38f)
        val maxSteerRate = (1.95f * handling) * speedFactor * highSpeedStabilizer
        val reverseDir = if (speedMps >= -0.2f) 1f else -1f

        val targetVisualSteer = -input.steer * 0.48f
        steerVisualRad = Math3D.lerp(steerVisualRad, targetVisualSteer, (dt * 12f).coerceAtMost(1f))

        // Positive steer input means steer RIGHT -> decreases yawRad in right-handed Y-up (-Z forward)
        val yawDelta = -input.steer * maxSteerRate * reverseDir * dt
        yawRad = Math3D.wrapAngleRad(yawRad + yawDelta)

        // Lateral slip when cornering hard at speed
        val centrifugalForce = -input.steer * speedMps * 0.36f * (if (input.brake > 0.1f) 1.38f else 1f)
        val gripRecovery = (4.6f * handling) * (if (input.brake > 0.2f && abs(input.steer) > 0.3f) 0.58f else 1f)
        lateralSpeedMps += (centrifugalForce - lateralSpeedMps * gripRecovery) * dt
        lateralSpeedMps = lateralSpeedMps.coerceIn(-18f, 18f)

        isDrifting = abs(lateralSpeedMps) > 3.1f && abs(speedMps) > 15f

        // Suspension body roll & pitch
        val targetRoll = (-input.steer * (speedMps / 65f) * 0.085f).coerceIn(-0.09f, 0.09f)
        rollRad = Math3D.lerp(rollRad, targetRoll, (dt * 8f).coerceAtMost(1f))

        // Integrate world position
        val fwdX = -sin(yawRad)
        val fwdZ = -cos(yawRad)
        val rightX = cos(yawRad)
        val rightZ = -sin(yawRad)

        x += (fwdX * speedMps + rightX * lateralSpeedMps) * dt
        z += (fwdZ * speedMps + rightZ * lateralSpeedMps) * dt

        wheelSpinRad = (wheelSpinRad + (speedMps / carSpec.wheelRadius) * dt) % Math3D.TWO_PI

        // Project onto spline & enforce road barrier collision
        val prevProgress = normalizedProgress
        val proj = track.projectToTrack(x, z, lastSampleIndex)
        lastSampleIndex = proj.sampleIndex
        y = proj.roadY

        val targetPitch = asin(Math3D.clamp(proj.sample.forward.y, -0.45f, 0.45f))
        pitchRad = Math3D.lerp(pitchRad, targetPitch, (dt * 10f).coerceAtMost(1f))

        val maxLat = track.roadHalfWidth - (carSpec.widthMeters * 0.48f)
        if (abs(proj.lateralOffset) > maxLat) {
            val sign = if (proj.lateralOffset > 0f) 1f else -1f
            val excess = abs(proj.lateralOffset) - maxLat
            x -= proj.sample.right.x * sign * excess
            z -= proj.sample.right.z * sign * excess
            lateralOffset = maxLat * sign

            // Align car gently along barrier and scrub some speed
            val wallYaw = Math3D.yawFromForwardXZ(proj.sample.forward.x, proj.sample.forward.z)
            yawRad = Math3D.lerpAngleRad(yawRad, wallYaw, 0.35f)
            speedMps *= 0.86f
            lateralSpeedMps *= -0.25f
            collisionFlash = max(collisionFlash, 0.85f)
        } else {
            lateralOffset = proj.lateralOffset
        }

        collisionFlash = max(0f, collisionFlash - dt * 3.2f)

        distanceAlongTrack = proj.distanceAlong
        normalizedProgress = proj.normalizedProgress

        // Checkpoint sector progression (0 -> 1 -> 2 -> 3 -> lap+)
        val sector = when {
            normalizedProgress < 0.25f -> 0
            normalizedProgress < 0.50f -> 1
            normalizedProgress < 0.75f -> 2
            else -> 3
        }
        if (sector == highestSector + 1) {
            highestSector = sector
        }
        // Detect crossing start/finish line forward
        if (!finished && prevProgress > 0.82f && normalizedProgress < 0.18f && highestSector >= 3) {
            val completedLapDuration = raceElapsedMs - lapStartTimeMs
            if (completedLapDuration > 4000L && (bestLapMs == 0L || completedLapDuration < bestLapMs)) {
                bestLapMs = completedLapDuration
            }
            lapStartTimeMs = raceElapsedMs
            highestSector = 0
            if (currentLap >= totalLaps) {
                finished = true
                finishTimeMs = raceElapsedMs
            } else {
                currentLap++
            }
        }

        currentLapMs = if (finished) finishTimeMs - lapStartTimeMs else max(0L, raceElapsedMs - lapStartTimeMs)
        totalRaceDistance = ((currentLap - 1) * track.totalLength) +
            (if (highestSector == 0 && normalizedProgress > 0.85f) 0f else distanceAlongTrack)
        if (finished) {
            totalRaceDistance = totalLaps * track.totalLength + 1000f - (finishTimeMs / 1000f)
        }

        // Gear & RPM telemetry calculation
        updateGearAndRpm(effectiveTopSpeed)
    }

    private fun updateGearAndRpm(effectiveTopSpeed: Float) {
        val ratio = (abs(speedMps) / max(effectiveTopSpeed, 10f)).coerceIn(0f, 1.05f)
        val thresholds = floatArrayOf(0f, 0.17f, 0.34f, 0.52f, 0.70f, 0.86f, 1.15f)
        var g = 1
        for (i in 1..6) {
            if (ratio >= thresholds[i - 1]) g = i
        }
        gear = g
        val low = thresholds[g - 1]
        val high = thresholds[g]
        val gearFrac = ((ratio - low) / max(0.05f, high - low)).coerceIn(0f, 1f)
        rpmNormalized = (0.28f + gearFrac * 0.68f + if (nitroActive) 0.05f else 0f).coerceIn(0.18f, 0.99f)
    }
}
