package com.example.engine

import com.example.model.CarCatalog
import com.example.model.CarUpgradeLevels
import com.example.model.GameMode
import com.example.model.PaintCatalog
import com.example.model.RaceConfig
import com.example.model.RacerStanding
import com.example.model.TrackCatalog
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

enum class RacePhase {
    COUNTDOWN,
    RACING,
    PAUSED,
    FINISHED
}

data class Particle(
    var active: Boolean = false,
    var x: Float = 0f,
    var y: Float = 0f,
    var z: Float = 0f,
    var vx: Float = 0f,
    var vy: Float = 0f,
    var vz: Float = 0f,
    var life: Float = 0f,
    var maxLife: Float = 1f,
    var size: Float = 1f,
    var r: Float = 1f,
    var g: Float = 1f,
    var b: Float = 1f,
    var alpha: Float = 1f
)

data class SkidMarkSegment(
    val x1: Float,
    val y1: Float,
    val z1: Float,
    val x2: Float,
    val y2: Float,
    val z2: Float,
    val rx: Float,
    val rz: Float
)

data class RaceHudSnapshot(
    val phase: RacePhase = RacePhase.COUNTDOWN,
    val countdownValue: Int = 3,
    val goBannerTimer: Float = 0f,
    val speedKmh: Int = 0,
    val gear: Int = 1,
    val rpmNormalized: Float = 0.2f,
    val nitroFuel: Float = 100f,
    val nitroActive: Boolean = false,
    val isDrifting: Boolean = false,
    val position: Int = 1,
    val totalRacers: Int = 4,
    val currentLap: Int = 1,
    val totalLaps: Int = 3,
    val raceElapsedMs: Long = 0L,
    val currentLapMs: Long = 0L,
    val bestLapMs: Long = 0L,
    val racerMinimapDots: List<Triple<Float, Float, Boolean>> = emptyList(),
    val standings: List<RacerStanding> = emptyList()
)

class RaceSimulation(
    val config: RaceConfig,
    playerUpgrades: CarUpgradeLevels,
    playerPaintId: String
) {
    val track = TrackSpline(TrackCatalog.findById(config.trackId))
    val racers: List<RacerState>
    val player: RacerState
    private val aiDrivers: Map<String, AiDriver>

    var phase: RacePhase = RacePhase.COUNTDOWN
        private set
    private var countdownRemainingSec: Float = 3.2f
    private var goBannerTimer: Float = 0f
    var raceElapsedMs: Long = 0L
        private set

    var playerInput: DriverInput = DriverInput()

    // Ring buffers for VFX
    val particles = Array(220) { Particle() }
    private var nextParticleIdx = 0
    val skidMarks = ArrayDeque<SkidMarkSegment>(360)
    private var prevSkidLeft = HashMap<String, Vec3>()
    private var prevSkidRight = HashMap<String, Vec3>()

    // Sound event callbacks
    var onCountdownTick: ((Int) -> Unit)? = null
    var onRaceGo: (() -> Unit)? = null
    var onLapCompleted: ((Int) -> Unit)? = null
    var onCollisionImpact: ((Float) -> Unit)? = null
    var onRaceFinished: (() -> Unit)? = null

    private var lastCountdownTick = 4
    private var lastPlayerLap = 1
    private var finishNotified = false

    init {
        val playerCar = CarCatalog.findById(config.carId)
        val playerPaint = PaintCatalog.findById(playerPaintId)
        player = RacerState(
            id = "player",
            driverName = "YOU",
            carSpec = playerCar,
            upgrades = playerUpgrades,
            paint = playerPaint,
            isPlayer = true,
            aiSkillMultiplier = 1f
        )

        val list = mutableListOf<RacerState>()
        val aiMap = mutableMapOf<String, AiDriver>()

        if (config.mode == GameMode.CAREER || config.mode == GameMode.QUICK_RACE) {
            val aiNames = listOf("K. Takahashi", "M. Vance", "E. Rossi")
            val rivalCars = CarCatalog.cars.filter { it.id != config.carId }.take(3)
            val rivalPaints = listOf("cobalt_apex", "solar_amber", "emerald_gt")
            val skillOffsets = listOf(0.96f, 1.00f, 1.04f)
            val laneOffsets = listOf(-2.8f, 2.8f, -2.6f)

            for (i in 0 until 3) {
                val aiId = "ai_$i"
                val aiRacer = RacerState(
                    id = aiId,
                    driverName = aiNames[i],
                    carSpec = rivalCars[i % rivalCars.size],
                    upgrades = CarUpgradeLevels(2, 2, 2, 2),
                    paint = PaintCatalog.findById(rivalPaints[i]),
                    isPlayer = false,
                    aiSkillMultiplier = config.difficulty.aiSpeedMultiplier * skillOffsets[i]
                )
                list.add(aiRacer)
                aiMap[aiId] = AiDriver(
                    preferredLaneOffset = laneOffsets[i],
                    difficulty = config.difficulty,
                    aggressionSeed = (i + 1) * 1.37f
                )
            }
        }
        list.add(player)
        racers = list
        aiDrivers = aiMap

        placeOnStartingGrid()
    }

    private fun placeOnStartingGrid() {
        val gridOffsets = listOf(
            Pair(-2.6f, -6f),
            Pair(2.6f, -12f),
            Pair(-2.6f, -18f),
            Pair(2.6f, -24f)
        )
        // Put player in last or 2nd row for exciting overtakes
        val ordered = racers.sortedBy { if (it.isPlayer) 1 else 0 }
        ordered.forEachIndexed { idx, racer ->
            val (lat, backDist) = gridOffsets[idx % gridOffsets.size]
            val sample = track.sampleAtDistance(track.totalLength + backDist)
            racer.x = sample.pos.x + sample.right.x * lat
            racer.y = sample.pos.y
            racer.z = sample.pos.z + sample.right.z * lat
            racer.yawRad = Math3D.yawFromForwardXZ(sample.forward.x, sample.forward.z)
            racer.lastSampleIndex = sample.index
            racer.distanceAlongTrack = sample.distanceAlong
            racer.normalizedProgress = sample.distanceAlong / track.totalLength
            racer.highestSector = 3 // Ready to cross start line or already behind start line
            racer.currentLap = 1
            racer.lateralOffset = lat
        }
        // Reset sector so initial crossing of start line doesn't increment lap immediately
        racers.forEach {
            it.highestSector = 0
            it.totalRaceDistance = it.distanceAlongTrack - track.totalLength
        }
    }

    fun pause() {
        if (phase == RacePhase.RACING || phase == RacePhase.COUNTDOWN) {
            phase = RacePhase.PAUSED
        }
    }

    fun resume() {
        if (phase == RacePhase.PAUSED) {
            phase = if (countdownRemainingSec > 0f) RacePhase.COUNTDOWN else RacePhase.RACING
        }
    }

    fun step(dtRaw: Float, maxParticles: Int) {
        if (phase == RacePhase.PAUSED) return
        val dt = dtRaw.coerceIn(0.001f, 0.05f)

        if (phase == RacePhase.COUNTDOWN) {
            countdownRemainingSec -= dt
            val tick = kotlin.math.ceil(countdownRemainingSec).toInt().coerceIn(0, 3)
            if (tick in 1..3 && tick < lastCountdownTick) {
                lastCountdownTick = tick
                onCountdownTick?.invoke(tick)
            }
            if (countdownRemainingSec <= 0f) {
                phase = RacePhase.RACING
                goBannerTimer = 1.2f
                onRaceGo?.invoke()
            }
            updateParticles(dt)
            return
        }

        if (goBannerTimer > 0f) {
            goBannerTimer = max(0f, goBannerTimer - dt)
        }

        if (phase == RacePhase.RACING) {
            raceElapsedMs += (dt * 1000f).toLong()
        }

        val effectiveLaps = if (config.mode == GameMode.PRACTICE || config.mode == GameMode.TIME_TRIAL) {
            99
        } else {
            config.laps
        }

        for (racer in racers) {
            val input = when {
                racer.finished -> DriverInput(throttle = 0.25f, brake = 0f, steer = 0f, nitro = false)
                racer.isPlayer -> playerInput
                else -> aiDrivers[racer.id]?.computeInput(racer, racers, track, dt) ?: DriverInput()
            }
            racer.stepPhysics(dt, input, track, raceElapsedMs, effectiveLaps)
            emitRacerVfx(racer, maxParticles)
        }

        resolveCarCollisions()
        updateParticles(dt)

        if (player.currentLap > lastPlayerLap) {
            lastPlayerLap = player.currentLap
            onLapCompleted?.invoke(player.currentLap)
        }

        if (player.finished && !finishNotified) {
            finishNotified = true
            phase = RacePhase.FINISHED
            onRaceFinished?.invoke()
        }
    }

    private fun resolveCarCollisions() {
        for (i in 0 until racers.size) {
            for (j in i + 1 until racers.size) {
                val a = racers[i]
                val b = racers[j]
                val dx = b.x - a.x
                val dz = b.z - a.z
                val distSq = dx * dx + dz * dz
                val minRadius = 2.05f
                if (distSq < minRadius * minRadius && distSq > 1e-4f) {
                    val dist = sqrt(distSq)
                    val nx = dx / dist
                    val nz = dz / dist
                    val overlap = (minRadius - dist) * 0.52f
                    a.x -= nx * overlap
                    a.z -= nz * overlap
                    b.x += nx * overlap
                    b.z += nz * overlap

                    val avgSpeed = (a.speedMps + b.speedMps) * 0.5f
                    a.speedMps = Math3D.lerp(a.speedMps, avgSpeed * 0.92f, 0.35f)
                    b.speedMps = Math3D.lerp(b.speedMps, avgSpeed * 0.92f, 0.35f)
                    a.lateralSpeedMps -= nx * 3.2f
                    b.lateralSpeedMps += nx * 3.2f
                    a.collisionFlash = 0.7f
                    b.collisionFlash = 0.7f

                    if (a.isPlayer || b.isPlayer) {
                        onCollisionImpact?.invoke(0.75f)
                    }
                    spawnSparkBurst((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f + 0.55f, (a.z + b.z) * 0.5f)
                }
            }
        }
    }

    private fun emitRacerVfx(racer: RacerState, maxParticles: Int) {
        val fwdX = -sin(racer.yawRad)
        val fwdZ = -cos(racer.yawRad)
        val rightX = cos(racer.yawRad)
        val rightZ = -sin(racer.yawRad)
        val rearDist = racer.carSpec.lengthMeters * 0.48f
        val halfTrack = racer.carSpec.widthMeters * 0.40f

        val rearX = racer.x - fwdX * rearDist
        val rearZ = racer.z - fwdZ * rearDist

        if (racer.nitroActive) {
            spawnParticle(
                x = rearX + rightX * 0.36f,
                y = racer.y + 0.34f,
                z = rearZ + rightZ * 0.36f,
                vx = -fwdX * 9f,
                vy = 0.4f,
                vz = -fwdZ * 9f,
                life = 0.22f,
                size = 0.65f,
                r = 0.1f,
                g = 0.78f,
                b = 1.0f,
                alpha = 0.9f,
                cap = maxParticles
            )
            spawnParticle(
                x = rearX - rightX * 0.36f,
                y = racer.y + 0.34f,
                z = rearZ - rightZ * 0.36f,
                vx = -fwdX * 9f,
                vy = 0.4f,
                vz = -fwdZ * 9f,
                life = 0.22f,
                size = 0.65f,
                r = 0.1f,
                g = 0.78f,
                b = 1.0f,
                alpha = 0.9f,
                cap = maxParticles
            )
        }

        if (racer.isDrifting || racer.collisionFlash > 0.4f) {
            val lw = Vec3(rearX - rightX * halfTrack, racer.y + 0.04f, rearZ - rightZ * halfTrack)
            val rw = Vec3(rearX + rightX * halfTrack, racer.y + 0.04f, rearZ + rightZ * halfTrack)
            val prevL = prevSkidLeft[racer.id]
            val prevR = prevSkidRight[racer.id]
            if (prevL != null && prevR != null) {
                val segLenSq = (lw.x - prevL.x) * (lw.x - prevL.x) + (lw.z - prevL.z) * (lw.z - prevL.z)
                if (segLenSq in 0.15f..18f) {
                    if (skidMarks.size >= 340) {
                        skidMarks.removeFirst()
                        skidMarks.removeFirst()
                    }
                    skidMarks.addLast(SkidMarkSegment(prevL.x, prevL.y, prevL.z, lw.x, lw.y, lw.z, rightX, rightZ))
                    skidMarks.addLast(SkidMarkSegment(prevR.x, prevR.y, prevR.z, rw.x, rw.y, rw.z, rightX, rightZ))
                }
            }
            prevSkidLeft[racer.id] = lw
            prevSkidRight[racer.id] = rw

            if (racer.isDrifting) {
                spawnParticle(
                    x = lw.x,
                    y = lw.y + 0.22f,
                    z = lw.z,
                    vx = (Math.random().toFloat() - 0.5f) * 2.2f,
                    vy = 1.4f,
                    vz = (Math.random().toFloat() - 0.5f) * 2.2f,
                    life = 0.65f,
                    size = 1.25f,
                    r = 0.85f,
                    g = 0.87f,
                    b = 0.90f,
                    alpha = 0.42f,
                    cap = maxParticles
                )
                spawnParticle(
                    x = rw.x,
                    y = rw.y + 0.22f,
                    z = rw.z,
                    vx = (Math.random().toFloat() - 0.5f) * 2.2f,
                    vy = 1.4f,
                    vz = (Math.random().toFloat() - 0.5f) * 2.2f,
                    life = 0.65f,
                    size = 1.25f,
                    r = 0.85f,
                    g = 0.87f,
                    b = 0.90f,
                    alpha = 0.42f,
                    cap = maxParticles
                )
            }
        } else {
            prevSkidLeft.remove(racer.id)
            prevSkidRight.remove(racer.id)
        }
    }

    private fun spawnSparkBurst(x: Float, y: Float, z: Float) {
        repeat(8) {
            spawnParticle(
                x = x,
                y = y,
                z = z,
                vx = (Math.random().toFloat() - 0.5f) * 9f,
                vy = Math.random().toFloat() * 5f + 1.5f,
                vz = (Math.random().toFloat() - 0.5f) * 9f,
                life = 0.35f,
                size = 0.42f,
                r = 1.0f,
                g = 0.72f,
                b = 0.18f,
                alpha = 0.95f,
                cap = particles.size
            )
        }
    }

    private fun spawnParticle(
        x: Float,
        y: Float,
        z: Float,
        vx: Float,
        vy: Float,
        vz: Float,
        life: Float,
        size: Float,
        r: Float,
        g: Float,
        b: Float,
        alpha: Float,
        cap: Int
    ) {
        val activeCap = cap.coerceIn(1, particles.size)
        val p = particles[nextParticleIdx % activeCap]
        nextParticleIdx = (nextParticleIdx + 1) % activeCap
        p.active = true
        p.x = x
        p.y = y
        p.z = z
        p.vx = vx
        p.vy = vy
        p.vz = vz
        p.life = life
        p.maxLife = life
        p.size = size
        p.r = r
        p.g = g
        p.b = b
        p.alpha = alpha
    }

    private fun updateParticles(dt: Float) {
        for (p in particles) {
            if (!p.active) continue
            p.life -= dt
            if (p.life <= 0f) {
                p.active = false
                continue
            }
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.z += p.vz * dt
            p.size += dt * 0.9f
        }
    }

    fun computeStandings(): List<RacerStanding> {
        val sorted = racers.sortedWith(
            compareByDescending<RacerState> { it.totalRaceDistance }
        )
        return sorted.mapIndexed { idx, racer ->
            RacerStanding(
                name = racer.driverName,
                carName = racer.carSpec.name,
                isPlayer = racer.isPlayer,
                position = idx + 1,
                finishTimeMs = if (racer.finished) racer.finishTimeMs else raceElapsedMs,
                bestLapMs = racer.bestLapMs,
                finished = racer.finished
            )
        }
    }

    fun buildHudSnapshot(): RaceHudSnapshot {
        val standings = computeStandings()
        val playerPos = standings.firstOrNull { it.isPlayer }?.position ?: 1
        val dots = racers.map { r ->
            val (nx, nz) = track.normalizePointForMinimap(r.x, r.z)
            Triple(nx, nz, r.isPlayer)
        }
        return RaceHudSnapshot(
            phase = phase,
            countdownValue = kotlin.math.ceil(countdownRemainingSec).toInt().coerceIn(0, 3),
            goBannerTimer = goBannerTimer,
            speedKmh = player.speedKmh.toInt(),
            gear = player.gear,
            rpmNormalized = player.rpmNormalized,
            nitroFuel = player.nitroFuel,
            nitroActive = player.nitroActive,
            isDrifting = player.isDrifting,
            position = playerPos,
            totalRacers = racers.size,
            currentLap = player.currentLap,
            totalLaps = config.laps,
            raceElapsedMs = raceElapsedMs,
            currentLapMs = player.currentLapMs,
            bestLapMs = player.bestLapMs,
            racerMinimapDots = dots,
            standings = standings
        )
    }
}
