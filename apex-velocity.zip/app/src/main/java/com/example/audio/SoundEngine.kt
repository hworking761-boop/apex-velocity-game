package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

class SoundEngine {
    @Volatile
    var enabled: Boolean = true
        set(value) {
            field = value
            if (!value) {
                activeRacing = false
            }
        }

    @Volatile
    var masterVolume: Float = 0.8f

    @Volatile
    var activeRacing: Boolean = false

    @Volatile
    var rpmNormalized: Float = 0.2f

    @Volatile
    var nitroActive: Boolean = false

    @Volatile
    var drifting: Boolean = false

    @Volatile
    private var beepFreq: Float = 0f

    @Volatile
    private var beepSamplesLeft: Int = 0

    @Volatile
    private var impactSamplesLeft: Int = 0

    @Volatile
    private var running: Boolean = false

    private var audioThread: Thread? = null
    private var track: AudioTrack? = null
    private val sampleRate = 22050

    fun start() {
        if (running) return
        running = true
        audioThread = thread(start = true, isDaemon = true, name = "ApexSoundThread") {
            val minBuf = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(1024)

            val localTrack = try {
                AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minBuf * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            } catch (_: Throwable) {
                running = false
                return@thread
            }

            track = localTrack
            try {
                localTrack.play()
            } catch (_: Throwable) {
                running = false
                return@thread
            }

            val chunkSize = 512
            val buffer = ShortArray(chunkSize)
            var phase1 = 0.0
            var phase2 = 0.0
            var phase3 = 0.0
            var beepPhase = 0.0
            var smoothRpm = 0.2f
            val rng = Random(77)

            while (running) {
                if (!enabled || (!activeRacing && beepSamplesLeft <= 0 && impactSamplesLeft <= 0)) {
                    buffer.fill(0)
                    try {
                        localTrack.write(buffer, 0, chunkSize)
                    } catch (_: Throwable) {
                        break
                    }
                    continue
                }

                val vol = masterVolume.coerceIn(0f, 1f)
                val targetRpm = rpmNormalized.coerceIn(0.15f, 1.0f)

                for (i in 0 until chunkSize) {
                    smoothRpm += (targetRpm - smoothRpm) * 0.004f
                    var sample = 0.0

                    if (activeRacing) {
                        val baseFreq = 46.0 + smoothRpm * 145.0
                        phase1 += (2.0 * PI * baseFreq) / sampleRate
                        phase2 += (2.0 * PI * baseFreq * 2.0) / sampleRate
                        phase3 += (2.0 * PI * baseFreq * 3.02) / sampleRate
                        if (phase1 > 2.0 * PI) phase1 -= 2.0 * PI
                        if (phase2 > 2.0 * PI) phase2 -= 2.0 * PI
                        if (phase3 > 2.0 * PI) phase3 -= 2.0 * PI

                        val engine = (sin(phase1) * 0.50 + sin(phase2) * 0.30 + sin(phase3) * 0.16) * 0.32
                        sample += engine

                        if (nitroActive) {
                            val jetNoise = (rng.nextFloat() * 2f - 1f) * 0.22
                            val turbine = sin(phase3 * 2.8) * 0.12
                            sample += jetNoise + turbine
                        }

                        if (drifting) {
                            val screech = sin(phase2 * 4.5 + rng.nextFloat() * 0.4) * 0.14
                            sample += screech
                        }
                    }

                    if (beepSamplesLeft > 0) {
                        beepPhase += (2.0 * PI * beepFreq) / sampleRate
                        if (beepPhase > 2.0 * PI) beepPhase -= 2.0 * PI
                        sample += sin(beepPhase) * 0.26
                        beepSamplesLeft--
                    }

                    if (impactSamplesLeft > 0) {
                        val env = impactSamplesLeft / 2200.0
                        sample += (rng.nextFloat() * 2f - 1f) * 0.38 * env
                        impactSamplesLeft--
                    }

                    val clamped = (sample * vol).coerceIn(-0.95, 0.95)
                    buffer[i] = (clamped * Short.MAX_VALUE).toInt().toShort()
                }

                try {
                    localTrack.write(buffer, 0, chunkSize)
                } catch (_: Throwable) {
                    break
                }
            }
        }
    }

    fun playCountdownBeep(isGo: Boolean) {
        if (!enabled) return
        beepFreq = if (isGo) 880f else 440f
        beepSamplesLeft = if (isGo) 6200 else 3200
    }

    fun playLapChime() {
        if (!enabled) return
        beepFreq = 660f
        beepSamplesLeft = 4000
    }

    fun playCollisionThud() {
        if (!enabled) return
        impactSamplesLeft = 2200
    }

    fun stop() {
        running = false
        activeRacing = false
        try {
            track?.pause()
            track?.flush()
            track?.release()
        } catch (_: Throwable) {
        }
        track = null
        audioThread = null
    }
}
