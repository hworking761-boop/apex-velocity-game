package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.audio.SoundEngine
import com.example.engine.RaceHudSnapshot
import com.example.graphics.RaceGLRenderer
import com.example.input.TiltSteeringManager
import com.example.model.GameMode
import com.example.ui.GameViewModel
import com.example.ui.screens.CareerScreen
import com.example.ui.screens.GarageScreen
import com.example.ui.screens.LoadingScreen
import com.example.ui.screens.MainMenuScreen
import com.example.ui.screens.QuickRaceSetupScreen
import com.example.ui.screens.RaceScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.ApexVelocityTheme

object AppRoutes {
    const val LOADING = "loading"
    const val MAIN_MENU = "main_menu"
    const val CAREER = "career"
    const val QUICK_SETUP = "quick_setup/{mode}"
    const val GARAGE = "garage/{upgrades}"
    const val SETTINGS = "settings"
    const val RACE = "race"

    fun quickSetup(mode: GameMode) = "quick_setup/${mode.name}"
    fun garage(openUpgrades: Boolean) = "garage/$openUpgrades"
}

class MainActivity : ComponentActivity() {
    private lateinit var soundEngine: SoundEngine
    private lateinit var tiltManager: TiltSteeringManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        configureImmersiveMode()

        soundEngine = SoundEngine()
        tiltManager = TiltSteeringManager(this)

        setContent {
            ApexVelocityTheme {
                ApexVelocityApp(
                    soundEngine = soundEngine,
                    tiltManager = tiltManager
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        configureImmersiveMode()
        soundEngine.start()
    }

    override fun onPause() {
        super.onPause()
        tiltManager.stop()
        soundEngine.stop()
    }

    private fun configureImmersiveMode() {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }
}

@Composable
private fun ApexVelocityApp(
    soundEngine: SoundEngine,
    tiltManager: TiltSteeringManager,
    gameViewModel: GameViewModel = viewModel()
) {
    val navController = rememberNavController()
    val isInitialized by gameViewModel.isInitialized.collectAsStateWithLifecycle()
    val profile by gameViewModel.profile.collectAsStateWithLifecycle()
    val garageCars by gameViewModel.garageCars.collectAsStateWithLifecycle()
    val careerResults by gameViewModel.careerResults.collectAsStateWithLifecycle()
    val bestLaps by gameViewModel.bestLaps.collectAsStateWithLifecycle()
    val settings by gameViewModel.settings.collectAsStateWithLifecycle()
    val browsedCarId by gameViewModel.browsedCarId.collectAsStateWithLifecycle()
    val activeRaceConfig by gameViewModel.activeRaceConfig.collectAsStateWithLifecycle()
    val lastRaceResult by gameViewModel.lastRaceResult.collectAsStateWithLifecycle()
    val garageFeedback by gameViewModel.garageFeedback.collectAsStateWithLifecycle()

    var hudSnapshot by remember { mutableStateOf(RaceHudSnapshot()) }
    val renderer = remember {
        RaceGLRenderer(
            onHudTick = { snapshot -> hudSnapshot = snapshot }
        )
    }

    val totalStars = remember(careerResults) { careerResults.values.sumOf { it.stars } }

    LaunchedEffect(settings.soundEnabled, settings.soundVolume) {
        soundEngine.enabled = settings.soundEnabled
        soundEngine.masterVolume = settings.soundVolume
    }

    LaunchedEffect(isInitialized) {
        if (isInitialized && navController.currentDestination?.route == AppRoutes.LOADING) {
            navController.navigate(AppRoutes.MAIN_MENU) {
                popUpTo(AppRoutes.LOADING) { inclusive = true }
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            tiltManager.stop()
            soundEngine.stop()
        }
    }

    NavHost(
        navController = navController,
        startDestination = AppRoutes.LOADING
    ) {
        composable(AppRoutes.LOADING) {
            LoadingScreen()
        }

        composable(AppRoutes.MAIN_MENU) {
            MainMenuScreen(
                renderer = renderer,
                profile = profile,
                garageCars = garageCars,
                totalStars = totalStars,
                onPlayNow = {
                    gameViewModel.startQuickPlayNow()
                    navController.navigate(AppRoutes.RACE)
                },
                onCareer = {
                    navController.navigate(AppRoutes.CAREER)
                },
                onQuickRace = { mode ->
                    navController.navigate(AppRoutes.quickSetup(mode))
                },
                onGarage = { openUpgrades ->
                    gameViewModel.browseCar(profile.selectedCarId)
                    navController.navigate(AppRoutes.garage(openUpgrades))
                },
                onSettings = {
                    navController.navigate(AppRoutes.SETTINGS)
                }
            )
        }

        composable(AppRoutes.CAREER) {
            CareerScreen(
                profile = profile,
                careerResults = careerResults,
                totalStars = totalStars,
                onBack = { navController.popBackStack() },
                onLaunchEvent = { config ->
                    gameViewModel.prepareRace(config)
                    navController.navigate(AppRoutes.RACE)
                }
            )
        }

        composable(
            route = AppRoutes.QUICK_SETUP,
            arguments = listOf(navArgument("mode") { type = NavType.StringType })
        ) { backStackEntry ->
            val modeName = backStackEntry.arguments?.getString("mode") ?: GameMode.QUICK_RACE.name
            val initialMode = runCatching { GameMode.valueOf(modeName) }.getOrDefault(GameMode.QUICK_RACE)
            QuickRaceSetupScreen(
                initialMode = initialMode,
                profile = profile,
                bestLaps = bestLaps,
                totalStars = totalStars,
                onBack = { navController.popBackStack() },
                onOpenGarage = {
                    gameViewModel.browseCar(profile.selectedCarId)
                    navController.navigate(AppRoutes.garage(false))
                },
                onStartRace = { config ->
                    gameViewModel.prepareRace(config)
                    navController.navigate(AppRoutes.RACE)
                }
            )
        }

        composable(
            route = AppRoutes.GARAGE,
            arguments = listOf(navArgument("upgrades") { type = NavType.BoolType })
        ) { backStackEntry ->
            val openUpgrades = backStackEntry.arguments?.getBoolean("upgrades") ?: false
            GarageScreen(
                renderer = renderer,
                profile = profile,
                garageCars = garageCars,
                browsedCarId = browsedCarId,
                totalStars = totalStars,
                initialUpgradesTab = openUpgrades,
                feedbackMessage = garageFeedback,
                onClearFeedback = { gameViewModel.clearGarageFeedback() },
                onBrowseCar = { gameViewModel.browseCar(it) },
                onSelectCar = { gameViewModel.selectCar(it) },
                onPurchaseCar = { gameViewModel.purchaseCar(it) },
                onSelectPaint = { carId, paintId -> gameViewModel.setCarPaint(carId, paintId) },
                onUpgradeCar = { carId, cat -> gameViewModel.upgradeCar(carId, cat) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(AppRoutes.SETTINGS) {
            SettingsScreen(
                settings = settings,
                profile = profile,
                totalStars = totalStars,
                tiltSupported = tiltManager.isSupported,
                onGraphicsChange = { gameViewModel.setGraphicsQuality(it) },
                onTiltToggle = { gameViewModel.setTiltSteeringEnabled(it) },
                onTiltSensitivity = { gameViewModel.setTiltSensitivity(it) },
                onSoundToggle = { gameViewModel.setSoundEnabled(it) },
                onSoundVolume = { gameViewModel.setSoundVolume(it) },
                onDefaultCamera = { gameViewModel.setDefaultCamera(it) },
                onShowMinimap = { gameViewModel.setShowMinimap(it) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(AppRoutes.RACE) {
            val config = activeRaceConfig
            if (config != null) {
                RaceScreen(
                    config = config,
                    upgrades = gameViewModel.getCurrentCarUpgrades(config.carId),
                    paintId = gameViewModel.getCurrentCarPaintId(config.carId),
                    settings = settings,
                    renderer = renderer,
                    soundEngine = soundEngine,
                    tiltManager = tiltManager,
                    raceResult = lastRaceResult,
                    onHudUpdate = { hudSnapshot = it },
                    hudState = hudSnapshot,
                    onRaceCompleted = { pos, totalMs, bestLapMs, standings ->
                        gameViewModel.recordRaceFinished(config, pos, totalMs, bestLapMs, standings)
                    },
                    onQuitToMenu = {
                        gameViewModel.clearRaceResult()
                        navController.popBackStack(AppRoutes.MAIN_MENU, inclusive = false)
                    }
                )
            }
        }
    }
}
